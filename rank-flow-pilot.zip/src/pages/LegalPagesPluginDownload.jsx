import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function LegalPagesPluginDownload() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleDownload = async () => {
    setLoading(true);
    setError('');

    try {
      const response = await base44.functions.invoke('downloadLegalPagesPluginZip', {});
      const fileUrl = response?.data?.file_url;

      if (!fileUrl) {
        setError('Le lien de téléchargement est introuvable.');
        return;
      }

      window.open(fileUrl, '_blank');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-3xl">
        <Card>
          <CardHeader>
            <CardTitle>MoneyAbroadGuide Legal Pages Generator</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-sm text-muted-foreground">
              Téléchargez un plugin WordPress léger qui crée automatiquement les pages Privacy Policy, About Us et Contact,
              puis les ajoute au menu principal et au footer.
            </p>

            <Button onClick={handleDownload} disabled={loading}>
              {loading ? 'Préparation du ZIP...' : 'Télécharger le plugin ZIP'}
            </Button>

            {error ? <p className="text-sm text-destructive">{error}</p> : null}

            <div className="space-y-2 text-sm text-muted-foreground">
              <p className="font-medium text-foreground">Installation</p>
              <p>1. Téléchargez le fichier ZIP.</p>
              <p>2. Dans WordPress : Plugins → Add New → Upload Plugin.</p>
              <p>3. Importez le ZIP puis cliquez sur Activate.</p>
              <p>4. Le plugin crée et publie automatiquement les 3 pages légales.</p>
            </div>

            <div className="space-y-2 text-sm text-muted-foreground">
              <p className="font-medium text-foreground">Checklist</p>
              <p>• Privacy Policy créée et publiée</p>
              <p>• About Us créée et publiée</p>
              <p>• Contact créée et publiée</p>
              <p>• Ajout au menu principal sans doublons</p>
              <p>• Ajout au footer + disclosure affiliée</p>
              <p>• HTML simple, compatible Astra + Elementor</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}