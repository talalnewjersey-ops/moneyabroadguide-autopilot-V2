import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const normalizeUrl = (url = '') => url.toLowerCase().trim().replace(/^https?:\/\//, '').replace(/\/$/, '');
const targetUrl = 'moneyabroadguide.com';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const websites = await base44.asServiceRole.entities.Website.list();
    const website = websites.find((item) => normalizeUrl(item.url) === targetUrl);

    if (!website) {
      return Response.json({ error: 'Website not found.' }, { status: 404 });
    }

    const pages = await base44.asServiceRole.entities.Page.filter({ website_id: website.id }, '-updated_date', 20);
    const pageContext = pages.map((page) => ({
      url: page.url,
      title: page.title,
      meta_description: page.meta_description,
      h1: page.h1,
      word_count: page.word_count,
      seo_score: page.seo_score,
      content_score: page.content_score,
      keywords: page.keywords || [],
      internal_links_count: page.internal_links_count || 0,
      has_faq: page.has_faq || false,
      has_alt_text: page.has_alt_text !== false,
    }));

    const scanLog = await base44.asServiceRole.entities.AutomationLog.create({
      website_id: website.id,
      task_type: 'site_scan',
      status: 'running',
      details: 'Daily SEO automation started',
      items_processed: 0,
    });

    const audit = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `Run a production-style daily SEO audit for ${website.url}. Use these known pages as context: ${JSON.stringify(pageContext)}. Also use live web context. Return overall seo_score, total_pages_scanned, critical_issues, warnings, opportunities, summary, and up to 10 actionable issues with type, severity, page_url, description, recommendation. Focus on technical SEO, thin content, missing metadata, internal linking, FAQ opportunities, ALT text gaps, and trust signals.`,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          seo_score: { type: 'number' },
          total_pages_scanned: { type: 'number' },
          critical_issues: { type: 'number' },
          warnings: { type: 'number' },
          opportunities: { type: 'number' },
          summary: { type: 'string' },
          issues: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                type: { type: 'string' },
                severity: { type: 'string' },
                page_url: { type: 'string' },
                description: { type: 'string' },
                recommendation: { type: 'string' }
              }
            }
          },
          recommendations: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                page_url: { type: 'string' },
                type: { type: 'string' },
                priority: { type: 'string' },
                description: { type: 'string' },
                suggested_content: { type: 'string' },
                impact_score: { type: 'number' }
              }
            }
          },
          keywords: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                keyword: { type: 'string' },
                search_volume: { type: 'number' },
                difficulty: { type: 'string' },
                intent: { type: 'string' },
                cluster: { type: 'string' },
                assigned_page: { type: 'string' }
              }
            }
          }
        }
      }
    });

    await base44.asServiceRole.entities.SiteScan.create({
      website_id: website.id,
      status: 'completed',
      seo_score: audit.seo_score,
      total_pages_scanned: audit.total_pages_scanned || pageContext.length,
      critical_issues: audit.critical_issues || 0,
      warnings: audit.warnings || 0,
      opportunities: audit.opportunities || 0,
      issues: audit.issues || [],
      summary: audit.summary || ''
    });

    await base44.asServiceRole.entities.Website.update(website.id, {
      status: 'connected',
      seo_score: audit.seo_score || website.seo_score || 0,
      last_scan_date: new Date().toISOString(),
      total_pages: audit.total_pages_scanned || pageContext.length,
      total_issues: (audit.critical_issues || 0) + (audit.warnings || 0)
    });

    const existingKeywords = await base44.asServiceRole.entities.Keyword.filter({ website_id: website.id }, '-created_date', 200);
    const existingKeywordSet = new Set(existingKeywords.map((item) => String(item.keyword || '').toLowerCase()));
    let newKeywords = 0;

    for (const keyword of audit.keywords || []) {
      const keywordName = String(keyword.keyword || '').trim().toLowerCase();
      if (!keywordName || existingKeywordSet.has(keywordName)) continue;
      await base44.asServiceRole.entities.Keyword.create({
        website_id: website.id,
        keyword: keyword.keyword,
        search_volume: keyword.search_volume || 0,
        difficulty: keyword.difficulty || 'medium',
        intent: keyword.intent || 'informational',
        cluster: keyword.cluster || '',
        assigned_page: keyword.assigned_page || '',
        status: 'opportunity'
      });
      existingKeywordSet.add(keywordName);
      newKeywords += 1;
    }

    let newRecommendations = 0;
    for (const recommendation of audit.recommendations || []) {
      await base44.asServiceRole.entities.ContentRecommendation.create({
        website_id: website.id,
        page_url: recommendation.page_url || website.url,
        type: recommendation.type || 'content_refresh',
        priority: recommendation.priority || 'medium',
        description: recommendation.description || '',
        suggested_content: recommendation.suggested_content || '',
        impact_score: recommendation.impact_score || 0,
        status: 'pending'
      });
      newRecommendations += 1;
    }

    await base44.asServiceRole.entities.AutomationLog.update(scanLog.id, {
      status: 'completed',
      details: audit.summary || 'Daily SEO automation completed',
      items_processed: (audit.issues || []).length + newRecommendations + newKeywords
    });

    return Response.json({
      success: true,
      website: website.url,
      seo_score: audit.seo_score || 0,
      issues_found: (audit.issues || []).length,
      recommendations_created: newRecommendations,
      keywords_created: newKeywords
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});