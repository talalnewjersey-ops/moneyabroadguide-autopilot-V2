import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Key, Loader2, Sparkles, Target } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import EmptyState from '../components/common/EmptyState';
import { toast } from 'sonner';

export default function KeywordCenter() {
  const [seedKeyword, setSeedKeyword] = useState('');
  const [discovering, setDiscovering] = useState(false);
  const queryClient = useQueryClient();

  const { data: websites = [] } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 1),
  });

  const activeWebsite = websites[0];

  const { data: keywords = [], isLoading } = useQuery({
    queryKey: ['keywords', activeWebsite?.id],
    queryFn: () => base44.entities.Keyword.filter({ website_id: activeWebsite.id }),
    enabled: !!activeWebsite,
  });

  const discoverKeywords = async () => {
    if (!seedKeyword || !activeWebsite) return;
    setDiscovering(true);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an SEO keyword research expert. For the website ${activeWebsite.url}, generate keyword opportunities related to: "${seedKeyword}"
      
      Return 15 keyword ideas with realistic data. Include a mix of:
      - Long-tail keywords (low difficulty)
      - Medium competition keywords
      - High volume head terms
      
      Group them into clusters.`,
      response_json_schema: {
        type: "object",
        properties: {
          keywords: {
            type: "array",
            items: {
              type: "object",
              properties: {
                keyword: { type: "string" },
                search_volume: { type: "number" },
                difficulty: { type: "string" },
                intent: { type: "string" },
                cluster: { type: "string" }
              }
            }
          }
        }
      },
      add_context_from_internet: true,
    });

    for (const kw of result.keywords) {
      await base44.entities.Keyword.create({
        website_id: activeWebsite.id,
        ...kw,
        status: 'opportunity',
      });
    }

    queryClient.invalidateQueries({ queryKey: ['keywords'] });
    setSeedKeyword('');
    setDiscovering(false);
    toast.success(`${result.keywords.length} keywords discovered!`);
  };

  if (!activeWebsite) {
    return <EmptyState icon={Key} title="No website connected" description="Add a website in Settings first." />;
  }

  const clusters = [...new Set(keywords.map(k => k.cluster).filter(Boolean))];
  const difficultyColor = { low: 'bg-green-50 text-green-700', medium: 'bg-amber-50 text-amber-700', high: 'bg-red-50 text-red-700' };
  const intentColor = { informational: 'bg-blue-50 text-blue-700', transactional: 'bg-purple-50 text-purple-700', navigational: 'bg-gray-50 text-gray-700', commercial: 'bg-cyan-50 text-cyan-700' };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Keyword Center" description="Discover and track keyword opportunities" />

      <div className="flex gap-3">
        <Input
          placeholder="Enter a seed keyword (e.g. 'money transfer abroad')..."
          value={seedKeyword}
          onChange={e => setSeedKeyword(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && discoverKeywords()}
          className="flex-1 rounded-xl"
        />
        <Button onClick={discoverKeywords} disabled={discovering} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
          {discovering ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          {discovering ? 'Discovering...' : 'Discover Keywords'}
        </Button>
      </div>

      {keywords.length === 0 && !isLoading ? (
        <EmptyState icon={Key} title="No keywords yet" description="Enter a seed keyword above to start discovering opportunities." />
      ) : (
        <>
          {clusters.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {clusters.map(cluster => (
                <Badge key={cluster} variant="outline" className="rounded-lg px-3 py-1">
                  <Target className="w-3 h-3 mr-1" />
                  {cluster} ({keywords.filter(k => k.cluster === cluster).length})
                </Badge>
              ))}
            </div>
          )}

          <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
            <div className="grid grid-cols-12 gap-4 p-4 text-xs font-medium text-gray-500 border-b border-gray-50 bg-gray-50/50">
              <div className="col-span-4">Keyword</div>
              <div className="col-span-2">Volume</div>
              <div className="col-span-2">Difficulty</div>
              <div className="col-span-2">Intent</div>
              <div className="col-span-2">Cluster</div>
            </div>
            {keywords.map(kw => (
              <div key={kw.id} className="grid grid-cols-12 gap-4 p-4 items-center hover:bg-gray-50/50 transition-colors border-b border-gray-50 last:border-0">
                <div className="col-span-4 text-sm font-medium text-gray-900">{kw.keyword}</div>
                <div className="col-span-2 text-sm text-gray-600">{kw.search_volume?.toLocaleString() || '—'}</div>
                <div className="col-span-2">
                  <Badge className={difficultyColor[kw.difficulty] || 'bg-gray-50 text-gray-700'}>
                    {kw.difficulty}
                  </Badge>
                </div>
                <div className="col-span-2">
                  <Badge className={intentColor[kw.intent] || 'bg-gray-50 text-gray-700'}>
                    {kw.intent}
                  </Badge>
                </div>
                <div className="col-span-2 text-xs text-gray-400">{kw.cluster || '—'}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}