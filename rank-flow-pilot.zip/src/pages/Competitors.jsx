import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Loader2, Sparkles, TrendingUp, TrendingDown } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import EmptyState from '../components/common/EmptyState';
import { toast } from 'sonner';

export default function Competitors() {
  const [competitorUrl, setCompetitorUrl] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const queryClient = useQueryClient();

  const { data: websites = [] } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 1),
  });

  const activeWebsite = websites[0];

  const { data: competitors = [], isLoading } = useQuery({
    queryKey: ['competitors', activeWebsite?.id],
    queryFn: () => base44.entities.Competitor.filter({ website_id: activeWebsite.id }),
    enabled: !!activeWebsite,
  });

  const analyzeCompetitor = async () => {
    if (!competitorUrl || !activeWebsite) return;
    setAnalyzing(true);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Compare the website ${activeWebsite.url} against competitor ${competitorUrl}.
      
      Return a detailed competitor analysis with:
      - name (competitor site name)
      - avg_article_length (estimated average)
      - keyword_overlap (percentage 0-100)
      - strengths (array of 3-5 competitor strengths)
      - weaknesses (array of 3-5 competitor weaknesses you can exploit)`,
      response_json_schema: {
        type: "object",
        properties: {
          name: { type: "string" },
          avg_article_length: { type: "number" },
          keyword_overlap: { type: "number" },
          strengths: { type: "array", items: { type: "string" } },
          weaknesses: { type: "array", items: { type: "string" } }
        }
      },
      add_context_from_internet: true,
    });

    let url = competitorUrl;
    if (!url.startsWith('http')) url = 'https://' + url;

    await base44.entities.Competitor.create({
      website_id: activeWebsite.id,
      competitor_url: url,
      ...result,
      last_analyzed: new Date().toISOString(),
    });

    queryClient.invalidateQueries({ queryKey: ['competitors'] });
    setCompetitorUrl('');
    setAnalyzing(false);
    toast.success('Competitor analyzed!');
  };

  if (!activeWebsite) {
    return <EmptyState icon={Users} title="No website connected" description="Add a website in Settings first." />;
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Competitor Benchmark" description="Analyze how you stack up against competitors" />

      <div className="flex gap-3">
        <Input
          placeholder="Enter competitor URL..."
          value={competitorUrl}
          onChange={e => setCompetitorUrl(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && analyzeCompetitor()}
          className="flex-1 rounded-xl"
        />
        <Button onClick={analyzeCompetitor} disabled={analyzing} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
          {analyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          {analyzing ? 'Analyzing...' : 'Analyze Competitor'}
        </Button>
      </div>

      {competitors.length === 0 && !isLoading ? (
        <EmptyState icon={Users} title="No competitors analyzed" description="Add competitor URLs to compare and find opportunities." />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {competitors.map(comp => (
            <Card key={comp.id} className="hover:shadow-sm transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-gray-900">{comp.name || 'Competitor'}</h3>
                    <p className="text-xs text-gray-400 truncate">{comp.competitor_url}</p>
                  </div>
                  <Badge className="bg-blue-50 text-blue-700">{comp.keyword_overlap}% overlap</Badge>
                </div>

                <div className="text-xs text-gray-500 mb-4">
                  Avg. article length: <span className="font-medium text-gray-700">{comp.avg_article_length?.toLocaleString()} words</span>
                </div>

                {comp.strengths?.length > 0 && (
                  <div className="mb-3">
                    <p className="text-xs font-medium text-gray-500 mb-1.5 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3 text-green-500" /> Their Strengths
                    </p>
                    <div className="space-y-1">
                      {comp.strengths.map((s, i) => (
                        <p key={i} className="text-xs text-gray-600 pl-4">• {s}</p>
                      ))}
                    </div>
                  </div>
                )}

                {comp.weaknesses?.length > 0 && (
                  <div>
                    <p className="text-xs font-medium text-gray-500 mb-1.5 flex items-center gap-1">
                      <TrendingDown className="w-3 h-3 text-red-500" /> Their Weaknesses (Your Opportunity)
                    </p>
                    <div className="space-y-1">
                      {comp.weaknesses.map((w, i) => (
                        <p key={i} className="text-xs text-gray-600 pl-4">• {w}</p>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}