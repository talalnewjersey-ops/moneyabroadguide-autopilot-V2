import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import HomeHeader from '@/components/home/HomeHeader';
import HomeFooter from '@/components/home/HomeFooter';
import StickyCompareBar from '@/components/home/StickyCompareBar';
import SectionReveal from '@/components/home/SectionReveal';
import MoneyTransferCalculator from '@/components/home/MoneyTransferCalculator';
import TransferComparisonTable from '@/components/home/TransferComparisonTable';
import SeoFaq from '@/components/seo/SeoFaq';
import { getTransferRoute } from '@/lib/transferRoutes';

export default function TransferRoutePage() {
  const { slug } = useParams();
  const route = getTransferRoute(slug);

  useEffect(() => {
    if (!route) return;
    document.title = `${route.seoTitle} | MoneyAbroadGuide`;
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'description';
      document.head.appendChild(meta);
    }
    meta.content = route.metaDescription;
  }, [route]);

  if (!route) {
    return <div className="min-h-screen bg-[#F8FAFC]"><HomeHeader /><div className="mx-auto max-w-[1200px] px-4 py-20">Route not found.</div><HomeFooter /></div>;
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-950">
      <HomeHeader />

      <section className="hero border-b border-slate-200">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-20">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3 text-sm text-slate-500">
              <Link to="/HomePage" className="hover:text-slate-950">Home</Link>
              <span>•</span>
              <Link to="/SeoHub" className="hover:text-slate-950">SEO Hub</Link>
              <span>•</span>
              <span>{route.fromCountry} → {route.toCountry}</span>
            </div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">SEO silo page</p>
            <h1 className="max-w-4xl text-4xl font-extrabold tracking-tight sm:text-5xl">{route.h1}</h1>
            <p className="max-w-3xl text-lg leading-8 text-slate-500">{route.intro}</p>
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {route.highlights.map((item) => (
              <div key={item} className="fintech-card p-5">
                <p className="text-base leading-7 text-slate-600">{item}</p>
              </div>
            ))}
          </div>
        </SectionReveal>
      </section>

      <section className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
        <MoneyTransferCalculator initialFromCountry={route.fromCountry} initialToCountry={route.toCountry} />
      </section>

      <section className="mx-auto max-w-[1200px] px-4 py-4 sm:px-6 lg:px-8 lg:py-8">
        <SectionReveal className="space-y-6">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">Comparison table</p>
          <h2 className="text-3xl font-semibold">Compare providers for {route.fromCountry} to {route.toCountry}</h2>
          <p className="max-w-3xl text-base leading-8 text-slate-500">Use this route page to compare provider pricing, speed, exchange-rate quality, and commercial offers before sending money.</p>
          <TransferComparisonTable />
        </SectionReveal>
      </section>

      <section className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
        <SectionReveal className="rounded-[28px] bg-[#0B1F3A] px-6 py-8 text-white sm:px-8">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-white/70">Action step</p>
          <h2 className="mt-3 text-3xl font-semibold">Ready to send money now?</h2>
          <p className="mt-3 max-w-2xl text-base leading-8 text-white/80">Use the calculator above, compare providers side by side, and then click through to the best-fit offer for your transfer.</p>
          <a href="#calculator" className="mt-6 inline-flex rounded-full bg-white px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-slate-100">Send Money Now</a>
        </SectionReveal>
      </section>

      <section className="mx-auto max-w-[1200px] px-4 pb-20 sm:px-6 lg:px-8">
        <SectionReveal className="space-y-6">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">FAQ</p>
          <h2 className="text-3xl font-semibold">Frequently asked questions</h2>
          <SeoFaq items={route.faq} />
        </SectionReveal>
      </section>

      <HomeFooter />
      <StickyCompareBar />
    </div>
  );
}