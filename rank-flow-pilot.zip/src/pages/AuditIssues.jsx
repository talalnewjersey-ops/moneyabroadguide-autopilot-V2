import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import PageHeader from '../components/common/PageHeader';

export default function AuditIssues() {
  const { data: issues = [] } = useQuery({ queryKey: ['audit-issues'], queryFn: () => base44.entities.AuditIssue.list('-created_date', 100) });
  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Audit Issues" description="Action-ready issue queue with recommended fixes and auto-apply flags." />
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="grid grid-cols-12 gap-4 p-4 text-xs font-medium text-gray-500 border-b bg-gray-50/50"><div className="col-span-2">Severity</div><div className="col-span-2">Priority</div><div className="col-span-3">Issue</div><div className="col-span-5">Recommended fix</div></div>
        {issues.map((issue) => <div key={issue.id} className="grid grid-cols-12 gap-4 p-4 border-b last:border-0"><div className="col-span-2 text-sm">{issue.severity}</div><div className="col-span-2 text-sm">{issue.priority}</div><div className="col-span-3 text-sm font-medium">{issue.issue_type}</div><div className="col-span-5 text-sm text-gray-600">{issue.recommended_fix || issue.description}</div></div>)}
      </div>
    </div>
  );
}