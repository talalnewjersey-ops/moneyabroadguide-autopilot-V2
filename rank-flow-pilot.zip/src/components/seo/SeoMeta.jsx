import React, { useEffect } from 'react';

export default function SeoMeta({ title, description }) {
  useEffect(() => {
    document.title = title;

    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }

    meta.setAttribute('content', description || 'MoneyAbroadGuide compares international money transfer providers for expats, immigrants, and global workers.');
  }, [title, description]);

  return null;
}