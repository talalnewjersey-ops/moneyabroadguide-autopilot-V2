import React from 'react';
import { trustPoints } from '@/lib/homepageData';
import SectionReveal from '@/components/home/SectionReveal';
import SectionHeading from '@/components/home/SectionHeading';

export default function HomeTrust() {
  return (
    <section id="trust" className="trust bg-white">
      <SectionReveal className="mx-auto max-w-[920px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
        <SectionHeading
          eyebrow="Built on transparency"
          title="Financial authority that helps users trust the comparison"
          description="We focus on real pricing, better clarity, and a more trustworthy user experience so people feel safe making money decisions here."
        />

        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
          {trustPoints.map((item) => (
            <div key={item.label} className="fintech-card fintech-card-hover p-6 text-center">
              <p className="text-4xl font-extrabold text-slate-950">{item.value}</p>
              <p className="mt-3 text-sm font-medium text-slate-500">{item.label}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 flex justify-center">
          <a href="#calculator" className="cta-primary h-13 px-8 text-sm">
            Compare Fees Now
          </a>
        </div>
      </SectionReveal>
    </section>
  );
}