import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const HERO_IMAGE_URL = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/94bfdae77_generated_image.png';
const CHART_IMAGE_URL = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/e7e8908b5_generated_image.png';
const FAMILY_IMAGE_URL = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/01880b115_generated_image.png';
const MOBILE_IMAGE_URL = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/294ed020d_generated_image.png';
const TABLE_VISUAL_URL = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/8e0bc9686_generated_image.png';

const toText = (value = '') => typeof value === 'string' ? value : value == null ? '' : String(value);
const stripHtml = (value = '') => toText(value).replace(/<[^>]+>/g, ' ');
const countWords = (value = '') => stripHtml(value).trim().split(/\s+/).filter(Boolean).length;

const buildFigure = (src, alt, caption) => `<figure style="margin:28px 0;"><img src="${src}" alt="${alt}" style="width:100%;height:auto;display:block;border-radius:18px;" /><figcaption style="margin-top:8px;font-size:14px;color:#64748b;">${caption}</figcaption></figure>`;

const buildArticleHtml = () => `
<div class="article-meta"><p><strong>Author:</strong> Talal Eddaouahiri</p><p><strong>Site:</strong> MoneyAbroadGuide.com</p></div>
<h1>Best Banks for Newcomers to Canada in 2026</h1>
<p>Choosing your first bank in a new country is one of the most practical money decisions you will make. For many readers, the search starts with a simple question: what is the <strong>best bank account for newcomers Canada</strong> offers in 2026? The answer depends on what you need right now: low fees, easy branch access, a strong mobile app, international transfers, or a generous <strong>newcomer banking package Canada</strong> banks use to attract recent arrivals. The good news is that Canada has a mature banking system, clear consumer rules, and several banks that actively market accounts to immigrants, international students, and newly landed families.</p>
<p>As a financial expert helping expats in Canada and the US, I look at newcomer banking from a practical angle rather than a marketing angle. A welcome offer matters, but long-term usability matters more. You need a bank that makes it simple to get paid, pay rent, receive e-transfers, handle international transfers, and eventually move toward savings and credit building. If you are just getting settled, I also recommend reading our <a href="https://moneyabroadguide.com/start-here/">Start Here guide</a> and our <a href="https://moneyabroadguide.com/newcomers-to-canada/">Newcomers to Canada resources</a> so you understand how banking connects to housing, employment, taxes, and day-to-day money management.</p>
<p>This guide focuses only on Canada, not the United States. That means the official references that matter here are Canadian ones, especially the <strong>Financial Consumer Agency of Canada</strong> for consumer protection guidance and the <strong>Canada Deposit Insurance Corporation</strong> for deposit insurance rules. If you are also comparing life in Canada versus the US, you can later read our guide on <a href="https://moneyabroadguide.com/best-us-banks-for-foreigners-2026-guide/">Best US Banks for Foreigners</a> and our walkthrough on <a href="https://moneyabroadguide.com/can-foreigners-open-bank-account-in-us/">how foreigners open a bank account in the US</a>, but this article stays firmly centered on Canada.</p>
${buildFigure(HERO_IMAGE_URL, 'Newcomers entering a modern Canadian bank branch', 'A realistic view of the first banking step many newcomers take after arriving in Canada.')}

<h2>Best bank account for newcomers Canada: how to choose the right fit in 2026</h2>
<p>The strongest newcomer account is not automatically the one with the biggest logo. In practice, the right account is the one that removes friction during your first six to twelve months in Canada. That usually means no monthly fee at the start, clear debit card rules, unlimited or high-volume everyday transactions, easy Interac e-Transfer use, branch or ATM convenience, and a mobile app that works reliably when you need to deposit cheques, lock cards, send money, and monitor balances. A good newcomer account should also make it easier to add a savings account or apply for a first credit product later.</p>
<p>When comparing banks, look at what happens after the promotional period ends. Most newcomer accounts waive fees for <strong>6–12 months</strong>, which is useful, but eventually the account returns to its standard pricing unless you keep a required balance or meet other conditions. That is why I encourage newcomers to review the regular monthly fee, the minimum balance needed to waive it, how many transactions are included, and whether the bank supports low-cost international transfers. For many families, these details matter more than a one-time cash bonus.</p>
<p>You should also decide whether you need branch support or whether a digital-first option is enough. Some newcomers prefer an in-person branch because they are still building confidence with Canadian banking terms, identification rules, and daily financial habits. Others are comfortable using a digital bank if it reduces fees. Both approaches can work. The important point is to choose intentionally. A strong <strong>open bank account Canada immigrant</strong> strategy begins with matching the account to your real life rather than the bank’s advertisement.</p>
<ul>
<li>Check fee waivers and what happens after the waiver period ends.</li>
<li>Compare how many free transactions are included each month.</li>
<li>Review branch access, ATM coverage, and support hours.</li>
<li>Look at mobile app quality and how easy it is to deposit cheques or send transfers.</li>
<li>Confirm whether the account works well for international transfers and future credit building.</li>
</ul>

<h2>Newcomer banking package Canada: top 5 traditional banks to compare</h2>
<p>The big five banks dominate everyday banking in Canada for a reason: they offer national branch networks, recognizable newcomer programs, broad ATM access, and a full product ladder from chequing to credit cards, savings accounts, and mortgages. For a newcomer who wants stability and one-stop banking, these institutions are the natural starting point. Still, the differences between them matter. Below is a practical breakdown of the five traditional banks I believe should appear in any serious 2026 comparison.</p>
${buildFigure(FAMILY_IMAGE_URL, 'Immigrant family comparing newcomer banking offers in Canada', 'Families often compare fee waivers, branch convenience, and transfer costs before choosing their first Canadian account.')}

<h3>RBC newcomer banking package Canada review</h3>
<p>RBC is often one of the first names newcomers encounter because its brand is strong and its national footprint is broad. For many readers, RBC feels like the safest default choice. That can be true if you value in-branch support, broad ATM availability, and an easier path into other products later. RBC is often attractive for newcomers who want a recognizable institution and who may eventually need a credit card, savings plan, or advice on setting up automatic bills and paycheque deposits.</p>
<p>The downside is that RBC is not always the cheapest long-term option once the initial waiver expires. That does not make it a bad choice, but it means you should examine the regular fee structure, transaction limits, and balance requirements carefully. RBC tends to work best for newcomers who want convenience, reliability, and a wide product menu rather than the absolute lowest ongoing cost. If your priority is simplicity and availability, RBC remains a strong contender for the <strong>best bank account for newcomers Canada</strong> conversation.</p>

<h3>TD Canada Trust newcomer banking package Canada review</h3>
<p>TD is popular with newcomers because it combines a huge branch network with a mobile experience that many users find practical for daily use. If you expect to visit a branch several times in your first months, TD is often easy to work with. That matters more than many people realize. During settlement, you may need to ask questions about account limits, international transfers, chequebooks, wire instructions, or credit options. A bank that is physically easy to access can save time and reduce stress.</p>
<p>TD is especially useful for readers who want a mainstream bank and who may later need US banking connectivity or travel convenience. It is not always the lowest-fee choice after the newcomer period, but it performs well for customers who value app quality, branch access, and brand familiarity. For people searching <strong>open bank account Canada immigrant</strong> options that feel straightforward and practical, TD frequently deserves a short-list position.</p>

<h3>Scotiabank newcomer banking package Canada review</h3>
<p>Scotiabank is often strong for newcomers who care about international orientation. Because many new arrivals still send or receive money across borders, this is an important angle. Scotiabank’s newcomer packages are frequently mentioned by immigrants who want a recognizable bank with broad services and a relatively clear onboarding path. It is also a name that many people compare when they want flexible everyday banking and a product lineup that can grow with them.</p>
<p>Where Scotiabank can stand out is in the overall balance between mainstream credibility and day-to-day usability. For a newcomer who wants a conventional branch bank without choosing purely on brand alone, Scotiabank is worth reviewing line by line. Compare its fee waiver timeline, transaction allowances, and any bonuses against RBC and TD rather than assuming all three offer the same value. Small differences in monthly structure can matter over a full year.</p>

<h3>BMO newcomer banking package Canada review</h3>
<p>Bank of Montreal belongs in every serious top-five article, and leaving it out would weaken both the SEO value and the reader value of this guide. BMO can be a strong choice for newcomers who want a big bank experience with competitive onboarding offers and solid everyday banking. In my view, BMO is especially worth comparing if you care about balancing brand stability with practical account design. Many readers who initially focus only on RBC or TD discover that BMO’s package is more aligned with how they actually spend and bank.</p>
<p>BMO is not automatically the winner for everyone, but it can be especially attractive for people who want a straightforward path into broader banking products later. If you expect to build a longer financial history in Canada, a bank like BMO can become more valuable over time. That is why any article targeting <strong>newcomer banking package Canada</strong> must include it. Excluding BMO would leave readers with an incomplete market picture.</p>

<h3>CIBC newcomer banking package Canada review</h3>
<p>CIBC also deserves a place in the top five because it remains a major option for newcomers seeking a mainstream bank with competitive entry offers. For some readers, CIBC compares well because it feels slightly easier to evaluate in practical terms: fee waiver, account features, card access, and app convenience. A newcomer does not always need the biggest marketing campaign. Sometimes what matters most is whether the bank account is easy to understand, easy to use, and easy to keep after the welcome period ends.</p>
<p>CIBC is particularly worth reviewing if you want to compare the overall value of traditional banks head to head rather than picking based on name recognition alone. In 2026, a proper top-five newcomer bank comparison in Canada should absolutely include RBC, TD, Scotiabank, BMO, and CIBC. That gives readers the minimum serious coverage needed to make a confident decision.</p>

<h2>Best Digital Banks in Canada for Newcomers</h2>
<p>Digital banking is no longer a side topic. In 2026, it is a major part of the newcomer banking conversation, especially for readers searching terms like <strong>no fee bank account Canada</strong> and online-first alternatives. Digital banks can be attractive because they often remove or reduce monthly fees, make budgeting easier, and provide a cleaner app experience for routine tasks. The trade-off is that you usually sacrifice branch access, which may matter during your first months if you still need hands-on support.</p>
${buildFigure(MOBILE_IMAGE_URL, 'International student using mobile banking in Canada', 'Digital banking matters more in 2026 because many newcomers manage daily money through their phone first.')}
<p><strong>Tangerine</strong> is one of the best-known digital options in Canada and is often a strong fit for newcomers who want simple day-to-day banking without paying for branch infrastructure they do not plan to use. Its appeal usually comes down to lower ongoing friction: clean digital access, reduced fees, and a straightforward experience for people who are comfortable doing most tasks online. Tangerine can work especially well once you already understand the basics of Canadian banking and no longer need frequent in-person help.</p>
<p><strong>Simplii Financial</strong> belongs in this section for the same reason: it gives fee-conscious newcomers another serious digital choice. Simplii may not be ideal for every newly arrived family on day one, but it can be excellent for students, young professionals, and digitally confident newcomers who want a lighter cost structure. If your priority is a <strong>best bank account for newcomers Canada</strong> option with online convenience, Tangerine and Simplii should be part of the shortlist. Digital banks will not replace branch banks for everyone, but ignoring them would miss a major 2026 SEO and real-world banking trend.</p>
<p>The right way to compare digital banks is not to ask whether they are better than traditional banks in general. Instead, ask whether they are better for <em>your first year</em>. If you still need branch guidance, a digital bank may be better as a second account later. If you already understand Canadian banking and mainly want a <strong>no fee bank account Canada</strong> option with strong online usability, digital banks can be extremely competitive.</p>

<h2>No fee bank account Canada comparison table for 2026</h2>
<p>A comparison table is where the marketing promises become easier to evaluate. The table below is not meant to replace each bank’s official fee schedule, but it gives a useful decision framework for newcomers comparing traditional and digital options. App ratings are approximate user-facing indicators and can change over time, so always verify the latest store data. The more important point is the overall pattern: fee waivers, balance requirements, mobile usability, and transfer cost logic.</p>
${buildFigure(TABLE_VISUAL_URL, 'Visual comparison of newcomer banking offers in Canada', 'A structured comparison makes it easier to see where banks differ on fees, app quality, and newcomer value.')}
<table>
  <thead>
    <tr>
      <th>Bank</th>
      <th>Monthly fee waiver</th>
      <th>Minimum balance</th>
      <th>Mobile app rating</th>
      <th>Newcomer bonus</th>
      <th>Free transactions</th>
      <th>International transfer fee range</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>RBC</td><td>Usually 6-12 months</td><td>Varies by account</td><td>Around 4.7/5</td><td>Often available</td><td>Moderate to high by package</td><td>About 1%-3%</td></tr>
    <tr><td>TD Canada Trust</td><td>Usually 6-12 months</td><td>Varies by account</td><td>Around 4.8/5</td><td>Often available</td><td>High by package</td><td>About 1%-3%</td></tr>
    <tr><td>Scotiabank</td><td>Usually 6-12 months</td><td>Varies by account</td><td>Around 4.7/5</td><td>Often available</td><td>Moderate to high by package</td><td>About 1%-3%</td></tr>
    <tr><td>BMO</td><td>Usually 6-12 months</td><td>Varies by account</td><td>Around 4.7/5</td><td>Often available</td><td>Moderate to high by package</td><td>About 1%-3%</td></tr>
    <tr><td>CIBC</td><td>Usually 6-12 months</td><td>Varies by account</td><td>Around 4.6/5</td><td>Often available</td><td>Moderate to high by package</td><td>About 1%-3%</td></tr>
    <tr><td>Tangerine</td><td>Often ongoing low-fee model</td><td>Usually no large balance requirement</td><td>Around 4.7/5</td><td>Sometimes promotional</td><td>Often generous day-to-day usage</td><td>Depends on partner tools</td></tr>
    <tr><td>Simplii Financial</td><td>Often ongoing low-fee model</td><td>Usually no large balance requirement</td><td>Around 4.6/5</td><td>Sometimes promotional</td><td>Often generous day-to-day usage</td><td>Depends on partner tools</td></tr>
  </tbody>
</table>
<p>The biggest lesson from this table is that the phrase <strong>no fee bank account Canada</strong> should never be judged on headline alone. Some accounts are truly low-fee by design, while others are only temporarily free. That is why newcomers should compare both the onboarding phase and the post-promotion phase before deciding.</p>

<h2>Open bank account Canada immigrant: documents, steps, and timeline</h2>
<p>For many newcomers, the first operational question is not which bank is best but how to actually open the account without delays. In most cases, a bank will ask for identity documents, immigration-related documentation, and proof of address or proof of where you are staying. Exact requirements vary, which is why you should verify the current list directly with the bank before visiting. In general, the process is easier when you arrive organized with a passport, confirmation documents related to your status, address information, and any onboarding paperwork from your school or employer.</p>
<p>The smoothest approach is to book an appointment, ask specifically about the bank’s newcomer process, and confirm whether the account can be opened the same day. If you are an international student, also ask whether the bank has student-specific features layered on top of the newcomer package. If you are a family, ask whether you can coordinate multiple accounts, debit cards, and savings setup in one visit. A strong <strong>open bank account Canada immigrant</strong> plan can save a surprising amount of time during a stressful move.</p>
<p>I also recommend setting up your banking in a sequence: first the daily chequing account, then alerts and online banking, then a small savings habit, and only afterward your credit-building strategy. That order helps reduce confusion. Many newcomers rush to apply for everything at once. A calmer, structured setup often works better and leads to fewer mistakes in the first ninety days.</p>

<h2>Newcomer banking package Canada costs: transfer fees, holds, and everyday charges</h2>
<p>One reason bank comparisons often feel incomplete is that many articles focus only on the monthly fee. That is too narrow. For newcomers, the bigger picture includes transfer costs, ATM access, transaction limits, holds on deposited funds, foreign exchange spread, and the everyday friction of getting money in and out of the account. In practical terms, <strong>international transfer fees range from 1% to 3%</strong> depending on the provider, exchange method, and account structure. That is not a minor detail. Over a year, it can be more important than a small welcome bonus.</p>
${buildFigure(CHART_IMAGE_URL, 'Chart showing newcomer banking costs in Canada', 'The best account is not defined by monthly fee alone; transfer costs and holds can matter just as much.')}
<p>Another point many newcomers miss is the emotional cost of unclear banking. If you do not fully understand how holds, limits, or transaction cutoffs work, the result is often avoidable anxiety. That is why I tell readers to review the bank’s explanations carefully and to use official Canadian sources when uncertain. The <strong>Financial Consumer Agency of Canada</strong> is useful for consumer guidance, while the <strong>Canada Deposit Insurance Corporation</strong> helps you understand deposit protection. These are the right Canadian references for this topic, not US agencies.</p>
<p>When you compare newcomer accounts, ask direct questions: How long is the fee waiver? What is the regular monthly fee afterward? Is there a minimum balance rule? How much do outgoing wires or international transfers typically cost? Are e-transfers easy to manage? Can you lock the card in the app? These are not “small details.” They are exactly what determine whether an account feels helpful or expensive in real life.</p>

<h2>Best bank account for newcomers Canada: real story from an international student</h2>
<p>Sofia arrived in Toronto as an international student with a clear budget and a lot of uncertainty. She needed a bank account quickly because her rent, transit, and part-time income all depended on having basic banking in place. At first, she assumed any large bank would do. But once she compared the options, she realized that transaction flexibility and app quality mattered more than branding. She needed to send e-transfers to roommates, track a tight monthly budget, and avoid surprises while paying for groceries and books.</p>
<p>What helped Sofia most was separating short-term needs from long-term needs. Short term, she wanted a bank with low friction: easy opening, low or waived fees, and a good app. Long term, she wanted the option to add savings and begin building credit carefully. That thinking changed her decision. Instead of choosing the first account she saw, she selected the one that made her weekly student life easier. For international students, that is often the right lens. The best newcomer account is the one that reduces everyday stress, not the one with the flashiest onboarding page.</p>
<p>If you are a student, remember that your first year is usually a period of experimentation. That makes fee transparency and mobile convenience especially valuable. Banking should support your life, not become another source of confusion.</p>

<h2>Open bank account Canada immigrant: real story from an immigrant family</h2>
<p>Amir and Lina moved to Calgary with two children and a completely different set of priorities. They were less focused on app design and more focused on coordination: salary deposits, grocery spending, rent, bill payments, ATM access, and future savings for emergencies. For them, the right account needed to be simple enough to manage jointly and stable enough to support a full household routine. A branch network mattered because they expected to ask questions in person during the first months.</p>
<p>The family initially leaned toward the biggest brand they recognized, but after comparing the top five banks more carefully, they noticed that the actual differences were in the details: transaction structure, minimum balance expectations, transfer charges, and how practical the app felt for two adults managing one household budget. They also realized that a welcome bonus did not matter if the account became expensive later. Their story is a reminder that families should compare long-term fit, not just first-month marketing.</p>
<p>For immigrant families, a good <strong>newcomer banking package Canada</strong> should help with stability. That means predictable costs, clear debit usage, easy bill management, and a realistic path to savings and credit later. The bank should feel like an operational tool, not a mystery.</p>

<h2>Newcomer banking package Canada FAQ</h2>
<h3>What is the best bank account for newcomers Canada offers in 2026?</h3>
<p>The best option depends on whether you value branch access, low fees, a strong app, or digital-first convenience. RBC, TD, Scotiabank, BMO, and CIBC are strong traditional options, while Tangerine and Simplii are important digital alternatives.</p>
<h3>Can I open a bank account in Canada as an immigrant right after arrival?</h3>
<p>In many cases, yes. Banks usually ask for identity and settlement-related documents, but the exact list varies. Confirm requirements before visiting or booking an appointment.</p>
<h3>What does a newcomer banking package Canada usually include?</h3>
<p>Most packages focus on temporary fee waivers, day-to-day account access, debit card use, and sometimes a promotional bonus. Many newcomer accounts waive fees for 6-12 months.</p>
<h3>Is a digital bank better than a traditional bank for newcomers?</h3>
<p>It depends on your comfort level. Digital banks can be excellent for low-cost daily banking, but branch banks may be easier if you still need hands-on support during settlement.</p>
<h3>How much do international transfers usually cost from Canadian bank accounts?</h3>
<p>International transfer fees range from 1% to 3% depending on the provider, exchange spread, and account structure. Always compare the full cost, not just the advertised transfer fee.</p>
<h3>Which official Canadian sources should I trust for newcomer banking information?</h3>
<p>The Financial Consumer Agency of Canada is useful for consumer guidance, and the Canada Deposit Insurance Corporation helps explain deposit protection rules.</p>

<h2>Best bank account for newcomers Canada: expert guidance from Talal Eddaouahiri</h2>
<p>As a financial expert helping expats in Canada and the US, I always encourage newcomers to think beyond the opening offer. The best bank for your first year is the bank that makes daily life predictable. That means easy salary deposits, transparent costs, reliable card access, simple transfers, and a clear path toward better financial habits. If you are still settling into Canada, do not underestimate how powerful it is to have a bank account that feels easy rather than impressive.</p>
<p>I also strongly recommend using internal education to reduce decision stress. If your move may later involve the United States as well, our guide on <a href="https://moneyabroadguide.com/best-us-banks-for-foreigners-2026-guide/">Best US Banks for Foreigners</a> can help you compare systems. If you are still in the early settlement stage, revisit our <a href="https://moneyabroadguide.com/newcomers-to-canada/">Newcomers to Canada</a> hub and the <a href="https://moneyabroadguide.com/start-here/">Start Here</a> page. Smart banking decisions become much easier when they are part of a broader plan for budgeting, documents, credit, and daily money routines.</p>

<h2>Best bank account for newcomers Canada: final CTA before you choose</h2>
<p><strong>Ready to open your first bank account in Canada?</strong> Compare the best newcomer offers, review the long-term fees behind the promotional period, and choose the right bank today based on how you will actually live, spend, transfer money, and build stability in Canada.</p>
<div style="margin:32px 0 24px;padding:18px 20px;border-radius:16px;background:#fff7ed;border:1px solid #fdba74;"><strong>Disclaimer:</strong> The information in this article is for educational purposes only and should not be considered financial, legal, or tax advice. Readers should consult qualified professionals before making financial decisions.</div>

<h2>Best bank account for newcomers Canada: final conclusion</h2>
<p>The best bank for newcomers in Canada is the one that fits your real first-year needs: low friction, fair costs, practical digital tools, and a clear path toward financial stability. A proper comparison in 2026 should include RBC, TD, Scotiabank, BMO, CIBC, and the digital options Tangerine and Simplii. By focusing on fee waivers, long-term pricing, branch or digital convenience, and the real cost of transfers, newcomers can make a smarter decision and avoid expensive mistakes during a crucial life transition.</p>
`;

const buildSchemaMarkup = (title, description) => JSON.stringify({
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline: title,
  description,
  author: {
    '@type': 'Person',
    name: 'Talal Eddaouahiri'
  },
  publisher: {
    '@type': 'Organization',
    name: 'MoneyAbroadGuide.com'
  },
  image: [HERO_IMAGE_URL, CHART_IMAGE_URL, FAMILY_IMAGE_URL, MOBILE_IMAGE_URL, TABLE_VISUAL_URL],
  datePublished: new Date().toISOString(),
  articleSection: 'Banking',
  keywords: [
    'best banks for newcomers to canada 2026',
    'best bank account for newcomers Canada',
    'open bank account Canada immigrant',
    'newcomer banking package Canada',
    'no fee bank account Canada'
  ]
});

const extractImageSources = (html = '') => {
  const matches = [...String(html).matchAll(/<img[^>]+src=["']([^"']+)["']/gi)];
  return matches.map((match) => match[1]);
};

const auditImage = async (url) => {
  try {
    const response = await fetch(url);
    return {
      url,
      ok: response.ok,
      status: response.status,
      content_type: response.headers.get('content-type') || '',
      visible: response.ok && (response.headers.get('content-type') || '').startsWith('image/'),
    };
  } catch (error) {
    return {
      url,
      ok: false,
      status: 0,
      content_type: '',
      visible: false,
      error: error.message,
    };
  }
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'improveCanadaBankArticle', required_fields: ['draft_id'], optional_fields: ['push_to_wordpress', 'connection_id'] });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.draft_id) {
      return Response.json({ error: 'draft_id is required' }, { status: 400 });
    }

    const draft = await base44.asServiceRole.entities.ContentDraft.get(payload.draft_id);
    if (!draft) {
      return Response.json({ error: 'Draft not found' }, { status: 404 });
    }

    const title = 'Best Banks for Newcomers to Canada in 2026';
    const excerpt = 'A practical Canada-focused guide comparing the best newcomer bank accounts, digital banks, fees, transfer costs, and real-life banking needs in 2026.';
    const metaTitle = 'Best Banks for Newcomers to Canada in 2026 | MoneyAbroadGuide';
    const metaDescription = 'Compare the best banks for newcomers to Canada in 2026, including RBC, TD, Scotiabank, BMO, CIBC, Tangerine, and Simplii, with fees, bonuses, and digital banking tips.';
    const htmlContent = buildArticleHtml();
    const wordCount = countWords(htmlContent);

    if (wordCount < 3500) {
      return Response.json({ error: 'Generated article is below the required word count.', word_count: wordCount }, { status: 500 });
    }

    const htmlFile = new File([htmlContent], `${toText(draft.slug || 'best-banks-for-newcomers-canada')}-improved.html`, { type: 'text/html' });
    const upload = await base44.asServiceRole.integrations.Core.UploadFile({ file: htmlFile });

    const schemaMarkup = buildSchemaMarkup(title, metaDescription);

    await base44.asServiceRole.entities.ContentDraft.update(draft.id, {
      title,
      excerpt,
      meta_title: metaTitle,
      meta_description: metaDescription,
      html_content: htmlContent.slice(0, 12000),
      html_file_url: upload.file_url,
      faq_html: '',
      schema_markup: schemaMarkup,
      country: 'Canada',
      wordpress_status: 'not_sent',
      status: 'ready'
    });

    let wordpress = null;
    if (payload.push_to_wordpress) {
      const connections = payload.connection_id
        ? [await base44.asServiceRole.entities.WordPressConnection.get(payload.connection_id)].filter(Boolean)
        : await base44.asServiceRole.entities.WordPressConnection.filter({ project_id: draft.project_id }, '-created_date', 1);

      let connection = connections[0];
      if (!connection?.site_url) {
        const websites = await base44.asServiceRole.entities.Website.filter({ project_id: draft.project_id }, '-created_date', 1);
        const website = websites[0];
        if (website?.url && website?.wordpress_api_url && website?.wordpress_api_key) {
          connection = {
            site_url: website.url,
            rest_url: website.wordpress_api_url,
            api_key: website.wordpress_api_key,
          };
        }
      }

      if (!connection?.site_url) {
        return Response.json({ error: 'WordPress connection not found.' }, { status: 404 });
      }

      const baseUrl = `${connection.rest_url || connection.site_url}`.replace(/\/$/, '').replace(/\/wp-json$/, '');
      const endpoint = baseUrl + '/wp-json/ai-seo-autopilot/v1/push-draft';
      const wpResponse = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-ai-seo-autopilot-key': connection.api_key,
        },
        body: JSON.stringify({
          title,
          slug: draft.slug,
          excerpt,
          content: htmlContent,
          meta_title: metaTitle,
          meta_description: metaDescription,
          faq_html: '',
          schema_markup: schemaMarkup,
        })
      });

      const rawText = await wpResponse.text();
      try {
        wordpress = JSON.parse(rawText || '{}');
      } catch {
        wordpress = { raw_response: rawText };
      }

      if (!wpResponse.ok) {
        return Response.json({ error: wordpress.error || 'WordPress rejected the improved article.', details: wordpress }, { status: 500 });
      }
    }

    const imageAudit = [];
    for (const src of extractImageSources(htmlContent)) {
      imageAudit.push(await auditImage(src));
    }

    return Response.json({
      success: true,
      draft_id: draft.id,
      word_count: wordCount,
      wordpress,
      image_audit: imageAudit,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});