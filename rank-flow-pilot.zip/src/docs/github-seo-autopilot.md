# MoneyAbroadGuide GitHub SEO Autopilot

This setup is intentionally **GitHub-first**, **safe**, and **dry-run by default**.

## What this framework does

- Runs a daily safe scan from GitHub Actions
- Runs a weekly SEO audit from GitHub Actions
- Generates report files instead of silently changing production
- Prepares safe patch proposals for:
  - editorial policy cleanup
  - base64 image replacement workflow
  - robots.txt update
  - metadata comparison
  - internal linking suggestions
  - Rank Math setup checklist
  - schema strategy
  - EEAT improvements
- Generates 5 article drafts as Markdown + JSON

## Safety rules

- Patch mode only
- Dry-run by default
- No destructive actions
- No full-site rewrites
- No direct production changes without manual approval
- Designed to stay compatible with Astra, LiteSpeed, Rank Math, and Wordfence

## Repo structure

- `.github/workflows/seo-daily.yml`
- `.github/workflows/seo-weekly.yml`
- `scripts/seo/common.py`
- `scripts/seo/daily_scan.py`
- `scripts/seo/weekly_audit.py`
- `docs/seo-reports/`
- `content-drafts/`
- `meta/`

## Required GitHub secrets

Set these in **GitHub > Settings > Secrets and variables > Actions**.

### Required for report-only framework
- `WP_BASE_URL`

### Required for authenticated WordPress REST read/write expansion
- `WP_USERNAME`
- `WP_APP_PASSWORD`

### Optional integrations
- `GSC_SITE_URL`
- `PAGESPEED_API_KEY`
- `AHREFS_API_KEY`
- `MOZ_ACCESS_ID`
- `MOZ_SECRET_KEY`

If optional secrets are missing, the system remains in report/proposal mode.

## How it works

### Daily workflow
Generates:
- editorial artifact report
- base64 image detection report
- robots.txt ready-to-apply file
- meta comparison report
- internal linking report
- schema report
- EEAT plan
- Rank Math checklist

### Weekly workflow
Generates:
- weekly audit JSON
- weekly audit Markdown summary
- thin content findings
- missing meta report references
- internal linking report references
- 5 article drafts in Markdown
- 5 companion meta JSON files

## robots.txt final version

```txt
User-agent: *
Allow: /

Disallow: /wp-admin/
Allow: /wp-admin/admin-ajax.php

Sitemap: https://moneyabroadguide.com/sitemap.xml
```

## Manual approval required before apply mode

Do not add automatic production apply steps until all of the following are verified:

1. WordPress backup process is documented
2. REST authentication is confirmed
3. Rank Math/Astra schema overlap is reviewed
4. Wordfence rules are checked
5. LiteSpeed cache purge strategy is defined
6. Reversible rollback logs are implemented

## Exact commands to commit and push

```bash
git checkout -b safe-seo-autopilot
git add .github/workflows/seo-daily.yml .github/workflows/seo-weekly.yml scripts/seo docs/github-seo-autopilot.md docs/seo-reports content-drafts meta
git commit -m "Add safe GitHub-first SEO autopilot framework"
git push origin safe-seo-autopilot
```

Then open a pull request and review generated reports before merging.