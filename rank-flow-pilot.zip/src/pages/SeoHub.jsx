import React from 'react';
import { Link } from 'react-router-dom';
import HomeHeader from '@/components/home/HomeHeader';
import HomeFooter from '@/components/home/HomeFooter';
import StickyCompareBar from '@/components/home/StickyCompareBar';
import SectionReveal from '@/components/home/SectionReveal';
import { transferRoutes } from '@/lib/transferRoutes';
import { seoArticles } from '@/lib/seoArticles';

export default function SeoHub() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-950">
      <HomeHeader />
      <section className="hero border-b border-slate-200">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-20">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">SEO hub</p>
          <h1 className="mt-3 max-w-4xl text-4xl font-extrabold tracking-tight sm:text-5xl">Money transfer route pages and ready-to-publish guides</h1>
          <p className="mt-4 max-w-3xl text-lg leading-8 text-slate-500">Explore high-intent transfer corridor pages and 20 conversion-focused SEO guides designed to rank, educate, and push users into the calculator.</p>
        </SectionReveal>
      </section>

      <section className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
        <div className="mb-8 space-y-2">
          <h2 className="text-3xl font-semibold">SEO silo pages</h2>
          <p className="text-slate-500">Route-specific pages with calculator, comparison, and FAQ blocks.</p>
        </div>
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {transferRoutes.map((route) => (
            <Link key={route.slug} to={`/routes/${route.slug}`} className="fintech-card fintech-card-hover p-6">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">{route.fromCountry} → {route.toCountry}</p>
              <h3 className="mt-3 text-2xl font-semibold text-slate-950">{route.h1}</h3>
              <p className="mt-3 text-base leading-7 text-slate-500">{route.intro}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1200px] px-4 pb-20 sm:px-6 lg:px-8">
        <div className="mb-8 space-y-2">
          <h2 className="text-3xl font-semibold">Ready-to-publish SEO guides</h2>
          <p className="text-slate-500">Commercial and educational pages with internal links, FAQs, and calculator CTAs.</p>
        </div>
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {seoArticles.map((article) => (
            <Link key={article.slug} to={`/guides/${article.slug}`} className="fintech-card fintech-card-hover p-6">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">SEO article</p>
              <h3 className="mt-3 text-2xl font-semibold text-slate-950">{article.h1}</h3>
              <p className="mt-3 text-base leading-7 text-slate-500">{article.metaDescription}</p>
            </Link>
          ))}
        </div>
      </section>

      <HomeFooter />
      <StickyCompareBar />
    </div>
  );
}