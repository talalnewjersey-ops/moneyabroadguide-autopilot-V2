import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';
import JSZip from 'npm:jszip@3.10.1';

const pluginPhp = String.raw`<?php
/**
 * Plugin Name: MoneyAbroadGuide Dashboard Preview Homepage
 * Description: Recreates the current MoneyAbroadGuide homepage preview and sets it as the WordPress homepage.
 * Version: 1.0.4
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) exit;

class MAG_Dashboard_Preview_Homepage {
    const PAGE_SLUG = 'moneyabroadguide-dashboard-home';

    public function __construct() {
        add_shortcode('mag_dashboard_home', [$this, 'render_shortcode']);
        add_filter('the_content', [$this, 'append_article_footer'], 20);
    }

    public static function activate() {
        $instance = new self();
        $page_id = $instance->ensure_page();

        if ($page_id && !is_wp_error($page_id)) {
            update_option('show_on_front', 'page');
            update_option('page_on_front', $page_id);
            update_option('page_for_posts', 0);
        }

        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    private function ensure_page() {
        $page = get_page_by_path(self::PAGE_SLUG, OBJECT, 'page');
        $page_data = [
            'post_title' => 'MoneyAbroadGuide Home',
            'post_name' => self::PAGE_SLUG,
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_content' => '[mag_dashboard_home]',
        ];

        if ($page) {
            $page_data['ID'] = $page->ID;
            return wp_update_post($page_data, true);
        }

        return wp_insert_post($page_data, true);
    }

    public function render_shortcode() {
        wp_enqueue_style('mag-dashboard-home-style', plugins_url('style.css', __FILE__), [], '1.0.6');
        wp_enqueue_script('mag-dashboard-home-script', plugins_url('script.js', __FILE__), [], '1.0.6', true);

        $logo_url = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/7807cf1df_logoMoneyabroadGuide.jpeg';

        ob_start();
        ?>
        <style>
          #mag-restored-header-shell,
          #mag-home-intro,
          .seo-autopilot-homepage-h1,
          .entry-content > section:not(.mag-home-root),
          .entry-content > h1:not(.mag-home-root h1),
          .site-header,
          #masthead,
          .main-header-bar,
          .ast-above-header-wrap,
          .ast-below-header-wrap,
          .ast-desktop-header,
          .ast-mobile-header-wrap,
          .ast-theme-transparent-header,
          header[role='banner'] {
            display: none !important;
          }
        </style>
        <div class="mag-home-root" id="top">
          <header class="mag-home-header">
            <div class="mag-home-shell mag-home-header-inner">
              <a href="<?php echo esc_url(home_url('/')); ?>" class="mag-home-logo-link" aria-label="MoneyAbroadGuide homepage">
                <img src="<?php echo esc_url($logo_url); ?>" alt="MoneyAbroadGuide" class="mag-home-logo" loading="lazy" />
              </a>
              <nav class="mag-home-nav" aria-label="Primary navigation">
                <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                <a href="#blog">Start here</a>
                <a href="#blog">Newcomers to the USA</a>
                <a href="#blog">Newcomers to Canada</a>
              </nav>
              <a href="#calculator" class="mag-home-btn mag-home-btn-primary mag-home-hide-mobile">Find the Cheapest Transfer Now</a>
            </div>
          </header>

          <main class="mag-home-page">
            <section class="mag-home-hero">
              <div class="mag-home-shell">
                <div class="mag-home-hero-inner">
                  <div class="mag-home-pill">Trusted money transfer comparison for immigrants, expats, and global families</div>
                  <h1>Save Up to 90% on International Money Transfers</h1>
                  <p>Compare real-time rates from trusted providers and avoid hidden fees.</p>
                  <div class="mag-home-actions">
                    <a href="#compare" class="mag-home-btn mag-home-btn-primary">Compare Now</a>
                    <a href="#compare" class="mag-home-btn mag-home-btn-secondary">See Best Providers</a>
                  </div>
                  <div class="mag-home-trust-row">
                    <span class="mag-home-trust-pill">Trusted by newcomers and expats</span>
                    <span class="mag-home-trust-pill">Transparent fees</span>
                    <span class="mag-home-trust-pill">Expert-reviewed content</span>
                  </div>
                  <div class="mag-home-steps-grid">
                    <div class="mag-home-step-card"><strong>★★★★★</strong><span>Trusted by thousands of users</span></div>
                    <div class="mag-home-step-card"><strong>Step 1</strong><span>Enter amount</span></div>
                    <div class="mag-home-step-card"><strong>Step 2</strong><span>Compare providers</span></div>
                    <div class="mag-home-step-card mag-home-step-card-last"><strong>Step 3</strong><span>Send money</span></div>
                  </div>
                  <div class="mag-home-summary-card">
                    <div class="mag-home-section-heading mag-home-left-heading">
                      <h2>Compare top money transfer services at a glance</h2>
                      <p>See which providers help you save more, move faster, and get stronger exchange value before you click out.</p>
                    </div>
                    <div class="mag-home-table-wrap">
                      <table class="mag-home-table" aria-label="Money transfer summary table">
                        <thead>
                          <tr>
                            <th>Service</th>
                            <th>Fees</th>
                            <th>Speed</th>
                            <th>Exchange Rate</th>
                            <th>Rating</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr><td>Wise</td><td>Low, transparent</td><td>Minutes to 2 days</td><td>Mid-market rate</td><td>4.9/5</td><td><a href="https://wise.com/" rel="nofollow sponsored" target="_blank">View deal</a></td></tr>
                          <tr><td>Remitly</td><td>Promo-friendly</td><td>Express available</td><td>Competitive</td><td>4.8/5</td><td><a href="https://www.remitly.com/" rel="nofollow sponsored" target="_blank">View deal</a></td></tr>
                          <tr><td>OFX</td><td>No fixed fee</td><td>1–3 days</td><td>Strong on large transfers</td><td>4.7/5</td><td><a href="https://www.ofx.com/" rel="nofollow sponsored" target="_blank">View deal</a></td></tr>
                          <tr><td>Xe Money Transfer</td><td>Varies</td><td>Same day to 3 days</td><td>Live rate tools</td><td>4.6/5</td><td><a href="https://www.xe.com/" rel="nofollow sponsored" target="_blank">View deal</a></td></tr>
                        </tbody>
                      </table>
                    </div>
                    <div class="mag-home-highlight-grid">
                      <div class="mag-home-highlight"><span>Lowest cost</span><strong>Wise</strong></div>
                      <div class="mag-home-highlight"><span>Fast transfers</span><strong>Remitly</strong></div>
                      <div class="mag-home-highlight"><span>Large amounts</span><strong>OFX</strong></div>
                      <div class="mag-home-highlight"><span>Rate tools</span><strong>Xe</strong></div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section id="blog" class="mag-home-section">
              <div class="mag-home-shell">
                <div class="mag-home-section-heading">
                  <p class="mag-home-kicker">Authority content</p>
                  <h2>Guides designed to build trust before users compare fees</h2>
                  <p>Educational content for newcomers helps establish authority, improve conversion quality, and move visitors naturally toward the calculator.</p>
                </div>
                <div class="mag-home-blog-grid">
                  <article class="mag-home-article-card">
                    <div class="mag-home-tag">USA</div>
                    <h3>Newcomers to the USA</h3>
                    <p>Educational explanations of U.S. financial concepts, including banking basics, saving, and everyday money terminology.</p>
                    <a href="<?php echo esc_url(home_url('/newcomers-to-the-usa/')); ?>">Read Full Guide</a>
                  </article>
                  <article class="mag-home-article-card">
                    <div class="mag-home-tag">Canada</div>
                    <h3>Newcomers to Canada</h3>
                    <p>Educational information to help readers understand Canadian banking systems, savings basics, and financial fundamentals.</p>
                    <a href="<?php echo esc_url(home_url('/newcomers-to-canada/')); ?>">Read Full Guide</a>
                  </article>
                  <article class="mag-home-article-card">
                    <div class="mag-home-tag">Start here</div>
                    <h3>Start Here for Newcomers</h3>
                    <p>A simple starting point for immigrants learning how financial systems work in the USA and Canada.</p>
                    <a href="<?php echo esc_url(home_url('/start-here/')); ?>">Read Full Guide</a>
                  </article>
                </div>
              </div>
            </section>

            <section class="mag-home-section mag-home-alt-section">
              <div class="mag-home-shell">
                <div class="mag-home-section-heading">
                  <p class="mag-home-kicker">Why users choose MoneyAbroadGuide</p>
                  <h2>Built to save money, build trust, and drive action</h2>
                  <p>This experience is designed like a fintech platform, not a generic blog, so readers move faster from research to conversion.</p>
                </div>
                <div class="mag-home-benefits-grid">
                  <article class="mag-home-card"><h3>Save more on every transfer</h3><p>Compare real transfer fees and exchange rate margins in one place and avoid hidden costs that reduce what your recipient gets.</p></article>
                  <article class="mag-home-card"><h3>Make safer financial decisions</h3><p>Transparent provider comparisons and educational content create trust before users click through.</p></article>
                  <article class="mag-home-card"><h3>Convert faster with confidence</h3><p>A cleaner comparison flow helps users choose the strongest option for their route and urgency.</p></article>
                </div>
              </div>
            </section>

            <section class="mag-home-section">
              <div class="mag-home-shell">
                <div class="mag-home-story-card">
                  <div>
                    <p class="mag-home-kicker mag-home-kicker-light">Real savings story</p>
                    <h2>Ahmed saved $420 a year by switching transfer provider</h2>
                    <p>Ahmed was sending money home every month from the USA and assumed his usual provider was already competitive. After comparing fees, FX margins, and delivery times, he switched to a lower-cost option and kept hundreds of dollars each year.</p>
                    <div class="mag-home-actions mag-home-actions-left">
                      <a href="#calculator" class="mag-home-btn mag-home-btn-light">Compare Fees Now</a>
                      <a href="#trust" class="mag-home-btn mag-home-btn-ghost">See why users trust us</a>
                    </div>
                  </div>
                  <div class="mag-home-story-side">
                    <div class="mag-home-story-mini"><span>Before switching</span><strong>Higher fees + weak FX</strong><p>Monthly transfers looked fine on the surface, but hidden spread costs kept reducing the received amount.</p></div>
                    <div class="mag-home-story-mini"><span>After comparing</span><strong>$420/year saved</strong><p>A better provider meant stronger rates, lower total cost, and more money delivered every month.</p></div>
                  </div>
                </div>
              </div>
            </section>

            <section id="compare" class="mag-home-section mag-home-alt-section">
              <div class="mag-home-shell">
                <div class="mag-home-section-heading">
                  <p class="mag-home-kicker">Compare and convert</p>
                  <h2>Compare providers, reduce fees, and move money with more confidence</h2>
                  <p>This table is built to help users compare total value fast and click through only when the offer matches their route, urgency, and amount.</p>
                </div>
                <div class="mag-home-comparison-card">
                  <div class="mag-home-table-wrap">
                    <table class="mag-home-table mag-home-table-centered" aria-label="Full comparison table">
                      <thead>
                        <tr><th>Service</th><th>Fees</th><th>Speed</th><th>Exchange Rate</th><th>Rating</th><th>Action</th></tr>
                      </thead>
                      <tbody>
                        <tr><td>Wise</td><td>Low, transparent</td><td>Minutes to 2 days</td><td>Mid-market rate</td><td>4.9/5</td><td><a href="https://wise.com/" rel="nofollow sponsored" target="_blank">Compare Fees Now</a></td></tr>
                        <tr><td>Remitly</td><td>Promo-friendly</td><td>Express available</td><td>Competitive</td><td>4.8/5</td><td><a href="https://www.remitly.com/" rel="nofollow sponsored" target="_blank">Compare Fees Now</a></td></tr>
                        <tr><td>OFX</td><td>No fixed fee</td><td>1–3 days</td><td>Strong on large transfers</td><td>4.7/5</td><td><a href="https://www.ofx.com/" rel="nofollow sponsored" target="_blank">Compare Fees Now</a></td></tr>
                        <tr><td>Xe Money Transfer</td><td>Varies</td><td>Same day to 3 days</td><td>Live rate tools</td><td>4.6/5</td><td><a href="https://www.xe.com/" rel="nofollow sponsored" target="_blank">Compare Fees Now</a></td></tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="mag-home-center-cta"><a href="#calculator" class="mag-home-btn mag-home-btn-primary">Compare Fees Now</a></div>
              </div>
            </section>

            <section id="trust" class="mag-home-section">
              <div class="mag-home-shell">
                <div class="mag-home-section-heading">
                  <p class="mag-home-kicker">Built on transparency</p>
                  <h2>Financial authority that helps users trust the comparison</h2>
                  <p>We focus on real pricing, better clarity, and a more trustworthy user experience so people feel safe making money decisions here.</p>
                </div>
                <div class="mag-home-metrics-grid">
                  <article class="mag-home-metric-card"><strong>12,000+</strong><span>Expats helped</span></article>
                  <article class="mag-home-metric-card"><strong>$1.8M+</strong><span>Potential savings</span></article>
                  <article class="mag-home-metric-card"><strong>80+</strong><span>Providers reviewed</span></article>
                  <article class="mag-home-metric-card"><strong>Weekly</strong><span>Updated data</span></article>
                </div>
              </div>
            </section>

            <section class="mag-home-section">
              <div class="mag-home-shell">
                <div class="mag-home-final-cta">
                  <p class="mag-home-kicker mag-home-kicker-light">Ready to save more?</p>
                  <h2>Compare fees, protect your money, and choose a better transfer today</h2>
                  <p>MoneyAbroadGuide helps users avoid hidden markups, compare transfer rates faster, and move money with more confidence.</p>
                  <div class="mag-home-actions">
                    <a href="#calculator" class="mag-home-btn mag-home-btn-light">Compare Fees Now</a>
                    <a href="#blog" class="mag-home-btn mag-home-btn-ghost">Start Free</a>
                  </div>
                </div>
              </div>
            </section>
          </main>
        </div>
        <?php
        return ob_get_clean();
    }

    public function append_article_footer($content) {
        if (is_admin() || !is_singular('post') || !in_the_loop() || !is_main_query()) {
            return $content;
        }

        if (strpos($content, 'mag-author-footer-box') !== false) {
            return $content;
        }

        $footer = '<div class="mag-author-footer-box">'
            . '<h3>About Talal Eddaouahiri</h3>'
            . '<p>Talal Eddaouahiri is a financial advisor specialising in the financial systems of the United States and Canada. He founded Money Abroad Guide to provide honest, jargon-free guidance for immigrants, international students, and expats building their new lives in North America. With a focus on practical, real-world advice, Talal helps newcomers build their financial future — from opening a first bank account to understanding credit, taxes, and everyday money decisions — with confidence.</p>'
            . '<p class="mag-article-disclosure">This article may contain affiliate links. We may earn a commission at no extra cost to you. This does not influence our editorial assessments.</p>'
            . '<p class="mag-article-disclaimer">This content is for educational purposes only and should not be considered financial, legal, or tax advice.</p>'
            . '</div>';

        return $content . $footer;
    }
}

register_activation_hook(__FILE__, ['MAG_Dashboard_Preview_Homepage', 'activate']);
register_deactivation_hook(__FILE__, ['MAG_Dashboard_Preview_Homepage', 'deactivate']);
new MAG_Dashboard_Preview_Homepage();`;

const pluginCss = String.raw`#mag-restored-header-shell,
#mag-home-intro,
.site-header,
#masthead,
.main-header-bar,
.ast-above-header-wrap,
.ast-below-header-wrap,
.ast-desktop-header,
.ast-mobile-header-wrap,
.ast-theme-transparent-header,
header[role='banner'],
.ast-builder-menu,
.ast-builder-grid-row,
.site-branding,
.custom-logo-link,
.main-header-menu,
.site-footer,
.entry-header,
.entry-title,
.seo-autopilot-homepage-h1,
.entry-content > :not(.mag-home-root) {
  display: none !important;
}

.entry-content,
.site-content,
.ast-container,
#primary,
.content-area {
  width: 100% !important;
  max-width: 100% !important;
  margin: 0 !important;
  padding: 0 !important;
}

body {
  background: #f8fafc !important;
}

:root {
  --mag-primary: #16a34a;
  --mag-primary-dark: #166534;
  --mag-light: #f0fdf4;
  --mag-text: #0f172a;
  --mag-muted: #64748b;
  --mag-border: #e2e8f0;
  --mag-bg: #f8fafc;
}
*{box-sizing:border-box}body{margin:0}.mag-home-root{font-family:Inter,Arial,sans-serif;color:var(--mag-text);background:var(--mag-bg)}
.mag-home-page{display:flex;flex-direction:column;gap:0}.mag-home-shell{width:min(100%,920px);margin:0 auto;padding:0 16px}.mag-home-header{border-bottom:1px solid var(--mag-border);background:rgba(255,255,255,.92);backdrop-filter:blur(16px);position:sticky;top:0;z-index:40}.mag-home-header-inner{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:10px 0}.mag-home-logo-link{display:inline-flex;align-items:center}.mag-home-logo{width:320px;max-width:100%;height:auto;object-fit:contain}.mag-home-nav{display:none;gap:24px}.mag-home-nav a{text-decoration:none;color:#475569;font-weight:600}
.mag-home-hero{padding:8px 0 56px;background:radial-gradient(circle at top center, rgba(31,143,106,.12), transparent 32%),linear-gradient(180deg,#f8fafc 0%,#ffffff 72%);border-bottom:1px solid rgba(226,232,240,.8)}.mag-home-hero-inner{display:flex;flex-direction:column;align-items:center;text-align:center;gap:28px}.mag-home-pill,.mag-home-kicker{display:inline-flex;align-items:center;border-radius:999px;padding:10px 16px;font-size:14px;font-weight:600}.mag-home-pill{border:1px solid var(--mag-border);background:#fff;color:#475569;box-shadow:0 12px 28px rgba(15,23,42,.06)}.mag-home-kicker{padding:0;background:transparent;color:#16a34a;text-transform:uppercase;letter-spacing:.22em;font-size:12px;font-weight:700}.mag-home-kicker-light{color:rgba(255,255,255,.75)}
.mag-home-hero h1,.mag-home-section-heading h2,.mag-home-summary-card h2,.mag-home-final-cta h2,.mag-home-story-card h2{margin:0;font-weight:800;line-height:1.04;letter-spacing:-.03em;color:var(--mag-text)}.mag-home-hero h1{max-width:850px;font-size:clamp(2.6rem,5vw,4.1rem)}.mag-home-hero p,.mag-home-section-heading p,.mag-home-summary-card p,.mag-home-story-card p,.mag-home-final-cta p,.mag-home-card p,.mag-home-article-card p{color:var(--mag-muted);line-height:1.8}
.mag-home-actions{display:flex;flex-direction:column;gap:12px}.mag-home-actions-left{justify-content:flex-start}.mag-home-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 24px;border-radius:999px;text-decoration:none;font-weight:700;transition:all .2s ease}.mag-home-btn-primary{background:var(--mag-primary);color:#fff;box-shadow:0 16px 34px rgba(22,163,74,.22)}.mag-home-btn-primary:hover{background:var(--mag-primary-dark)}.mag-home-btn-secondary,.mag-home-btn-light{background:#fff;border:1px solid var(--mag-border);color:var(--mag-text)}.mag-home-btn-ghost{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.15);color:#fff}.mag-home-hide-mobile{display:none}
.mag-home-trust-row{display:flex;flex-wrap:wrap;justify-content:center;gap:12px}.mag-home-trust-pill{display:inline-flex;align-items:center;padding:8px 14px;border-radius:999px;border:1px solid var(--mag-border);background:#fff;color:#334155;font-size:14px;font-weight:600;box-shadow:0 8px 20px rgba(15,23,42,.05)}
.mag-home-steps-grid{display:grid;gap:12px;width:100%}.mag-home-step-card{border:1px solid var(--mag-border);background:#f8fafc;border-radius:18px;padding:16px;text-align:center}.mag-home-step-card strong{display:block;color:#0f172a}.mag-home-step-card span{display:block;margin-top:8px;color:var(--mag-muted);font-size:14px}.mag-home-step-card-last{max-width:260px;margin:0 auto}
.mag-home-summary-card,.mag-home-card,.mag-home-story-card,.mag-home-comparison-card,.mag-home-metric-card,.mag-home-article-card,.mag-home-final-cta{border:1px solid var(--mag-border);background:#fff;box-shadow:0 18px 45px rgba(15,23,42,.08)}.mag-home-summary-card{width:100%;padding:20px;border-radius:28px;text-align:left}.mag-home-left-heading{text-align:left}
.mag-home-table-wrap{overflow-x:auto}.mag-home-table{width:100%;min-width:760px;border-collapse:collapse}.mag-home-table th,.mag-home-table td{padding:14px 12px;border-bottom:1px solid var(--mag-border);text-align:left}.mag-home-table th{color:#64748b;font-size:13px}.mag-home-table td{color:#334155}.mag-home-table td:first-child{color:#0f172a;font-weight:700}.mag-home-table a{display:inline-flex;align-items:center;justify-content:center;padding:10px 14px;border-radius:999px;text-decoration:none;color:#fff;background:#16a34a;font-weight:700;font-size:12px}.mag-home-table-centered th,.mag-home-table-centered td{text-align:center}
.mag-home-highlight-grid,.mag-home-benefits-grid,.mag-home-metrics-grid,.mag-home-blog-grid{display:grid;gap:16px}.mag-home-highlight-grid{margin-top:16px}.mag-home-highlight{border-radius:18px;border:1px solid var(--mag-border);background:#f8fafc;padding:16px;text-align:center}.mag-home-highlight span,.mag-home-metric-card span{display:block;font-size:11px;text-transform:uppercase;letter-spacing:.14em;color:#64748b}.mag-home-highlight strong,.mag-home-metric-card strong{display:block;margin-top:8px;font-size:20px;font-weight:800;color:#0f172a}
.mag-home-section{padding:56px 0}.mag-home-alt-section{background:#fff}.mag-home-section-heading{max-width:780px;margin:0 auto 32px;text-align:center}.mag-home-benefits-grid,.mag-home-blog-grid{grid-template-columns:1fr}.mag-home-card{padding:28px;border-radius:24px;transition:transform .25s ease, box-shadow .25s ease, border-color .25s ease}.mag-home-card:hover,.mag-home-article-card:hover{transform:translateY(-4px) scale(1.01);border-color:rgba(148,163,184,.35);box-shadow:0 24px 55px rgba(15,23,42,.1)}.mag-home-card h3,.mag-home-article-card h3{margin:0;color:#0f172a;font-size:24px}
.mag-home-story-card,.mag-home-final-cta{border-radius:32px;padding:32px;color:#fff;background:linear-gradient(135deg,#0B1F3A 0%,#15304f 52%,#1F8F6A 100%)}.mag-home-story-card{display:grid;gap:24px}.mag-home-story-card h2,.mag-home-final-cta h2,.mag-home-story-card p,.mag-home-final-cta p{color:#fff}.mag-home-story-side{display:grid;gap:16px}.mag-home-story-mini{border-radius:24px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.08);padding:20px}.mag-home-story-mini span{display:block;color:rgba(255,255,255,.72);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.16em}.mag-home-story-mini strong{display:block;margin-top:12px;font-size:28px}
.mag-home-comparison-card{border-radius:28px;padding:0;overflow:hidden}.mag-home-center-cta{margin-top:24px;display:flex;justify-content:center}.mag-home-metrics-grid{grid-template-columns:1fr}.mag-home-metric-card{padding:24px;border-radius:24px;text-align:center}.mag-home-article-card{padding:28px;border-radius:28px}.mag-home-tag{display:inline-flex;width:fit-content;border-radius:999px;background:#EAF7F1;color:#1F8F6A;padding:6px 12px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.14em;margin-bottom:18px}.mag-home-article-card a{margin-top:24px;display:inline-flex;width:fit-content;align-items:center;padding:12px 20px;border-radius:999px;border:1px solid var(--mag-border);color:#0f172a;text-decoration:none;font-weight:700;background:#fff}.mag-author-footer-box{margin-top:32px;padding:22px;border:1px solid var(--mag-border);border-radius:20px;background:#f8fafc}.mag-author-footer-box h3{margin:0 0 12px;color:#0f172a;font-size:22px}.mag-author-footer-box p{margin:0 0 12px;line-height:1.8;color:#475569}.mag-author-footer-box p:last-child{margin-bottom:0}.mag-article-disclosure{font-weight:600}.mag-article-disclaimer{color:#64748b}
@media (min-width:900px){.mag-home-nav,.mag-home-hide-mobile{display:inline-flex}.mag-home-steps-grid,.mag-home-highlight-grid,.mag-home-metrics-grid{grid-template-columns:repeat(4,minmax(0,1fr))}.mag-home-blog-grid,.mag-home-benefits-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.mag-home-story-card{grid-template-columns:1.15fr .85fr;align-items:center}.mag-home-actions,.mag-home-actions-left{flex-direction:row;align-items:center}}
`;

const pluginJs = String.raw`document.addEventListener('DOMContentLoaded', function () {
  var selectors = [
    '#mag-restored-header-shell',
    '#mag-home-intro',
    '.site-header',
    '#masthead',
    '.main-header-bar',
    '.ast-above-header-wrap',
    '.ast-below-header-wrap',
    '.ast-desktop-header',
    '.ast-mobile-header-wrap',
    '.ast-theme-transparent-header',
    "header[role='banner']",
    '.ast-builder-menu',
    '.ast-builder-grid-row',
    '.site-branding',
    '.custom-logo-link',
    '.main-header-menu',
    '.site-footer',
    '.entry-header',
    '.entry-title',
    '.seo-autopilot-homepage-h1'
  ];
  selectors.forEach(function (selector) {
    document.querySelectorAll(selector).forEach(function (el) {
      if (el && !el.closest('.mag-home-root')) {
        el.remove();
      }
    });
  });
});`;

async function buildZip() {
  const zip = new JSZip();
  const folder = zip.folder('moneyabroadguide-dashboard-preview-homepage');
  folder.file('moneyabroadguide-dashboard-preview-homepage.php', pluginPhp);
  folder.file('style.css', pluginCss);
  folder.file('script.js', pluginJs);
  return await zip.generateAsync({ type: 'uint8array' });
}

Deno.serve(async (req) => {
  try {
    const zipContent = await buildZip();

    if (req.method === 'GET') {
      return new Response(zipContent, {
        status: 200,
        headers: {
          'Content-Type': 'application/zip',
          'Content-Disposition': 'attachment; filename="moneyabroadguide-dashboard-preview-homepage.zip"',
          'Cache-Control': 'no-store',
        },
      });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const zipFile = new File([zipContent], 'moneyabroadguide-dashboard-preview-homepage.zip', { type: 'application/zip' });
    const upload = await base44.asServiceRole.integrations.Core.UploadFile({ file: zipFile });

    return Response.json({
      success: true,
      file_name: 'moneyabroadguide-dashboard-preview-homepage.zip',
      folder_name: 'moneyabroadguide-dashboard-preview-homepage',
      files: ['moneyabroadguide-dashboard-preview-homepage.php', 'style.css', 'script.js'],
      file_url: upload.file_url,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});