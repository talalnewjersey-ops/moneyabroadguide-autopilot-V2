import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const stripHtml = (value = '') => String(value).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
const decodeHtml = (value = '') => String(value)
  .replace(/&amp;/g, '&')
  .replace(/&#8217;/g, "'")
  .replace(/&#8211;/g, '–')
  .replace(/&#8220;|&#8221;/g, '"')
  .replace(/&hellip;/g, '...')
  .replace(/&nbsp;/g, ' ');
const fallbackLogo = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/eeee75ce7_image.png';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const response = await fetch('https://moneyabroadguide.com/wp-json/wp/v2/posts?per_page=3&_embed');
    if (!response.ok) {
      return Response.json({ error: 'Unable to fetch posts' }, { status: 500 });
    }

    const items = await response.json();
    const posts = items.map((post) => {
      const featured = post?._embedded?.['wp:featuredmedia']?.[0];
      const image = featured?.source_url || fallbackLogo;
      const cleanTitle = decodeHtml(stripHtml(post.title?.rendered || 'Latest article'));
      const cleanExcerpt = decodeHtml(stripHtml(post.excerpt?.rendered || '')).replace(/\[\.\.\.\]\.\.\.|\[\.\.\.\]|\.\.\.\.*/g, '...').trim();
      return {
        id: post.id,
        title: cleanTitle,
        excerpt: cleanExcerpt.length > 145 ? `${cleanExcerpt.slice(0, 142).trim()}...` : cleanExcerpt,
        link: post.link,
        image,
        isLogoFallback: image === fallbackLogo,
      };
    });

    return Response.json({ success: true, posts });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});