import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';
import { Download, FileText, Play, RefreshCw } from 'lucide-react';

export default function SeoAutopilotCenter() {
  const queryClient = useQueryClient();
  const [loadingAction, setLoadingAction] = useState('');
  const { data: websites = [] } = useQuery({ queryKey: ['websites'], queryFn: () => base44.entities.Website.list('-created_date', 10) });
  const { data: projects = [] } = useQuery({ queryKey: ['projects'], queryFn: () => base44.entities.Project.list('-created_date', 10) });
  const { data: runs = [] } = useQuery({ queryKey: ['seo-autopilot-runs'], queryFn: () => base44.entities.SeoAutopilotRun.list('-created_date', 20) });

  const website = websites[0];
  const project = projects[0];

  const runAction = async (type, action) => {
    if (!website) return;
    setLoadingAction(type);
    if (type === 'daily') await base44.functions.invoke('runDailySeoAutomation', { site_url: website.url, api_key: website.wordpress_api_key });
    if (type === 'weekly') await base44.functions.invoke('runWeeklySeoAuditReport', { site_url: website.url });
    if (type === 'articles' && project) await base44.functions.invoke('generateSeoAutopilotArticles', { project_id: project.id, website_id: website.id });
    if (type === 'bundle') {
      const response = await fetch('/functions/downloadSeoAutopilotBundle', { method: 'GET' });
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'moneyabroadguide-seo-autopilot-bundle.zip';
      link.click();
      window.URL.revokeObjectURL(url);
    }
    await queryClient.invalidateQueries({ queryKey: ['seo-autopilot-runs'] });
    setLoadingAction('');
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="SEO Autopilot Center" description="Run the full patch-mode SEO system, generate content, and download the WordPress + GitHub automation bundle." />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {[
          { key: 'daily', title: 'Daily scan + fixes', icon: Play, label: 'Run daily autopilot' },
          { key: 'weekly', title: 'Weekly audit report', icon: RefreshCw, label: 'Run weekly audit' },
          { key: 'articles', title: 'Generate 5 articles', icon: FileText, label: 'Generate articles' },
          { key: 'bundle', title: 'Download WP + GitHub bundle', icon: Download, label: 'Download bundle' },
        ].map((item) => (
          <Card key={item.key}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base"><item.icon className="w-4 h-4" /> {item.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={() => runAction(item.key)} className="w-full rounded-xl">
                {loadingAction === item.key ? 'Running...' : item.label}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Latest reports</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {runs.map((run) => (
            <div key={run.id} className="rounded-xl border border-slate-200 p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="font-medium text-slate-900">{run.run_type} · {run.status}</p>
                  <p className="text-sm text-slate-500">{run.summary}</p>
                </div>
                <p className="text-xs text-slate-400">{new Date(run.created_date).toLocaleString()}</p>
              </div>
              {run.report_markdown && (
                <pre className="mt-3 whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-xs text-slate-700">{run.report_markdown}</pre>
              )}
            </div>
          ))}
          {runs.length === 0 && <p className="text-sm text-slate-500">No reports yet.</p>}
        </CardContent>
      </Card>
    </div>
  );
}