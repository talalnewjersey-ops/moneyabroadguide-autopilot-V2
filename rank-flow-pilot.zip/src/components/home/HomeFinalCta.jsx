import React from 'react';
import SectionReveal from '@/components/home/SectionReveal';

export default function HomeFinalCta() {
  return (
    <section className="final-cta border-y border-white/10 text-white">
      <SectionReveal className="mx-auto max-w-[920px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
        <div className="rounded-[32px] border border-white/10 bg-white/5 px-6 py-10 text-center shadow-[0_28px_70px_rgba(15,23,42,0.22)] backdrop-blur sm:px-10 sm:py-14">
          <p className="text-sm font-semibold uppercase tracking-[0.22em] text-white/75">Ready to save more?</p>
          <h2 className="mx-auto mt-3 max-w-3xl text-3xl font-extrabold tracking-tight sm:text-4xl lg:text-[2.9rem] lg:leading-[1.1]">Compare fees, protect your money, and choose a better transfer today</h2>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-8 text-white/80">
            MoneyAbroadGuide helps users avoid hidden markups, compare transfer rates faster, and move money with more confidence.
          </p>
          <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <a href="#calculator" className="inline-flex h-14 items-center justify-center rounded-full bg-white px-8 text-base font-semibold text-slate-950 shadow-[0_0_40px_rgba(255,255,255,0.18)] transition hover:bg-slate-100">
              Compare Fees Now
            </a>
            <a href="/HomePage#newcomers-usa" className="inline-flex h-14 items-center justify-center rounded-full border border-white/20 bg-white/10 px-8 text-base font-semibold text-white transition hover:bg-white/15">
              Start Free
            </a>
          </div>
        </div>
      </SectionReveal>
    </section>
  );
}