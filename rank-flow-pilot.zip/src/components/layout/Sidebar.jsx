import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  LayoutDashboard,
  Search,
  FileText,
  Key,
  Users,
  Link2,
  Shield,
  Zap,
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight,
  Globe,
  FileCode
} from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { name: 'Public Homepage', page: 'HomePage', icon: Globe, href: '/HomePage' },
  { name: 'Open Homepage Preview', page: 'HomePagePreview', icon: Link2, previewPath: '/HomePage', external: true },
  { name: 'Overview', page: 'Dashboard', icon: LayoutDashboard },
  { name: 'Workspace', page: 'WorkspaceDashboard', icon: LayoutDashboard },
  { name: 'Workspaces', page: 'Workspaces', icon: Users },
  { name: 'Projects', page: 'Projects', icon: FileText },
  { name: 'Project Overview', page: 'ProjectOverview', icon: BarChart3 },
  { name: 'Connect Website', page: 'ConnectWebsite', icon: Globe },
  { name: 'WordPress', page: 'WordPressConnection', icon: FileCode },
  { name: 'Site Audit', page: 'SiteAudit', icon: Search },
  { name: 'Audit Issues', page: 'AuditIssues', icon: Search },
  { name: 'Single Page', page: 'SinglePageOptimizer', icon: FileText },
  { name: 'Full Site', page: 'FullSiteOptimizer', icon: Zap },
  { name: 'Content Optimizer', page: 'ContentOptimizer', icon: FileText },
  { name: 'AI Content', page: 'AIContentAssistant', icon: FileText },
  { name: 'Article Generator', page: 'ArticleGenerator', icon: FileText },
  { name: 'Keyword Center', page: 'KeywordCenter', icon: Key },
  { name: 'Keyword Clusters', page: 'KeywordClusters', icon: Key },
  { name: 'Rank Tracking', page: 'RankTracking', icon: BarChart3 },
  { name: 'Competitors', page: 'Competitors', icon: Users },
  { name: 'Competitor Analysis', page: 'CompetitorAnalysis', icon: Users },
  { name: 'Internal Links', page: 'InternalLinks', icon: Link2 },
  { name: 'Backlinks', page: 'Backlinks', icon: Globe },
  { name: 'E-E-A-T', page: 'EEAT', icon: Shield },
  { name: 'Automations', page: 'Automations', icon: Zap },
  { name: 'Reports', page: 'Reports', icon: BarChart3 },
  { name: 'API Keys', page: 'APIKeys', icon: Key },
  { name: 'AI Settings', page: 'AISettings', icon: Settings },
  { name: 'Billing', page: 'BillingPlaceholder', icon: Settings },
  { name: 'Activity Logs', page: 'ActivityLogs', icon: FileText },
  { name: 'Applied Fixes', page: 'AppliedFixesHistory', icon: Shield },
  { name: 'Admin Console', page: 'AdminConsole', icon: Users },
  { name: 'Onboarding', page: 'Onboarding', icon: ChevronRight },
  { name: 'WordPress Plugin', page: 'WordPressPlugin', icon: FileCode },
  { name: 'Settings', page: 'AppSettings', icon: Settings },
];

export default function Sidebar({ currentPage, collapsed, setCollapsed }) {
  const homepagePreviewHref = typeof window !== 'undefined'
    ? `${window.location.origin}/HomePage${window.location.search || ''}`
    : '/HomePage';

  return (
    <aside className={cn(
      "fixed left-0 top-0 h-screen bg-[#0a0e1a] border-r border-white/5 z-50 transition-all duration-300 flex flex-col",
      collapsed ? "w-[68px]" : "w-[240px]"
    )}>
      <div className="h-16 flex items-center justify-between px-4 border-b border-white/5">
        {!collapsed && (
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="text-white font-semibold text-sm tracking-tight">AI SEO Autopilot</span>
          </div>
        )}
        {collapsed && (
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center mx-auto">
            <Zap className="w-4 h-4 text-white" />
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className={cn(
            "text-white/40 hover:text-white/80 transition-colors",
            collapsed && "hidden"
          )}
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      <nav className="flex-1 py-4 px-2 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = currentPage === item.page;
          const itemClasses = cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200 group",
            isActive
              ? "bg-blue-500/10 text-blue-400"
              : "text-white/50 hover:text-white/80 hover:bg-white/5"
          );

          if (item.external) {
            return (
              <a
                key={item.page}
                href={item.previewPath ? homepagePreviewHref : item.href}
                target="_blank"
                rel="noreferrer"
                className={itemClasses}
              >
                <item.icon className={cn("w-[18px] h-[18px] flex-shrink-0", isActive && "text-blue-400")} />
                {!collapsed && <span className="truncate">{item.name}</span>}
              </a>
            );
          }

          return (
            <Link
              key={item.page}
              to={item.href || createPageUrl(item.page)}
              className={itemClasses}
            >
              <item.icon className={cn("w-[18px] h-[18px] flex-shrink-0", isActive && "text-blue-400")} />
              {!collapsed && <span className="truncate">{item.name}</span>}
            </Link>
          );
        })}
      </nav>

      {collapsed && (
        <button
          onClick={() => setCollapsed(false)}
          className="p-3 text-white/30 hover:text-white/60 transition-colors border-t border-white/5"
        >
          <ChevronRight className="w-4 h-4 mx-auto" />
        </button>
      )}
    </aside>
  );
}