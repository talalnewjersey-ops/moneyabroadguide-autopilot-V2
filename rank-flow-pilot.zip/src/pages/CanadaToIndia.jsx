import React from 'react';
import SeoArticleLayout from '@/components/seo/SeoArticleLayout';
import { siloPages } from '@/lib/seoPages';

export default function CanadaToIndia() {
  return <SeoArticleLayout page={siloPages.CanadaToIndia} />;
}