import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const DEFAULT_ENDPOINT = 'https://moneyabroadguide.com/wp-json/mag-head/v1/script';
const DEFAULT_SITE_URL = 'https://moneyabroadguide.com/';
const WRITESONIC_SCRIPT = `<script src="https://seo-fixer.writesonic.com/site-audit/fixer-script/index.js" id="wsAiSeoMb"></script>
<script id="wsAiSeoInitScript">
  wsSEOfixer.configure({
    hostURL: 'https://seo-fixer.writesonic.com',
    siteID: '698b3972462c09142695aef9'
  });
</script>`;

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    const apiKey = payload.api_key;
    const endpoint = payload.endpoint || DEFAULT_ENDPOINT;
    const siteUrl = payload.site_url || DEFAULT_SITE_URL;
    const script = payload.script || WRITESONIC_SCRIPT;

    if (!apiKey) {
      return Response.json({ error: 'api_key is required' }, { status: 400 });
    }

    const updateResponse = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-mag-head-key': apiKey,
      },
      body: JSON.stringify({ script }),
    });

    const updateText = await updateResponse.text();
    let updateResult = {};
    try {
      updateResult = JSON.parse(updateText || '{}');
    } catch {
      updateResult = { raw_response: updateText };
    }

    if (!updateResponse.ok) {
      return Response.json({ error: updateResult.error || 'Remote update failed', details: updateResult }, { status: 500 });
    }

    const statusResponse = await fetch(endpoint);
    const statusText = await statusResponse.text();
    let statusResult = {};
    try {
      statusResult = JSON.parse(statusText || '{}');
    } catch {
      statusResult = { raw_response: statusText };
    }

    const homepageResponse = await fetch(siteUrl);
    const homepageHtml = await homepageResponse.text();
    const scriptDetected = homepageHtml.includes('wsAiSeoMb') && homepageHtml.includes('wsAiSeoInitScript');

    return Response.json({
      success: true,
      update: updateResult,
      status: statusResult,
      script_detected_on_homepage: scriptDetected,
      endpoint,
      site_url: siteUrl,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});