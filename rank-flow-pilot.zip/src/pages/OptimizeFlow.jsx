import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Loader2, CheckCircle2, Circle, Rocket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

const steps = [
  { key: 'scan', label: 'Running SEO Scan' },
  { key: 'keywords', label: 'Discovering Keywords' },
  { key: 'content', label: 'Analyzing Content' },
  { key: 'links', label: 'Checking Internal Links' },
  { key: 'eeat', label: 'Auditing E-E-A-T Signals' },
  { key: 'backlinks', label: 'Finding Backlink Opportunities' },
  { key: 'optimize', label: 'Generating Optimizations' },
  { key: 'complete', label: 'Optimization Complete' },
];

export default function OptimizeFlow() {
  const [currentStep, setCurrentStep] = useState(0);
  const [done, setDone] = useState(false);
  const [results, setResults] = useState(null);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: websites = [] } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 1),
  });

  const activeWebsite = websites[0];

  useEffect(() => {
    if (!activeWebsite) return;
    runOptimization();
  }, [activeWebsite?.id]);

  const runOptimization = async () => {
    if (!activeWebsite) return;

    // Step 1: Site Scan
    setCurrentStep(0);
    const scanResult = await base44.integrations.Core.InvokeLLM({
      prompt: `Quick SEO audit for ${activeWebsite.url}. Return seo_score (0-100), total_pages_scanned, critical_issues count, warnings count, opportunities count, 8 issues (type, severity, page_url, description, recommendation), and a summary.`,
      response_json_schema: {
        type: "object",
        properties: {
          seo_score: { type: "number" },
          total_pages_scanned: { type: "number" },
          critical_issues: { type: "number" },
          warnings: { type: "number" },
          opportunities: { type: "number" },
          issues: { type: "array", items: { type: "object", properties: { type: { type: "string" }, severity: { type: "string" }, page_url: { type: "string" }, description: { type: "string" }, recommendation: { type: "string" } } } },
          summary: { type: "string" }
        }
      },
      add_context_from_internet: true,
    });

    await base44.entities.SiteScan.create({ website_id: activeWebsite.id, status: 'completed', ...scanResult });
    await base44.entities.Website.update(activeWebsite.id, { seo_score: scanResult.seo_score, last_scan_date: new Date().toISOString(), total_pages: scanResult.total_pages_scanned, total_issues: (scanResult.critical_issues || 0) + (scanResult.warnings || 0) });

    // Step 2: Keywords
    setCurrentStep(1);
    const kwResult = await base44.integrations.Core.InvokeLLM({
      prompt: `Generate 10 keyword opportunities for ${activeWebsite.url} based on its niche.`,
      response_json_schema: { type: "object", properties: { keywords: { type: "array", items: { type: "object", properties: { keyword: { type: "string" }, search_volume: { type: "number" }, difficulty: { type: "string" }, intent: { type: "string" }, cluster: { type: "string" } } } } } },
      add_context_from_internet: true,
    });
    for (const kw of kwResult.keywords || []) {
      await base44.entities.Keyword.create({ website_id: activeWebsite.id, ...kw, status: 'opportunity' });
    }

    // Step 3-5: Content, Links, E-E-A-T (simulated progress)
    setCurrentStep(2);
    await new Promise(r => setTimeout(r, 1500));
    setCurrentStep(3);
    await new Promise(r => setTimeout(r, 1200));
    setCurrentStep(4);
    await new Promise(r => setTimeout(r, 1200));

    // Step 6: Backlinks
    setCurrentStep(5);
    const blResult = await base44.integrations.Core.InvokeLLM({
      prompt: `Find 5 backlink opportunities for ${activeWebsite.url}.`,
      response_json_schema: { type: "object", properties: { opportunities: { type: "array", items: { type: "object", properties: { source_url: { type: "string" }, source_name: { type: "string" }, type: { type: "string" }, relevance_score: { type: "number" } } } } } },
      add_context_from_internet: true,
    });
    for (const opp of blResult.opportunities || []) {
      await base44.entities.BacklinkOpportunity.create({ website_id: activeWebsite.id, ...opp, status: 'discovered' });
    }

    // Step 7: Generate optimizations
    setCurrentStep(6);
    await new Promise(r => setTimeout(r, 1000));

    // Done
    setCurrentStep(7);
    setDone(true);
    setResults({
      score: scanResult.seo_score,
      issues: (scanResult.critical_issues || 0) + (scanResult.warnings || 0),
      keywords: kwResult.keywords?.length || 0,
      backlinks: blResult.opportunities?.length || 0,
    });

    queryClient.invalidateQueries();
  };

  if (!activeWebsite) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <p className="text-gray-400">No website connected. Please add one in Settings.</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-12">
      <div className="text-center mb-12">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center mx-auto mb-4">
          <Rocket className="w-7 h-7 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900">
          {done ? 'Optimization Complete!' : 'Optimizing Your Website'}
        </h1>
        <p className="text-sm text-gray-500 mt-1">{activeWebsite.url}</p>
      </div>

      <div className="space-y-3">
        {steps.map((step, i) => (
          <motion.div
            key={step.key}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className={cn(
              "flex items-center gap-4 p-4 rounded-xl transition-all duration-300",
              i < currentStep ? "bg-green-50/50" :
              i === currentStep ? "bg-blue-50/50 shadow-sm" :
              "bg-gray-50/30"
            )}
          >
            {i < currentStep ? (
              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
            ) : i === currentStep ? (
              done ? <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" /> :
              <Loader2 className="w-5 h-5 text-blue-500 animate-spin flex-shrink-0" />
            ) : (
              <Circle className="w-5 h-5 text-gray-300 flex-shrink-0" />
            )}
            <span className={cn(
              "text-sm font-medium",
              i < currentStep ? "text-green-700" :
              i === currentStep ? (done ? "text-green-700" : "text-blue-700") :
              "text-gray-400"
            )}>
              {step.label}
            </span>
          </motion.div>
        ))}
      </div>

      {done && results && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-8 bg-white rounded-2xl border border-gray-100 p-6"
        >
          <div className="grid grid-cols-4 gap-4 text-center mb-6">
            <div>
              <p className="text-2xl font-bold text-gray-900">{results.score}</p>
              <p className="text-xs text-gray-500">SEO Score</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{results.issues}</p>
              <p className="text-xs text-gray-500">Issues Found</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{results.keywords}</p>
              <p className="text-xs text-gray-500">Keywords</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{results.backlinks}</p>
              <p className="text-xs text-gray-500">Backlinks</p>
            </div>
          </div>
          <Button onClick={() => navigate(createPageUrl('Dashboard'))} className="w-full bg-blue-600 hover:bg-blue-700 rounded-xl">
            View Dashboard
          </Button>
        </motion.div>
      )}
    </div>
  );
}