import React from 'react';
import SeoArticleLayout from '@/components/seo/SeoArticleLayout';
import { articlePages } from '@/lib/seoPages';

export default function BestWayToSendMoneyFromUsaToMorocco2026() {
  return <SeoArticleLayout page={articlePages.BestWayToSendMoneyFromUsaToMorocco2026} />;
}