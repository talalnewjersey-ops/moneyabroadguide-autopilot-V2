import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { BarChart3, Loader2, Sparkles, Download } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import PageHeader from '../components/common/PageHeader';
import EmptyState from '../components/common/EmptyState';

export default function Reports() {
  const [generating, setGenerating] = useState(false);
  const [report, setReport] = useState(null);

  const { data: websites = [] } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 1),
  });

  const activeWebsite = websites[0];

  const { data: pages = [] } = useQuery({
    queryKey: ['pages', activeWebsite?.id],
    queryFn: () => base44.entities.Page.filter({ website_id: activeWebsite.id }),
    enabled: !!activeWebsite,
  });

  const { data: keywords = [] } = useQuery({
    queryKey: ['keywords', activeWebsite?.id],
    queryFn: () => base44.entities.Keyword.filter({ website_id: activeWebsite.id }),
    enabled: !!activeWebsite,
  });

  const generateReport = async () => {
    if (!activeWebsite) return;
    setGenerating(true);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Generate a comprehensive SEO performance report for ${activeWebsite.url}.
      
      Current data:
      - SEO Score: ${activeWebsite.seo_score || 'Not scanned'}
      - Pages tracked: ${pages.length}
      - Keywords tracked: ${keywords.length}
      
      Generate a report with:
      - executive_summary (2-3 sentences)
      - key_metrics (array of {name, value, change})
      - top_priorities (array of strings, 5 most important actions)
      - content_status (object: {optimized, needs_work, pending} as numbers)
      - keyword_difficulty_distribution (object: {low, medium, high} as numbers)`,
      response_json_schema: {
        type: "object",
        properties: {
          executive_summary: { type: "string" },
          key_metrics: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                value: { type: "string" },
                change: { type: "string" }
              }
            }
          },
          top_priorities: { type: "array", items: { type: "string" } },
          content_status: {
            type: "object",
            properties: {
              optimized: { type: "number" },
              needs_work: { type: "number" },
              pending: { type: "number" }
            }
          },
          keyword_difficulty_distribution: {
            type: "object",
            properties: {
              low: { type: "number" },
              medium: { type: "number" },
              high: { type: "number" }
            }
          }
        }
      }
    });

    setReport(result);
    setGenerating(false);
  };

  if (!activeWebsite) {
    return <EmptyState icon={BarChart3} title="No website connected" description="Add a website in Settings first." />;
  }

  const COLORS = ['#22c55e', '#f59e0b', '#94a3b8'];

  const contentData = report?.content_status ? [
    { name: 'Optimized', value: report.content_status.optimized },
    { name: 'Needs Work', value: report.content_status.needs_work },
    { name: 'Pending', value: report.content_status.pending },
  ] : [];

  const kwData = report?.keyword_difficulty_distribution ? [
    { name: 'Low', value: report.keyword_difficulty_distribution.low },
    { name: 'Medium', value: report.keyword_difficulty_distribution.medium },
    { name: 'High', value: report.keyword_difficulty_distribution.high },
  ] : [];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader
        title="Reports"
        description="SEO performance reports and analytics"
        action={
          <Button onClick={generateReport} disabled={generating} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
            {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {generating ? 'Generating...' : 'Generate Report'}
          </Button>
        }
      />

      {!report ? (
        <EmptyState icon={BarChart3} title="No reports generated" description="Generate an AI-powered SEO performance report." action="Generate Report" onAction={generateReport} />
      ) : (
        <>
          <div className="bg-white rounded-2xl border border-gray-100 p-6">
            <h3 className="font-semibold text-gray-900 mb-2">Executive Summary</h3>
            <p className="text-sm text-gray-600 leading-relaxed">{report.executive_summary}</p>
          </div>

          {report.key_metrics?.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {report.key_metrics.map((m, i) => (
                <Card key={i}>
                  <CardContent className="p-4 text-center">
                    <p className="text-2xl font-bold text-gray-900">{m.value}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{m.name}</p>
                    {m.change && <p className="text-xs text-green-600 mt-1">{m.change}</p>}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {contentData.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Content Status</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={contentData} cx="50%" cy="50%" outerRadius={70} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                      {contentData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
            {kwData.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Keyword Difficulty</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={kwData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Bar dataKey="value" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          {report.top_priorities?.length > 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Top Priorities</h3>
              <div className="space-y-2">
                {report.top_priorities.map((p, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-gray-50/50">
                    <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold flex-shrink-0">{i + 1}</span>
                    <p className="text-sm text-gray-700">{p}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}