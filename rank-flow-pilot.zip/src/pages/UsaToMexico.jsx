import React from 'react';
import CorridorLandingPage from '@/components/transfers/CorridorLandingPage';
import { transferCorridors } from '@/lib/transferCorridors';

export default function UsaToMexico() {
  return <CorridorLandingPage page={transferCorridors.UsaToMexico} />;
}