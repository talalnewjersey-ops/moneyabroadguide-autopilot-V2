import React from 'react';

const logoUrl = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/7807cf1df_logoMoneyabroadGuide.jpeg';
const menuItems = [
  { label: 'Home', href: '/' },
  { label: 'Start Here', href: '/start-here/' },
  { label: 'Canada', href: '/newcomers-to-canada/' },
  { label: 'USA', href: '/newcomers-to-the-usa/' },
  { label: 'Transfers', href: '/best-money-transfer-apps-immigrants/' },
  { label: 'About', href: '/about' },
];

export default function HomeHeader() {
  return (
    <>
      <div className="bg-[#001F3F] px-4 py-2 text-[11px] text-white/70 sm:px-6 lg:px-8">
        <div className="mx-auto flex max-w-[1300px] flex-col items-center justify-between gap-2 sm:flex-row">
          <div className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
            <span className="rounded-full bg-white/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-white">Educational Resource</span>
            <span>All content is for informational purposes only.</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="/about" className="transition hover:text-white">About</a>
            <a href="/contact" className="transition hover:text-white">Contact</a>
            <a href="/privacy-policy" className="transition hover:text-white">Privacy</a>
          </div>
        </div>
      </div>
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,31,63,0.05)]">
        <div className="mx-auto flex max-w-[1300px] items-center gap-6 px-4 py-3 sm:px-6 lg:px-8">
          <a href="/" className="flex shrink-0 items-center">
            <img src={logoUrl} alt="MoneyAbroadGuide" className="h-12 w-auto sm:h-14" />
          </a>

          <nav className="hidden flex-1 items-center gap-6 lg:flex">
            {menuItems.map((item) => (
              <a key={item.label} href={item.href} className="text-[13px] font-semibold text-slate-700 transition hover:text-[#05825F]">
                {item.label}
              </a>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-3">
            <a href="#newsletter" className="hidden rounded-lg border border-slate-300 px-4 py-2 text-sm font-bold text-[#001F3F] transition hover:bg-slate-50 sm:inline-flex">
              Free Newsletter
            </a>
            <a href="#calculator" className="cta-primary h-11 px-5 text-sm">
              Compare Fees
            </a>
          </div>
        </div>
      </header>
    </>
  );
}