import React from 'react';
import { cn } from '@/lib/utils';

export default function MetricCard({ title, value, subtitle, icon: Icon, trend, color = 'blue' }) {
  const colorMap = {
    blue: 'from-blue-500/10 to-blue-500/5 text-blue-600',
    green: 'from-green-500/10 to-green-500/5 text-green-600',
    amber: 'from-amber-500/10 to-amber-500/5 text-amber-600',
    red: 'from-red-500/10 to-red-500/5 text-red-600',
    purple: 'from-purple-500/10 to-purple-500/5 text-purple-600',
    cyan: 'from-cyan-500/10 to-cyan-500/5 text-cyan-600',
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-5 hover:shadow-md transition-shadow duration-300">
      <div className="flex items-start justify-between mb-4">
        <div className={cn("w-10 h-10 rounded-xl bg-gradient-to-br flex items-center justify-center", colorMap[color])}>
          {Icon && <Icon className="w-5 h-5" />}
        </div>
        {trend && (
          <span className={cn(
            "text-xs font-medium px-2 py-0.5 rounded-full",
            trend > 0 ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"
          )}>
            {trend > 0 ? '+' : ''}{trend}%
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
      <p className="text-sm text-gray-500 mt-0.5">{title}</p>
      {subtitle && <p className="text-xs text-gray-400 mt-1">{subtitle}</p>}
    </div>
  );
}