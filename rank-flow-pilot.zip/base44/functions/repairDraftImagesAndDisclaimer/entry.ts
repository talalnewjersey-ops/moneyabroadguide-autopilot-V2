import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const GRID_IMAGE_1 = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/bac797316_generated_image.png';
const GRID_IMAGE_2 = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/01880b115_generated_image.png';
const GRID_IMAGE_3 = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/294ed020d_generated_image.png';
const GRID_IMAGE_4 = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/8e0bc9686_generated_image.png';
const HERO_IMAGE_URL = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/94bfdae77_generated_image.png';
const CHART_IMAGE_URL = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/e7e8908b5_generated_image.png';

const DISCLAIMER_HTML = '<div style="margin:32px 0 24px;padding:18px 20px;border-radius:16px;background:#fff7ed;border:1px solid #fdba74;"><strong>Disclaimer:</strong> The information in this article is for educational purposes only and should not be considered financial, legal, or tax advice. Readers should consult qualified professionals before making financial decisions.</div>';

const toText = (value = '') => typeof value === 'string' ? value : value == null ? '' : String(value);

const buildFigure = (src, alt, caption) => `<figure style="margin:28px 0;"><img src="${src}" alt="${alt}" style="width:100%;height:auto;display:block;border-radius:18px;" /><figcaption style="margin-top:8px;font-size:14px;color:#64748b;">${caption}</figcaption></figure>`;

const extractImageSources = (html = '') => {
  const matches = [...String(html).matchAll(/<img[^>]+src=["']([^"']+)["']/gi)];
  return matches.map((match) => match[1]);
};

const auditImage = async (url) => {
  try {
    const response = await fetch(url);
    return {
      url,
      ok: response.ok,
      status: response.status,
      content_type: response.headers.get('content-type') || '',
      visible: response.ok && (response.headers.get('content-type') || '').startsWith('image/'),
    };
  } catch (error) {
    return {
      url,
      ok: false,
      status: 0,
      content_type: '',
      visible: false,
      error: error.message,
    };
  }
};

const cleanArticleHtml = (html = '') => {
  let cleaned = String(html)
    .replaceAll('https://source.unsplash.com/featured/1200x800/?banking', GRID_IMAGE_1)
    .replaceAll('https://source.unsplash.com/featured/1200x800/?immigrant,family', GRID_IMAGE_2)
    .replaceAll('https://source.unsplash.com/featured/1200x800/?student,finance', GRID_IMAGE_3)
    .replaceAll('https://source.unsplash.com/featured/1200x800/?money,planning', GRID_IMAGE_4)
    .replaceAll('/images/hero-bank.jpg', HERO_IMAGE_URL)
    .replaceAll('/images/market-analysis-graph.jpg', CHART_IMAGE_URL)
    .replace(/<div class="article-image-grid">[\s\S]*?<\/div>/i, '')
    .replace(/<img[^>]*>/gi, '')
    .replace(/<p>Image caption:[\s\S]*?<\/p>/gi, '')
    .replace(/<div style="margin:32px 0 24px;padding:18px 20px;border-radius:16px;background:#fff7ed;border:1px solid #fdba74;">[\s\S]*?<\/div>/gi, '')
    .replace(/<p><strong>Disclaimer:<\/strong>[\s\S]*?<\/p>/gi, '')
    .replace(/<h2 id="conclusion">Conclusion<\/h2>[\s\S]*?<section>\s*<h2>Real Story: Maria and Ahmed Starting Fresh<\/h2>/i, '<section>\n  <h2>Real Story: Maria and Ahmed Starting Fresh</h2>')
    .replace(/<section>\s*<h2>Conclusion<\/h2>[\s\S]*?<\/section>\s*$/i, '');

  cleaned = cleaned.replace(
    /(<h1>Best Banks for Newcomers to Canada in 2026<\/h1>\s*<p>[\s\S]*?<\/p>)/i,
    `$1\n${buildFigure(HERO_IMAGE_URL, 'Newcomers visiting a Canadian bank branch', 'A practical look at banking options for newcomers to Canada.')}`
  );

  cleaned = cleaned.replace(
    /(<h2 id="market-analysis">Market Analysis<\/h2>\s*<p>[\s\S]*?<\/p>)/i,
    `$1\n${buildFigure(CHART_IMAGE_URL, 'Digital banking trends in Canada', 'Digital banking continues to shape how newcomers choose their first bank account in Canada.')}`
  );

  cleaned = cleaned.replace(
    /(<h2 id="top-banks">Top Banks for Newcomers<\/h2>\s*<p>[\s\S]*?<\/p>)/i,
    `$1\n${buildFigure(GRID_IMAGE_2, 'Immigrant family reviewing bank options in Canada', 'Comparing branch access, fees, and newcomer packages helps families choose more confidently.')}`
  );

  cleaned = cleaned.replace(
    /(<h2 id="practical-tips">Practical Tips<\/h2>\s*<ul>[\s\S]*?<\/ul>)/i,
    `$1\n${buildFigure(GRID_IMAGE_4, 'Budget planning for new arrivals in Canada', 'Simple budgeting and account alerts can make the first months in Canada much easier.')}`
  );

  cleaned = cleaned.replace(
    /(<section>\s*<h2>Real Story: Maria and Ahmed Starting Fresh<\/h2>\s*<p>[\s\S]*?<\/p>)/i,
    `$1\n${buildFigure(GRID_IMAGE_3, 'Newcomers organizing their finances', 'Real newcomer stories often begin with the simple step of opening the right bank account.')}`
  );

  cleaned = cleaned.trim();
  return `${cleaned}\n${DISCLAIMER_HTML}\n<section>\n  <h2>Conclusion</h2>\n  <p>For newcomers, the best bank is not always the biggest bank. The right choice is the one that makes daily life easier, keeps fees under control, supports your first months in Canada, and helps you build long-term financial stability. Comparing practical features, asking the right questions, and understanding the fine print can save both money and stress.</p>\n</section>`;
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'repairDraftImagesAndDisclaimer', required_fields: ['draft_id'], optional_fields: ['connection_id'] });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.draft_id) {
      return Response.json({ error: 'draft_id is required' }, { status: 400 });
    }

    const draft = await base44.asServiceRole.entities.ContentDraft.get(payload.draft_id);
    if (!draft) {
      return Response.json({ error: 'Draft not found' }, { status: 404 });
    }

    const sourceHtml = draft.html_file_url ? await (await fetch(draft.html_file_url)).text() : (draft.html_content || '');
    const html = cleanArticleHtml(sourceHtml);

    const htmlFile = new File([html], `${toText(draft.slug || draft.title || 'draft')}-repaired.html`, { type: 'text/html' });
    const upload = await base44.asServiceRole.integrations.Core.UploadFile({ file: htmlFile });

    await base44.asServiceRole.entities.ContentDraft.update(draft.id, {
      html_content: html.slice(0, 12000),
      html_file_url: upload.file_url,
    });

    const connections = payload.connection_id
      ? [await base44.asServiceRole.entities.WordPressConnection.get(payload.connection_id)].filter(Boolean)
      : await base44.asServiceRole.entities.WordPressConnection.filter({ project_id: draft.project_id }, '-created_date', 1);

    let connection = connections[0];
    if (!connection?.site_url) {
      const websites = await base44.asServiceRole.entities.Website.filter({ project_id: draft.project_id }, '-created_date', 1);
      const website = websites[0];
      if (website?.url && website?.wordpress_api_url && website?.wordpress_api_key) {
        connection = {
          site_url: website.url,
          rest_url: website.wordpress_api_url,
          api_key: website.wordpress_api_key,
        };
      }
    }

    if (!connection?.site_url) {
      return Response.json({ error: 'WordPress connection not found.' }, { status: 404 });
    }

    const endpointBase = `${connection.rest_url || connection.site_url}`.replace(/\/$/, '').replace(/\/wp-json$/, '');
    const endpoint = endpointBase + '/wp-json/ai-seo-autopilot/v1/push-draft';
    const wpResponse = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-ai-seo-autopilot-key': connection.api_key,
      },
      body: JSON.stringify({
        title: draft.title,
        slug: draft.slug,
        excerpt: draft.excerpt,
        content: html,
        meta_title: draft.meta_title,
        meta_description: draft.meta_description,
        faq_html: draft.faq_html,
        schema_markup: draft.schema_markup,
      })
    });

    const rawText = await wpResponse.text();
    let wordpress = {};
    try {
      wordpress = JSON.parse(rawText || '{}');
    } catch {
      wordpress = { raw_response: rawText };
    }

    if (!wpResponse.ok) {
      return Response.json({ error: wordpress.error || 'WordPress rejected the draft push.', details: wordpress }, { status: 500 });
    }

    const imageSources = extractImageSources(html);
    const imageAudit = [];
    for (const src of imageSources) {
      imageAudit.push(await auditImage(src));
    }

    return Response.json({
      success: true,
      draft_id: draft.id,
      wordpress,
      fixes: {
        single_conclusion: true,
        disclaimer_position: 'before_final_conclusion',
        distributed_images: true,
      },
      image_audit: imageAudit,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});