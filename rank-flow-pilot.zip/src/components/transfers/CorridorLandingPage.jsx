import React from 'react';
import { CheckCircle2, Shield, Zap } from 'lucide-react';
import HomeHeader from '@/components/home/HomeHeader';
import HomeFooter from '@/components/home/HomeFooter';
import HomeFinalCta from '@/components/home/HomeFinalCta';
import StickyCompareBar from '@/components/home/StickyCompareBar';
import SectionReveal from '@/components/home/SectionReveal';
import SectionHeading from '@/components/home/SectionHeading';
import SeoMeta from '@/components/seo/SeoMeta';
import SeoFaq from '@/components/seo/SeoFaq';
import SeoFaqSchema from '@/components/seo/SeoFaqSchema';
import CorridorComparison from '@/components/transfers/CorridorComparison';
import CorridorCalculator from '@/components/transfers/CorridorCalculator';

export default function CorridorLandingPage({ page }) {
  const benefitIcons = [CheckCircle2, Zap, Shield];

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-950">
      <SeoMeta title={page.title} description={page.description} />
      <SeoFaqSchema items={page.faqs} />
      <HomeHeader />

      <section className="hero border-b border-slate-200/70">
        <SectionReveal className="mx-auto max-w-[980px] px-4 pb-10 pt-0 sm:px-6 sm:pb-14 lg:px-8 lg:pb-16">
          <div className="flex flex-col items-center text-center">
            <div className="inline-flex items-center rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 shadow-sm">
              {page.keyword} • {page.urgency}
            </div>
            <h1 className="mt-6 max-w-4xl text-4xl font-extrabold tracking-tight text-[#0F172A] sm:text-5xl lg:text-[60px] lg:leading-[1.02]">
              {page.headline}
            </h1>
            <p className="mt-5 max-w-3xl text-lg leading-8 text-slate-500 sm:text-xl">
              {page.subheadline}
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href="#calculator" className="cta-primary h-14 px-8 text-base">Compare Now</a>
              <a href="#compare" className="inline-flex h-14 items-center justify-center rounded-full border border-slate-200 bg-white px-8 text-base font-semibold text-slate-900 shadow-[0_10px_24px_rgba(15,23,42,0.05)] transition hover:border-slate-300 hover:bg-slate-50">See Best Rates</a>
            </div>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              {page.trustBadges.map((badge) => (
                <div key={badge} className="trust-pill">{badge}</div>
              ))}
            </div>
          </div>
        </SectionReveal>
      </section>

      <CorridorComparison
        title={`Compare the best providers for ${page.corridorLabel}`}
        description={`Review pricing, speed, exchange rate quality, and payout fit before sending money from ${page.corridorLabel}.`}
        services={page.services}
      />

      <CorridorCalculator
        services={page.services}
        toCountry={page.toCountry}
        receiveCurrency={page.receiveCurrency}
        currencySymbol={page.currencySymbol}
        urgency={page.urgency}
      />

      <section className="bg-white">
        <SectionReveal className="mx-auto max-w-[980px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
          <SectionHeading
            eyebrow="Why compare first"
            title={`Why compare money transfer services for ${page.corridorLabel}?`}
            description="This section is built to improve conversion, trust, and ranking with cleaner fintech-style explanations."
          />

          <div className="grid gap-6 md:grid-cols-3">
            {page.benefits.map((item, index) => {
              const Icon = benefitIcons[index % benefitIcons.length];
              return (
                <div key={item.title} className="fintech-card fintech-card-hover p-7 text-center">
                  <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#EAF7F1] text-[#1F8F6A]">
                    <Icon className="h-6 w-6" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-950">{item.title}</h2>
                  <p className="mt-3 text-base leading-7 text-slate-500">{item.description}</p>
                </div>
              );
            })}
          </div>
        </SectionReveal>
      </section>

      <section className="bg-white">
        <SectionReveal className="mx-auto max-w-[980px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
          <div className="space-y-5">
            {page.sections.map((section) => (
              <article key={section.title} className="fintech-card p-6 sm:p-8">
                <h2 className="text-3xl font-bold tracking-tight text-slate-950 text-center">{section.title}</h2>
                <div className="mt-4 space-y-4">
                  {section.paragraphs.map((paragraph, idx) => (
                    <p key={idx} className="text-base leading-8 text-slate-600">{paragraph}</p>
                  ))}
                </div>
                {section.bullets?.length ? (
                  <ul className="mt-5 space-y-3">
                    {section.bullets.map((bullet) => (
                      <li key={bullet} className="flex gap-3 text-base leading-7 text-slate-600">
                        <CheckCircle2 className="mt-1 h-5 w-5 flex-shrink-0 text-[#1F8F6A]" />
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>
                ) : null}
              </article>
            ))}
          </div>
        </SectionReveal>
      </section>

      <section className="bg-[#F8FAFC]">
        <SectionReveal className="mx-auto max-w-[980px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
          <SectionHeading
            eyebrow="Internal linking"
            title="Keep exploring related money transfer routes"
            description="These internal links help with SEO clustering and keep users in a high-intent comparison flow."
          />
          <div className="grid gap-5 md:grid-cols-4">
            <a href="/UsaToMexico" className="fintech-card fintech-card-hover rounded-[24px] p-6 transition"><p className="text-lg font-semibold text-slate-950">USA to Mexico</p><p className="mt-3 text-sm leading-7 text-slate-500">See the best transfer options for Mexico.</p></a>
            <a href="/UsaToIndia" className="fintech-card fintech-card-hover rounded-[24px] p-6 transition"><p className="text-lg font-semibold text-slate-950">USA to India</p><p className="mt-3 text-sm leading-7 text-slate-500">Compare fees, rates, and speed for India.</p></a>
            <a href="/UsaToMorocco" className="fintech-card fintech-card-hover rounded-[24px] p-6 transition"><p className="text-lg font-semibold text-slate-950">USA to Morocco</p><p className="mt-3 text-sm leading-7 text-slate-500">Review the best options for Morocco transfers.</p></a>
            <a href="/UsaToPakistan" className="fintech-card fintech-card-hover rounded-[24px] p-6 transition"><p className="text-lg font-semibold text-slate-950">USA to Pakistan</p><p className="mt-3 text-sm leading-7 text-slate-500">Explore trusted providers for Pakistan.</p></a>
          </div>
        </SectionReveal>
      </section>

      <section id="faq" className="bg-white">
        <SectionReveal className="mx-auto max-w-[980px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
          <SectionHeading
            eyebrow="FAQ"
            title={`Frequently asked questions about ${page.keyword}`}
            description="These answers help users and search engines understand the route, trade-offs, and best next action."
          />
          <SeoFaq items={page.faqs} />
        </SectionReveal>
      </section>

      <HomeFinalCta />
      <HomeFooter />

      <a href="#calculator" className="fixed bottom-4 left-4 right-4 z-50 inline-flex h-14 items-center justify-center rounded-full bg-[#1F8F6A] px-6 text-base font-semibold text-white shadow-[0_18px_40px_rgba(31,143,106,0.28)] transition hover:bg-[#187255] md:hidden">Compare Fees Now</a>
      <StickyCompareBar />
    </div>
  );
}