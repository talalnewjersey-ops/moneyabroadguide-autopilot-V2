import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Globe, Plus, Trash2, Loader2, Check } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import { toast } from 'sonner';

export default function AppSettings() {
  const [newSite, setNewSite] = useState({ name: '', url: '', wordpress_api_url: '', wordpress_api_key: '' });
  const [showForm, setShowForm] = useState(false);
  const queryClient = useQueryClient();

  const { data: websites = [], isLoading } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Website.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['websites'] });
      setNewSite({ name: '', url: '', wordpress_api_url: '', wordpress_api_key: '' });
      setShowForm(false);
      toast.success('Website added successfully');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Website.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['websites'] });
      toast.success('Website removed');
    },
  });

  const handleAdd = () => {
    if (!newSite.name || !newSite.url) return;
    let url = newSite.url;
    if (!url.startsWith('http')) url = 'https://' + url;
    createMutation.mutate({ ...newSite, url, status: 'connected' });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <PageHeader
        title="Settings"
        description="Manage your websites and integrations"
        action={
          <Button onClick={() => setShowForm(true)} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
            <Plus className="w-4 h-4" /> Add Website
          </Button>
        }
      />

      {showForm && (
        <Card className="border-blue-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Add New Website</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-gray-500">Website Name</Label>
                <Input
                  placeholder="My Blog"
                  value={newSite.name}
                  onChange={e => setNewSite({ ...newSite, name: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-xs text-gray-500">Website URL</Label>
                <Input
                  placeholder="https://example.com"
                  value={newSite.url}
                  onChange={e => setNewSite({ ...newSite, url: e.target.value })}
                  className="mt-1"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-gray-500">WordPress REST API URL (optional)</Label>
                <Input
                  placeholder="https://example.com/wp-json/wp/v2"
                  value={newSite.wordpress_api_url}
                  onChange={e => setNewSite({ ...newSite, wordpress_api_url: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-xs text-gray-500">WordPress API Key (optional)</Label>
                <Input
                  placeholder="wp_xxxx..."
                  value={newSite.wordpress_api_key}
                  onChange={e => setNewSite({ ...newSite, wordpress_api_key: e.target.value })}
                  className="mt-1"
                />
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setShowForm(false)} className="rounded-xl">Cancel</Button>
              <Button onClick={handleAdd} disabled={createMutation.isPending} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
                {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                Save
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-5 h-5 animate-spin text-gray-400" /></div>
        ) : websites.length === 0 ? (
          <div className="text-center py-12 text-gray-400 text-sm">No websites added yet.</div>
        ) : (
          websites.map(site => (
            <Card key={site.id} className="hover:shadow-sm transition-shadow">
              <CardContent className="p-5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                  <Globe className="w-5 h-5 text-blue-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-900 text-sm">{site.name}</p>
                  <p className="text-xs text-gray-400 truncate">{site.url}</p>
                </div>
                <Badge variant="secondary" className={
                  site.status === 'connected' ? 'bg-green-50 text-green-700' : 'bg-gray-50 text-gray-500'
                }>
                  {site.status}
                </Badge>
                <Button
                  variant="ghost" size="icon"
                  onClick={() => deleteMutation.mutate(site.id)}
                  className="text-gray-400 hover:text-red-500"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}