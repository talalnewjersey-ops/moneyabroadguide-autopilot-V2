import React from 'react';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, AlertCircle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

const severityConfig = {
  critical: { icon: AlertCircle, color: 'bg-red-50 text-red-700 border-red-200', dot: 'bg-red-500' },
  warning: { icon: AlertTriangle, color: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-500' },
  info: { icon: Info, color: 'bg-blue-50 text-blue-700 border-blue-200', dot: 'bg-blue-500' },
};

export default function IssuesList({ issues = [] }) {
  if (!issues.length) {
    return (
      <div className="text-center py-12 text-gray-400">
        <p className="text-sm">No issues found. Run a scan to detect SEO problems.</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {issues.slice(0, 8).map((issue, i) => {
        const config = severityConfig[issue.severity] || severityConfig.info;
        const Icon = config.icon;
        return (
          <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-gray-50/50 hover:bg-gray-50 transition-colors">
            <div className={cn("w-2 h-2 rounded-full mt-2 flex-shrink-0", config.dot)} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-800 truncate">{issue.description}</p>
              {issue.page_url && (
                <p className="text-xs text-gray-400 mt-0.5 truncate">{issue.page_url}</p>
              )}
            </div>
            <Badge variant="secondary" className={cn("text-[10px] flex-shrink-0", config.color)}>
              {issue.severity}
            </Badge>
          </div>
        );
      })}
    </div>
  );
}