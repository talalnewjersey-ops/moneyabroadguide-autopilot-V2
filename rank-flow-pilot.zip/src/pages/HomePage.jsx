import React from 'react';
import HomeHeader from '@/components/home/HomeHeader';
import HomeHero from '@/components/home/HomeHero';
import HomeTrust from '@/components/home/HomeTrust';
import HomeComparison from '@/components/home/HomeComparison';
import HomeBlogPreview from '@/components/home/HomeBlogPreview';
import HomeGuideCards from '@/components/home/HomeGuideCards';
import HomeInteractiveHub from '@/components/home/HomeInteractiveHub';
import HomeWhyTrust from '@/components/home/HomeWhyTrust';
import HomeStory from '@/components/home/HomeStory';
import HomeFinalCta from '@/components/home/HomeFinalCta';
import HomeFooter from '@/components/home/HomeFooter';
import StickyCompareBar from '@/components/home/StickyCompareBar';

export default function HomePage() {
  return (
    <div id="top" className="min-h-screen bg-[#F8FAFC] text-foreground">
      <HomeHeader />
      <HomeHero />
      <HomeBlogPreview />
      <HomeGuideCards />
      <HomeInteractiveHub />
      <HomeWhyTrust />
      <HomeStory />
      <HomeComparison />
      <HomeTrust />
      <HomeFinalCta />
      <HomeFooter />
      <StickyCompareBar />
    </div>
  );
}