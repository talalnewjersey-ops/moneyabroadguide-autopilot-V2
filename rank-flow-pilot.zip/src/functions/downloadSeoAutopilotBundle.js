import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';
import JSZip from 'npm:jszip@3.10.1';

const pluginPhp = `<?php
/**
 * Plugin Name: MoneyAbroadGuide SEO Autopilot
 * Description: Safe patch-mode SEO maintenance helpers for MoneyAbroadGuide.com.
 * Version: 2.0.0
 */

if (!defined('ABSPATH')) exit;

function mag_seo_autopilot_org_schema() {
    if (!is_front_page()) return;
    $schema = array(
        '@context' => 'https://schema.org',
        '@type' => 'Organization',
        'name' => 'Money Abroad Guide',
        'url' => 'https://moneyabroadguide.com',
        'founder' => 'Talal Eddaouahiri',
        'description' => 'Free financial guides for newcomers to Canada & USA'
    );
    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}

function mag_seo_autopilot_person_schema() {
    if (!is_page('about')) return;
    $schema = array(
        '@context' => 'https://schema.org',
        '@type' => 'Person',
        'name' => 'Talal Eddaouahiri',
        'url' => 'https://moneyabroadguide.com/about/',
        'jobTitle' => 'Founder',
        'description' => 'Founder of Money Abroad Guide, focused on finance for newcomers.'
    );
    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}

add_action('wp_head', 'mag_seo_autopilot_org_schema');
add_action('wp_head', 'mag_seo_autopilot_person_schema');
`;

const dailyWorkflow = `name: SEO Daily Safe Scan

on:
  schedule:
    - cron: '15 4 * * *'
  workflow_dispatch:

jobs:
  daily-scan:
    runs-on: ubuntu-latest
    env:
      DRY_RUN: 'true'
      WP_BASE_URL: \${{ secrets.WP_BASE_URL }}
      WP_USERNAME: \${{ secrets.WP_USERNAME }}
      WP_APP_PASSWORD: \${{ secrets.WP_APP_PASSWORD }}
      GSC_SITE_URL: \${{ secrets.GSC_SITE_URL }}
      PAGESPEED_API_KEY: \${{ secrets.PAGESPEED_API_KEY }}
      AHREFS_API_KEY: \${{ secrets.AHREFS_API_KEY }}
      MOZ_ACCESS_ID: \${{ secrets.MOZ_ACCESS_ID }}
      MOZ_SECRET_KEY: \${{ secrets.MOZ_SECRET_KEY }}
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: pip install requests beautifulsoup4 lxml
      - name: Run daily scan
        run: python scripts/seo/daily_scan.py
      - name: Upload daily reports
        uses: actions/upload-artifact@v4
        with:
          name: daily-seo-reports
          path: |
            docs/seo-reports/daily/*.json
            docs/seo-reports/daily/*.md
            docs/seo-reports/daily/*.txt
`;

const weeklyWorkflow = `name: SEO Weekly Safe Audit

on:
  schedule:
    - cron: '0 5 * * 1'
  workflow_dispatch:

jobs:
  weekly-audit:
    runs-on: ubuntu-latest
    env:
      DRY_RUN: 'true'
      WP_BASE_URL: \${{ secrets.WP_BASE_URL }}
      WP_USERNAME: \${{ secrets.WP_USERNAME }}
      WP_APP_PASSWORD: \${{ secrets.WP_APP_PASSWORD }}
      GSC_SITE_URL: \${{ secrets.GSC_SITE_URL }}
      PAGESPEED_API_KEY: \${{ secrets.PAGESPEED_API_KEY }}
      AHREFS_API_KEY: \${{ secrets.AHREFS_API_KEY }}
      MOZ_ACCESS_ID: \${{ secrets.MOZ_ACCESS_ID }}
      MOZ_SECRET_KEY: \${{ secrets.MOZ_SECRET_KEY }}
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: pip install requests beautifulsoup4 lxml
      - name: Run weekly audit
        run: python scripts/seo/weekly_audit.py
      - name: Upload weekly reports
        uses: actions/upload-artifact@v4
        with:
          name: weekly-seo-reports
          path: |
            docs/seo-reports/weekly/*.json
            docs/seo-reports/weekly/*.md
            docs/seo-reports/weekly/*.txt
            docs/seo-reports/articles/*.md
            docs/seo-reports/articles/*.json
`;

const commonPy = `import base64
import json
import os
from datetime import datetime, timezone
from pathlib import Path

import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[2]
REPORTS_DIR = ROOT / 'docs' / 'seo-reports'
CONTENT_DRAFTS_DIR = ROOT / 'content-drafts'
META_DIR = ROOT / 'meta'
EDITORIAL_REPLACEMENT = 'Content under review. Updated editorial policy coming soon.'
ROBOTS_TARGET = """User-agent: *
Allow: /

Disallow: /wp-admin/
Allow: /wp-admin/admin-ajax.php

Sitemap: https://moneyabroadguide.com/sitemap.xml
""".strip()
META_TARGETS = {
    '/': {
        'title': 'Financial Guide for Newcomers to USA & Canada | MoneyAbroadGuide',
        'description': 'Explore a financial guide for newcomers to USA and Canada with practical banking, transfer, and credit tips. Start planning smarter today.'
    },
    '/newcomers-to-the-usa/': {
        'title': 'Banking & Finance for Immigrants in the USA | MoneyAbroadGuide',
        'description': 'Get banking and finance for immigrants in the USA with simple newcomer tips, account options, and next steps. Read the guide today.'
    },
    '/newcomers-to-canada/': {
        'title': 'Financial Guide for New Immigrants in Canada | MoneyAbroadGuide',
        'description': 'Use this financial guide for new immigrants in Canada to compare banking, transfers, and budgeting tips. Explore your options now.'
    }
}
ARTICLE_BLUEPRINTS = [
    {'slug': 'how-to-open-a-bank-account-in-canada-as-a-newcomer', 'keyword': 'how to open a bank account in canada as a newcomer', 'title': 'How to Open a Bank Account in Canada as a Newcomer', 'meta_description': 'Learn how to open a bank account in Canada as a newcomer with simple steps, required documents, and smart tips. Start banking confidently today.'},
    {'slug': 'best-bank-account-for-immigrants-usa-no-credit-history', 'keyword': 'best bank account for immigrants usa no credit history', 'title': 'Best Bank Account for Immigrants in the USA', 'meta_description': 'Find the best bank account for immigrants in the USA with no credit history and compare easy options. Read the guide and choose confidently.'},
    {'slug': 'how-to-build-credit-score-as-international-student-usa', 'keyword': 'how to build credit score as international student usa', 'title': 'How to Build Credit Score as an International Student', 'meta_description': 'Discover how to build credit score as an international student in the USA with practical steps and tools. Start improving your credit today.'},
    {'slug': 'wise-vs-remitly-for-sending-money-abroad', 'keyword': 'wise vs remitly for sending money abroad', 'title': 'Wise vs Remitly for Sending Money Abroad', 'meta_description': 'Compare Wise vs Remitly for sending money abroad, including fees, speed, and ease of use. Read the guide and pick the best fit today.'},
    {'slug': 'budgeting-tips-for-new-immigrants-canada', 'keyword': 'budgeting tips for new immigrants canada', 'title': 'Budgeting Tips for New Immigrants in Canada', 'meta_description': 'Use these budgeting tips for new immigrants in Canada to manage rent, groceries, and savings goals. Read the guide and plan better today.'}
]
INTERNAL_LINK_TARGETS = {
    '/': [{'anchor': 'money transfer comparisons', 'target': '/best-international-money-transfer-services-2026/'}, {'anchor': 'guides for newcomers', 'target': '/international-money-transfer-guide-for-immigrants/'}],
    '/newcomers-to-the-usa/': [{'anchor': 'build US credit', 'target': '/best-bank-account-for-immigrants-usa-no-credit-history/'}, {'anchor': 'sending money abroad', 'target': '/wise-vs-remitly-comparison-2026/'}],
    '/newcomers-to-canada/': [{'anchor': 'open a bank account in Canada', 'target': '/how-to-open-a-bank-account-in-canada-as-a-newcomer/'}, {'anchor': 'budgeting tips for newcomers', 'target': '/budgeting-tips-for-new-immigrants-canada/'}],
    '/editorial-policy/': [{'anchor': 'about Money Abroad Guide', 'target': '/about/'}, {'anchor': 'contact our team', 'target': '/contact/'}],
    '/about/': [{'anchor': 'editorial policy', 'target': '/editorial-policy/'}, {'anchor': 'financial guides for newcomers', 'target': '/'}]
}

def ensure_dirs():
    for path in [REPORTS_DIR / 'daily', REPORTS_DIR / 'weekly', REPORTS_DIR / 'articles', CONTENT_DRAFTS_DIR, META_DIR]:
        path.mkdir(parents=True, exist_ok=True)

def timestamp():
    return datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')

def write_text(path, content):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding='utf-8')

def write_json(path, payload):
    write_text(path, json.dumps(payload, indent=2, ensure_ascii=False))

def get_wp_credentials():
    base_url = (os.getenv('WP_BASE_URL') or '').rstrip('/')
    username = os.getenv('WP_USERNAME') or ''
    app_password = os.getenv('WP_APP_PASSWORD') or ''
    return {'base_url': base_url, 'username': username, 'app_password': app_password, 'configured': bool(base_url and username and app_password)}

def fetch_url(url, timeout=20):
    response = requests.get(url, timeout=timeout, headers={'User-Agent': 'MoneyAbroadGuide SEO Autopilot/2.0'})
    response.raise_for_status()
    return response

def get_page_html(base_url, path):
    return fetch_url(f'{base_url}{path}').text

def extract_title_and_meta(html):
    soup = BeautifulSoup(html, 'html.parser')
    title = soup.title.get_text(strip=True) if soup.title else ''
    meta = soup.find('meta', attrs={'name': 'description'})
    description = meta.get('content', '').strip() if meta else ''
    return {'title': title, 'description': description}

def word_count_from_html(html):
    soup = BeautifulSoup(html, 'html.parser')
    text = soup.get_text(' ', strip=True)
    return len([word for word in text.split() if word])

def find_base64_images(html):
    soup = BeautifulSoup(html, 'html.parser')
    images = []
    for img in soup.find_all('img'):
        src = img.get('src', '')
        if src.startswith('data:image/'):
            images.append({'src': src[:120] + '...' if len(src) > 120 else src, 'alt': img.get('alt', ''), 'loading': img.get('loading', '')})
    return images

def detect_editorial_artifacts(html):
    lines = [line.strip() for line in BeautifulSoup(html, 'html.parser').get_text('\n').splitlines() if line.strip()]
    prefixes = ('Provide', 'Include', 'Add', 'Detail', 'Expand on')
    return [line for line in lines if line.startswith(prefixes)]

def build_meta_report(base_url):
    report = []
    for path, target in META_TARGETS.items():
        current = {'title': '', 'description': ''}
        status = 'report_only'
        if base_url:
            try:
                current = extract_title_and_meta(get_page_html(base_url, path))
                status = 'compare'
            except Exception as error:
                current = {'title': '', 'description': f'Fetch failed: {error}'}
                status = 'unavailable'
        report.append({'path': path, 'current': current, 'target': target, 'status': status})
    return report

def build_internal_link_report():
    return [{'path': path, 'suggestions': suggestions} for path, suggestions in INTERNAL_LINK_TARGETS.items()]

def organization_schema():
    return {'@context': 'https://schema.org', '@type': 'Organization', 'name': 'Money Abroad Guide', 'url': 'https://moneyabroadguide.com', 'founder': 'Talal Eddaouahiri', 'description': 'Free financial guides for newcomers to Canada & USA'}

def person_schema():
    return {'@context': 'https://schema.org', '@type': 'Person', 'name': 'Talal Eddaouahiri', 'url': 'https://moneyabroadguide.com/about/', 'jobTitle': 'Founder', 'description': 'Founder of Money Abroad Guide, focused on finance for newcomers.'}

def rank_math_checklist():
    return {
        'installation_checklist': ['Confirm Rank Math is not already active.', 'Create a fresh backup before installation.', 'Install Rank Math manually in wp-admin.', 'Keep LiteSpeed cache purge ready if needed.'],
        'activation_checklist': ['Activate Rank Math during a low-traffic window.', 'Verify no schema duplication with Astra.', 'Confirm Wordfence does not block Rank Math actions.'],
        'configuration_checklist': ['Enable Sitemap for posts and pages only.', 'Enable Schema conservatively.', 'Enable Redirections with manual review.', 'Enable Analytics only after Search Console credentials are available.', 'Exclude noindex pages from sitemap.'],
        'gsc_placeholders': {'site_url': os.getenv('GSC_SITE_URL') or 'manual approval required', 'verification_status': 'not connected'}
    }
`;

const dailyScript = `from common import EDITORIAL_REPLACEMENT, ROBOTS_TARGET, build_internal_link_report, build_meta_report, detect_editorial_artifacts, ensure_dirs, find_base64_images, get_page_html, get_wp_credentials, organization_schema, person_schema, rank_math_checklist, timestamp, write_json, write_text

def main():
    ensure_dirs()
    creds = get_wp_credentials()
    run_id = timestamp()
    base_url = creds['base_url']
    editorial_report = {'path': '/editorial-policy/', 'mode': 'dry_run', 'replacement': EDITORIAL_REPLACEMENT, 'detected_lines': [], 'status': 'report_only'}
    image_report = {'mode': 'dry_run', 'upload_target_path': '/wp-content/uploads/2026/04/', 'items': [], 'status': 'report_only'}
    robots_report = {'mode': 'dry_run', 'current': '', 'target': ROBOTS_TARGET, 'status': 'ready_to_apply_file'}
    if base_url:
        try:
            editorial_html = get_page_html(base_url, '/editorial-policy/')
            editorial_report['detected_lines'] = detect_editorial_artifacts(editorial_html)
            editorial_report['status'] = 'patch_proposal_ready' if editorial_report['detected_lines'] else 'no_artifacts_found'
        except Exception as error:
            editorial_report['status'] = f'fetch_failed: {error}'
        try:
            robots_report['current'] = get_page_html(base_url, '/robots.txt').strip()
            robots_report['status'] = 'matches_target' if robots_report['current'] == ROBOTS_TARGET else 'patch_proposal_ready'
        except Exception as error:
            robots_report['status'] = f'fetch_failed: {error}'
        for path in ['/', '/editorial-policy/', '/about/', '/newcomers-to-the-usa/', '/newcomers-to-canada/']:
            try:
                html = get_page_html(base_url, path)
                images = find_base64_images(html)
                if images:
                    image_report['items'].append({'path': path, 'detected_images': images, 'replacement_plan': 'decode -> convert webp -> compress <=150KB -> upload manually -> replace src -> add alt + loading=lazy'})
            except Exception as error:
                image_report['items'].append({'path': path, 'error': str(error)})
    meta_report = build_meta_report(base_url)
    internal_link_report = build_internal_link_report()
    schema_report = {'homepage_organization_schema': organization_schema(), 'about_person_schema': person_schema(), 'breadcrumb_schema': 'Prefer Rank Math breadcrumbs if already enabled.', 'faq_schema': 'Inject only when FAQ blocks are confirmed on page.'}
    eeat_report = {'about_page_plan': {'founder': 'Talal Eddaouahiri', 'expertise': 'finance for newcomers', 'status': 'manual approval required'}, 'author_box_plan': 'Use child-theme/snippet-compatible patch only after template review.', 'trust_badges_plan': ['Verified Content badge', 'Last updated date', 'Official sources mention']}
    payload = {'run_id': run_id, 'mode': 'dry_run', 'wordpress_credentials_configured': creds['configured'], 'editorial_policy': editorial_report, 'base64_images': image_report, 'robots': robots_report, 'meta_updates': meta_report, 'internal_links': internal_link_report, 'schema': schema_report, 'eeat': eeat_report, 'rank_math': rank_math_checklist()}
    md_lines = ['# Daily SEO Safe Scan', '', f'- Run ID: {run_id}', '- Mode: dry_run', f"- WordPress credentials configured: {'yes' if creds['configured'] else 'no'}", '', '## Safety', '- No production changes applied.', '- Manual approval required before any write step.']
    write_json('docs/seo-reports/daily/daily-scan-latest.json', payload)
    write_json(f'docs/seo-reports/daily/daily-scan-{run_id}.json', payload)
    write_text('docs/seo-reports/daily/daily-scan-latest.md', '\n'.join(md_lines))
    write_text(f'docs/seo-reports/daily/daily-scan-{run_id}.md', '\n'.join(md_lines))
    write_text('docs/seo-reports/daily/robots.txt.ready.txt', ROBOTS_TARGET + '\n')

if __name__ == '__main__':
    main()
`;

const weeklyScript = `from common import ARTICLE_BLUEPRINTS, build_internal_link_report, build_meta_report, ensure_dirs, get_page_html, get_wp_credentials, rank_math_checklist, timestamp, word_count_from_html, write_json, write_text

def build_article_markdown(title, keyword):
    intro = f'If you are researching {keyword}, you are likely trying to make a safe financial decision while adapting to a new country. This guide explains the basics, the common mistakes to avoid, and the practical steps that matter most for newcomers. It is written in a human tone and designed to help readers compare options with confidence.'
    toc = ['Why this topic matters for newcomers', 'What to prepare before you start', 'Best options to compare', 'Common mistakes to avoid', 'How to choose the best next step', 'Final checklist']
    sections = []
    for heading in toc:
        paragraph = ' '.join([f'{heading} is an important part of the decision-making process for newcomers.', 'A strong approach starts with official requirements, realistic budgeting, and clear expectations about timelines.', 'Readers should compare fees, account rules, eligibility requirements, and support quality before choosing any provider.', 'It also helps to collect documents early, verify whether newcomer programs exist, and review digital banking features or transfer limits.', 'A practical plan is usually safer than chasing promotions with hidden conditions.', 'In most cases, the best option depends on how often you use the service, whether you need branch access, and how quickly your situation may change in the first year.', 'For MoneyAbroadGuide readers, the most useful strategy is to compare a shortlist, check official pages, and keep records of every important step.'])
        sections.append(f'## {heading}\n\n{paragraph}\n\n{paragraph}\n')
    faq = [('What documents should I prepare first?', 'Start with passport, visa or status proof, address details, and any local tax or ID number if available.'), ('Should I choose the cheapest option?', 'Not always. Compare total value, support quality, speed, and rules, not just the headline fee.'), ('How can I avoid common mistakes?', 'Read official terms, verify account limits, and avoid rushing into products you do not fully understand.'), ('What if I am new and have no credit history?', 'Look for newcomer-friendly products, secured options, and providers that explain eligibility clearly.'), ('How often should I review my setup?', 'Review your setup after the first few months and again when your income, status, or goals change.')]
    faq_md = '\n\n'.join([f'### {q}\n{a}' for q, a in faq])
    body = '\n'.join(sections)
    conclusion = 'The best financial setup for a newcomer is usually the one that is easy to maintain, transparent, and aligned with real day-to-day needs. Use this guide as a starting point, compare carefully, and make changes only after checking the official details.'
    return f'# {title}\n\n{intro}\n\n## Table of Contents\n' + '\n'.join([f'- {item}' for item in toc]) + f'\n\n{body}\n## FAQ\n\n{faq_md}\n\n## Conclusion\n\n{conclusion}\n'

def main():
    ensure_dirs()
    creds = get_wp_credentials()
    run_id = timestamp()
    base_url = creds['base_url']
    audit_checks = {'indexation': 'manual approval required unless GSC credentials are configured', 'core_web_vitals': 'manual approval required unless PageSpeed API key is configured', 'thin_content': [], 'missing_meta': build_meta_report(base_url), 'missing_alt_tags': 'report mode placeholder', 'broken_links': 'report mode placeholder', 'backlinks': 'manual approval required unless Ahrefs or Moz credentials are configured'}
    if base_url:
        for path in ['/', '/about/', '/editorial-policy/', '/newcomers-to-the-usa/', '/newcomers-to-canada/']:
            try:
                count = word_count_from_html(get_page_html(base_url, path))
                if count < 300:
                    audit_checks['thin_content'].append({'path': path, 'word_count': count, 'status': 'thin_content'})
            except Exception as error:
                audit_checks['thin_content'].append({'path': path, 'error': str(error), 'status': 'unavailable'})
    article_outputs = []
    for blueprint in ARTICLE_BLUEPRINTS:
        markdown = build_article_markdown(blueprint['title'], blueprint['keyword'])
        meta_json = {'slug': blueprint['slug'], 'keyword': blueprint['keyword'], 'title': blueprint['title'], 'meta_description': blueprint['meta_description'], 'status': 'draft_only'}
        write_text(f"content-drafts/{blueprint['slug']}.md", markdown)
        write_json(f"meta/{blueprint['slug']}.json", meta_json)
        write_text(f"docs/seo-reports/articles/{blueprint['slug']}.md", markdown)
        write_json(f"docs/seo-reports/articles/{blueprint['slug']}.json", meta_json)
        article_outputs.append({'slug': blueprint['slug'], 'title': blueprint['title']})
    payload = {'run_id': run_id, 'mode': 'dry_run', 'wordpress_credentials_configured': creds['configured'], 'audit_checks': audit_checks, 'internal_links': build_internal_link_report(), 'rank_math': rank_math_checklist(), 'generated_articles': article_outputs, 'critical_issues': len([item for item in audit_checks['thin_content'] if item.get('status') == 'thin_content']) > 0}
    md_lines = ['# Weekly SEO Audit', '', f'- Run ID: {run_id}', '- Mode: dry_run', f"- WordPress credentials configured: {'yes' if creds['configured'] else 'no'}", '', '## Content Engine', *[f"- Draft generated: {item['title']}" for item in article_outputs], '', '## Safety', '- No production changes applied.', '- Manual approval required before any apply workflow.']
    write_json('docs/seo-reports/weekly/weekly-audit-latest.json', payload)
    write_json(f'docs/seo-reports/weekly/weekly-audit-{run_id}.json', payload)
    write_text('docs/seo-reports/weekly/weekly-audit-latest.md', '\n'.join(md_lines))
    write_text(f'docs/seo-reports/weekly/weekly-audit-{run_id}.md', '\n'.join(md_lines))

if __name__ == '__main__':
    main()
`;

const docsReadme = `# MoneyAbroadGuide GitHub SEO Autopilot

This setup is GitHub-first, safe, and dry-run by default.

## Included
- Daily safe scan workflow
- Weekly SEO audit workflow
- Python report scripts
- Article draft generation
- Dry-run reports
- Meta files

## Required GitHub secrets
- WP_BASE_URL
- WP_USERNAME
- WP_APP_PASSWORD
- GSC_SITE_URL
- PAGESPEED_API_KEY
- AHREFS_API_KEY
- MOZ_ACCESS_ID
- MOZ_SECRET_KEY

## robots.txt final version

User-agent: *
Allow: /

Disallow: /wp-admin/
Allow: /wp-admin/admin-ajax.php

Sitemap: https://moneyabroadguide.com/sitemap.xml

## Push commands

 git checkout -b safe-seo-autopilot
 git add .
 git commit -m "Add safe GitHub-first SEO autopilot framework"
 git push origin safe-seo-autopilot
`;

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const zip = new JSZip();
    zip.file('moneyabroadguide-seo-autopilot/moneyabroadguide-seo-autopilot.php', pluginPhp);
    zip.file('moneyabroadguide-seo-autopilot/.github/workflows/seo-daily.yml', dailyWorkflow);
    zip.file('moneyabroadguide-seo-autopilot/.github/workflows/seo-weekly.yml', weeklyWorkflow);
    zip.file('moneyabroadguide-seo-autopilot/scripts/seo/common.py', commonPy);
    zip.file('moneyabroadguide-seo-autopilot/scripts/seo/daily_scan.py', dailyScript);
    zip.file('moneyabroadguide-seo-autopilot/scripts/seo/weekly_audit.py', weeklyScript);
    zip.file('moneyabroadguide-seo-autopilot/docs/github-seo-autopilot.md', docsReadme);
    zip.file('moneyabroadguide-seo-autopilot/docs/seo-reports/README.md', '# SEO Reports\n\nGenerated dry-run SEO reports live here.');
    zip.file('moneyabroadguide-seo-autopilot/content-drafts/.gitkeep', '');
    zip.file('moneyabroadguide-seo-autopilot/meta/.gitkeep', '');
    zip.file('moneyabroadguide-seo-autopilot/README.md', '# MoneyAbroadGuide SEO Autopilot Bundle\n\nSafe GitHub-first SEO autopilot in dry-run mode by default.');

    const buffer = await zip.generateAsync({ type: 'uint8array' });
    return new Response(buffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename="moneyabroadguide-seo-autopilot-bundle.zip"'
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});