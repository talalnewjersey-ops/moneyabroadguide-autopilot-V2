import React from 'react';
export default function BackofficeReady() { return <div className="hidden" />; }