import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const normalizeUrl = (url = '') => url.toLowerCase().trim().replace(/^https?:\/\//, '').replace(/\/$/, '');
const targetUrl = 'moneyabroadguide.com';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const websites = await base44.asServiceRole.entities.Website.list();
    const website = websites.find((item) => normalizeUrl(item.url) === targetUrl);

    if (!website) {
      return Response.json({ error: 'Website not found.' }, { status: 404 });
    }

    const keywords = await base44.asServiceRole.entities.Keyword.filter({ website_id: website.id }, '-created_date', 50);
    const recentScans = await base44.asServiceRole.entities.SiteScan.filter({ website_id: website.id }, '-created_date', 5);
    const pages = await base44.asServiceRole.entities.Page.filter({ website_id: website.id }, '-updated_date', 20);

    const log = await base44.asServiceRole.entities.AutomationLog.create({
      website_id: website.id,
      task_type: 'report_generation',
      status: 'running',
      details: 'Weekly SEO automation started',
      items_processed: 0,
    });

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `Create a weekly SEO growth update for ${website.url}. Use this data: website=${JSON.stringify({ seo_score: website.seo_score, total_pages: website.total_pages, total_issues: website.total_issues })}, recent_scans=${JSON.stringify(recentScans.map((scan) => ({ seo_score: scan.seo_score, critical_issues: scan.critical_issues, warnings: scan.warnings, summary: scan.summary, created_date: scan.created_date })))}, keywords=${JSON.stringify(keywords.map((keyword) => ({ keyword: keyword.keyword, difficulty: keyword.difficulty, intent: keyword.intent, assigned_page: keyword.assigned_page, status: keyword.status })))}, pages=${JSON.stringify(pages.map((page) => ({ title: page.title, url: page.url, seo_score: page.seo_score, content_score: page.content_score, keywords: page.keywords || [] })))}. Also use live web context. Return a non-empty executive summary, exactly 5 concrete priorities, and exactly 6 realistic backlink opportunities for this site with source_url, source_name, type, relevance_score, outreach_email. Prioritize finance, expat, travel money, banking, and international money transfer relevance. Do not leave any field empty.`,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          summary: { type: 'string' },
          priorities: { type: 'array', items: { type: 'string' } },
          opportunities: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                source_url: { type: 'string' },
                source_name: { type: 'string' },
                type: { type: 'string' },
                relevance_score: { type: 'number' },
                outreach_email: { type: 'string' }
              }
            }
          }
        }
      }
    });

    const existingBacklinks = await base44.asServiceRole.entities.BacklinkOpportunity.filter({ website_id: website.id }, '-created_date', 200);
    const existingSourceSet = new Set(existingBacklinks.map((item) => String(item.source_url || '').toLowerCase()));
    let newBacklinks = 0;

    for (const opportunity of result.opportunities || []) {
      const sourceUrl = String(opportunity.source_url || '').trim().toLowerCase();
      if (!sourceUrl || existingSourceSet.has(sourceUrl)) continue;
      await base44.asServiceRole.entities.BacklinkOpportunity.create({
        website_id: website.id,
        source_url: opportunity.source_url,
        source_name: opportunity.source_name || '',
        type: opportunity.type || 'guest_post',
        relevance_score: opportunity.relevance_score || 0,
        status: 'discovered',
        outreach_email: opportunity.outreach_email || ''
      });
      existingSourceSet.add(sourceUrl);
      newBacklinks += 1;
    }

    await base44.asServiceRole.entities.AutomationLog.update(log.id, {
      status: 'completed',
      details: result.summary || 'Weekly SEO automation completed',
      items_processed: newBacklinks
    });

    return Response.json({
      success: true,
      website: website.url,
      summary: result.summary || '',
      priorities: result.priorities || [],
      backlinks_created: newBacklinks
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});