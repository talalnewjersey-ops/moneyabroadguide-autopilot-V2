from common import (
    ARTICLE_BLUEPRINTS,
    build_internal_link_report,
    build_meta_report,
    ensure_dirs,
    get_page_html,
    get_wp_credentials,
    rank_math_checklist,
    timestamp,
    word_count_from_html,
    write_json,
    write_text,
)


def build_article_markdown(title, keyword):
    intro = (
        f"If you are researching {keyword}, you are likely trying to make a safe financial decision while adapting to a new country. "
        "This guide explains the basics, the common mistakes to avoid, and the practical steps that matter most for newcomers. "
        "It is written in a human tone, focused on clarity, and designed to help readers compare options with confidence."
    )
    toc = [
        'Why this topic matters for newcomers',
        'What to prepare before you start',
        'Best options to compare',
        'Common mistakes to avoid',
        'How to choose the best next step',
        'Final checklist'
    ]
    sections = []
    for heading in toc:
        paragraph = ' '.join([
            f"{heading} is an important part of the decision-making process for newcomers.",
            "A strong approach starts with official requirements, realistic budgeting, and clear expectations about timelines.",
            "Readers should compare fees, account rules, eligibility requirements, and support quality before choosing any provider.",
            "It also helps to collect documents early, verify whether newcomer programs exist, and review digital banking features or transfer limits.",
            "A practical plan is usually safer than chasing promotions that look attractive but come with hidden conditions.",
            "In most cases, the best option depends on how often you use the service, whether you need branch access, and how quickly your situation may change in the first year.",
            "For MoneyAbroadGuide readers, the most useful strategy is to compare a small shortlist, check official pages, and keep records of every important step."
        ])
        sections.append(f"## {heading}\n\n{paragraph}\n\n{paragraph}\n")
    faq = [
        ('What documents should I prepare first?', 'Start with passport, visa or status proof, address details, and any local tax or ID number if available.'),
        ('Should I choose the cheapest option?', 'Not always. Compare total value, support quality, speed, and rules, not just the headline fee.'),
        ('How can I avoid common mistakes?', 'Read official terms, verify account limits, and avoid rushing into products you do not fully understand.'),
        ('What if I am new and have no credit history?', 'Look for newcomer-friendly products, secured options, and providers that explain eligibility clearly.'),
        ('How often should I review my setup?', 'Review your setup after the first few months and again when your income, status, or goals change.')
    ]
    faq_md = '\n\n'.join([f"### {q}\n{a}" for q, a in faq])
    body = '\n'.join(sections)
    conclusion = (
        "The best financial setup for a newcomer is usually the one that is easy to maintain, transparent, and aligned with real day-to-day needs. "
        "Use this guide as a starting point, compare carefully, and make changes only after checking the official details."
    )
    return f"# {title}\n\n{intro}\n\n## Table of Contents\n" + '\n'.join([f"- {item}" for item in toc]) + f"\n\n{body}\n## FAQ\n\n{faq_md}\n\n## Conclusion\n\n{conclusion}\n"


def main():
    ensure_dirs()
    creds = get_wp_credentials()
    run_id = timestamp()
    base_url = creds['base_url']

    audit_checks = {
        'indexation': 'manual approval required unless GSC credentials are configured',
        'core_web_vitals': 'manual approval required unless PageSpeed API key is configured',
        'thin_content': [],
        'missing_meta': build_meta_report(base_url),
        'missing_alt_tags': 'report mode placeholder',
        'broken_links': 'report mode placeholder',
        'backlinks': 'manual approval required unless Ahrefs or Moz credentials are configured'
    }

    if base_url:
        for path in ['/', '/about/', '/editorial-policy/', '/newcomers-to-the-usa/', '/newcomers-to-canada/']:
            try:
                count = word_count_from_html(get_page_html(base_url, path))
                if count < 300:
                    audit_checks['thin_content'].append({'path': path, 'word_count': count, 'status': 'thin_content'})
            except Exception as error:
                audit_checks['thin_content'].append({'path': path, 'error': str(error), 'status': 'unavailable'})

    article_outputs = []
    for blueprint in ARTICLE_BLUEPRINTS:
        markdown = build_article_markdown(blueprint['title'], blueprint['keyword'])
        meta_json = {
            'slug': blueprint['slug'],
            'keyword': blueprint['keyword'],
            'title': blueprint['title'],
            'meta_description': blueprint['meta_description'],
            'status': 'draft_only'
        }
        write_text(f"content-drafts/{blueprint['slug']}.md", markdown)
        write_json(f"meta/{blueprint['slug']}.json", meta_json)
        write_text(f"docs/seo-reports/articles/{blueprint['slug']}.md", markdown)
        write_json(f"docs/seo-reports/articles/{blueprint['slug']}.json", meta_json)
        article_outputs.append({'slug': blueprint['slug'], 'title': blueprint['title']})

    payload = {
        'run_id': run_id,
        'mode': 'dry_run',
        'wordpress_credentials_configured': creds['configured'],
        'audit_checks': audit_checks,
        'internal_links': build_internal_link_report(),
        'rank_math': rank_math_checklist(),
        'generated_articles': article_outputs,
        'critical_issues': len([item for item in audit_checks['thin_content'] if item.get('status') == 'thin_content']) > 0,
    }

    md_lines = [
        '# Weekly SEO Audit',
        '',
        f'- Run ID: {run_id}',
        '- Mode: dry_run',
        f"- WordPress credentials configured: {'yes' if creds['configured'] else 'no'}",
        '',
        '## Checks',
        f"- Thin content findings: {len([item for item in audit_checks['thin_content'] if item.get('status') == 'thin_content'])}",
        '- Missing meta report generated.',
        '- Internal linking report generated.',
        '- Rank Math setup checklist prepared.',
        '',
        '## Content Engine',
        *[f"- Draft generated: {item['title']}" for item in article_outputs],
        '',
        '## Safety',
        '- No production changes applied.',
        '- Manual approval required before any apply workflow.',
    ]

    write_json('docs/seo-reports/weekly/weekly-audit-latest.json', payload)
    write_json(f'docs/seo-reports/weekly/weekly-audit-{run_id}.json', payload)
    write_text('docs/seo-reports/weekly/weekly-audit-latest.md', '\n'.join(md_lines))
    write_text(f'docs/seo-reports/weekly/weekly-audit-{run_id}.md', '\n'.join(md_lines))


if __name__ == '__main__':
    main()