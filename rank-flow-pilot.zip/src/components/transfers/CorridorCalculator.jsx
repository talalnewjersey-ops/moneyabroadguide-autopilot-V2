import React, { useMemo, useState } from 'react';
import { ArrowRight, Shield, TrendingUp } from 'lucide-react';
import { Input } from '@/components/ui/input';

const methodConfig = {
  bank_deposit: { label: 'Bank deposit', extraFee: 0, fxPenalty: 0, speedText: '1–2 days' },
  mobile_wallet: { label: 'Mobile wallet', extraFee: 1.5, fxPenalty: 0.12, speedText: 'Minutes to 24h' },
  cash_pickup: { label: 'Cash pickup', extraFee: 3.5, fxPenalty: 0.22, speedText: 'Minutes' },
};

export default function CorridorCalculator({ services, toCountry, receiveCurrency, currencySymbol, urgency }) {
  const [amount, setAmount] = useState(1000);
  const [method, setMethod] = useState('bank_deposit');

  const ranked = useMemo(() => {
    const safeAmount = Math.max(100, Number(amount) || 1000);
    const selectedMethod = methodConfig[method];

    return services
      .map((service) => {
        const fee = safeAmount * service.baseFeePercent + service.fixedFee + selectedMethod.extraFee + service.methodFee;
        const rate = service.baseRate - selectedMethod.fxPenalty;
        const receivedAmount = Math.max(0, (safeAmount - fee) * rate);
        return {
          ...service,
          fee,
          rate,
          receivedAmount,
          speedOutput: method === 'cash_pickup' ? 'Minutes' : method === 'mobile_wallet' ? 'Minutes to 24h' : service.speed,
        };
      })
      .sort((a, b) => b.receivedAmount - a.receivedAmount)
      .map((service, index) => ({ ...service, rank: index + 1 }));
  }, [amount, method, services]);

  const best = ranked[0];

  return (
    <section id="calculator" className="bg-[#F8FAFC]">
      <div className="mx-auto max-w-[980px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="fintech-card p-7 text-center lg:text-left">
            <div className="inline-flex rounded-full bg-[#EAF7F1] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#1F8F6A]">
              Best Option
            </div>
            <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-slate-950">{best.name} is the best option right now</h2>
            <p className="mt-3 text-base leading-8 text-slate-500">{urgency}</p>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div className="rounded-[22px] bg-[#0B1F3A] p-5 text-white">
                <p className="text-xs uppercase tracking-[0.16em] text-white/70">Amount received</p>
                <strong className="mt-2 block text-3xl font-bold">{currencySymbol}{best.receivedAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}</strong>
              </div>
              <div className="rounded-[22px] border border-slate-200 bg-white p-5">
                <p className="text-xs uppercase tracking-[0.16em] text-slate-500">Transfer speed</p>
                <strong className="mt-2 block text-2xl font-bold text-slate-950">{best.speedOutput}</strong>
              </div>
            </div>

            <div className="mt-6 space-y-3 text-sm text-slate-600">
              <div className="flex items-start justify-center gap-3 lg:justify-start">
                <Shield className="mt-0.5 h-4 w-4 text-[#1F8F6A]" />
                <span>Trust-focused layout for financial decisions</span>
              </div>
              <div className="flex items-start justify-center gap-3 lg:justify-start">
                <TrendingUp className="mt-0.5 h-4 w-4 text-[#1F8F6A]" />
                <span>Compare price, exchange rate, speed, and payout in one workflow</span>
              </div>
            </div>
          </div>

          <div className="fintech-card p-7">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#1F8F6A]">Money transfer calculator</p>
              <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-slate-950">Estimate fees, exchange rate, and amount received</h2>
            </div>

            <div className="mt-6 grid gap-4 md:grid-cols-3">
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">Amount (USD)</label>
                <Input type="number" min="100" value={amount} onChange={(e) => setAmount(e.target.value)} className="h-12 rounded-2xl border-slate-200" />
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">Destination</label>
                <div className="flex h-12 items-center rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm font-medium text-slate-900">{toCountry}</div>
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">Transfer method</label>
                <select value={method} onChange={(e) => setMethod(e.target.value)} className="h-12 w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm text-slate-900">
                  {Object.entries(methodConfig).map(([value, item]) => (
                    <option key={value} value={value}>{item.label}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-4 text-center">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Fees</p>
                <strong className="mt-2 block text-2xl font-bold text-slate-950">${best.fee.toFixed(2)}</strong>
              </div>
              <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-4 text-center">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Exchange rate</p>
                <strong className="mt-2 block text-2xl font-bold text-slate-950">{currencySymbol}{best.rate.toFixed(2)}</strong>
              </div>
              <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-4 text-center">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Amount received</p>
                <strong className="mt-2 block text-2xl font-bold text-slate-950">{currencySymbol}{best.receivedAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}</strong>
              </div>
              <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-4 text-center">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Transfer speed</p>
                <strong className="mt-2 block text-2xl font-bold text-slate-950">{best.speedOutput}</strong>
              </div>
            </div>

            <div className="mt-6 space-y-3">
              {ranked.map((service) => (
                <div key={service.name} className="flex items-center justify-between gap-4 rounded-[22px] border border-slate-200 bg-white px-4 py-4 transition hover:-translate-y-1 hover:shadow-[0_18px_35px_rgba(15,23,42,0.08)]">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="inline-flex rounded-full bg-[#EAF7F1] px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#1F8F6A]">#{service.rank}</span>
                      <strong className="text-slate-950">{service.name}</strong>
                    </div>
                    <p className="mt-2 text-sm text-slate-500">{service.speedOutput} • {service.rateText}</p>
                  </div>
                  <div className="text-right">
                    <strong className="block text-slate-950">{currencySymbol}{service.receivedAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}</strong>
                    <span className="text-sm text-slate-500">Fee ${service.fee.toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <a href={best.href} target="_blank" rel="noreferrer" className="cta-primary h-12 px-6 text-sm">Compare Fees Now</a>
              <a href="#faq" className="inline-flex items-center gap-2 text-sm font-semibold text-slate-950">Read transfer FAQs <ArrowRight className="h-4 w-4" /></a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}