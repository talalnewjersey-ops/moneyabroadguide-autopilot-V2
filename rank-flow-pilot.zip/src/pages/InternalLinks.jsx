import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Link2, Loader2, Sparkles, ArrowRight } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import EmptyState from '../components/common/EmptyState';
import { toast } from 'sonner';

export default function InternalLinks() {
  const [analyzing, setAnalyzing] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const queryClient = useQueryClient();

  const { data: websites = [] } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 1),
  });

  const activeWebsite = websites[0];

  const { data: pages = [] } = useQuery({
    queryKey: ['pages', activeWebsite?.id],
    queryFn: () => base44.entities.Page.filter({ website_id: activeWebsite.id }),
    enabled: !!activeWebsite,
  });

  const analyzeLinks = async () => {
    if (!activeWebsite) return;
    setAnalyzing(true);

    const pageUrls = pages.map(p => p.url).join('\n');

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an internal linking specialist for ${activeWebsite.url}.
      
      Here are the known pages:
      ${pageUrls || 'No pages crawled yet - suggest general internal linking improvements based on the website.'}
      
      Generate 10 specific internal linking suggestions. For each, specify:
      - source_page: the page that should contain the link
      - target_page: the page being linked to
      - anchor_text: suggested anchor text
      - context: brief explanation of why these pages should link
      - priority: high/medium/low`,
      response_json_schema: {
        type: "object",
        properties: {
          suggestions: {
            type: "array",
            items: {
              type: "object",
              properties: {
                source_page: { type: "string" },
                target_page: { type: "string" },
                anchor_text: { type: "string" },
                context: { type: "string" },
                priority: { type: "string" }
              }
            }
          }
        }
      },
      add_context_from_internet: true,
    });

    setSuggestions(result.suggestions || []);
    setAnalyzing(false);
    toast.success('Internal link analysis complete!');
  };

  if (!activeWebsite) {
    return <EmptyState icon={Link2} title="No website connected" description="Add a website in Settings first." />;
  }

  const priorityColor = { high: 'bg-red-50 text-red-700', medium: 'bg-amber-50 text-amber-700', low: 'bg-green-50 text-green-700' };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader
        title="Internal Linking AI"
        description="Discover contextual linking opportunities to boost your site structure"
        action={
          <Button onClick={analyzeLinks} disabled={analyzing} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
            {analyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {analyzing ? 'Analyzing...' : 'Analyze Links'}
          </Button>
        }
      />

      {suggestions.length === 0 ? (
        <EmptyState
          icon={Link2}
          title="No link suggestions yet"
          description="Click 'Analyze Links' to discover internal linking opportunities."
          action="Analyze Now"
          onAction={analyzeLinks}
        />
      ) : (
        <div className="space-y-3">
          {suggestions.map((s, i) => (
            <Card key={i} className="hover:shadow-sm transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Link2 className="w-4 h-4 text-blue-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-gray-600 truncate max-w-[200px]">{s.source_page}</span>
                      <ArrowRight className="w-3 h-3 text-gray-400 flex-shrink-0" />
                      <span className="text-gray-900 font-medium truncate max-w-[200px]">{s.target_page}</span>
                    </div>
                    <p className="text-xs text-blue-600 mt-1">Anchor: "{s.anchor_text}"</p>
                    <p className="text-xs text-gray-500 mt-1">{s.context}</p>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${priorityColor[s.priority] || 'bg-gray-50 text-gray-700'}`}>
                    {s.priority}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}