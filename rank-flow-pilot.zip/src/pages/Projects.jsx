import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function Projects() {
  const [name, setName] = useState('');
  const [domain, setDomain] = useState('');
  const queryClient = useQueryClient();
  const { data: workspaces = [] } = useQuery({ queryKey: ['workspaces'], queryFn: () => base44.entities.Workspace.list('-created_date', 1) });
  const { data: projects = [] } = useQuery({ queryKey: ['projects'], queryFn: () => base44.entities.Project.list('-created_date', 50) });

  const createProject = async () => {
    if (!name || !workspaces[0]) return;
    await base44.entities.Project.create({
      workspace_id: workspaces[0].id,
      name,
      domain,
      site_url: domain ? `https://${domain.replace(/^https?:\/\//, '')}` : '',
      cms_type: 'wordpress',
      niche: 'expat finance',
      language: 'English',
      country: 'USA and Canada',
      auto_mode: 'assisted',
      project_api_key: crypto.randomUUID().replace(/-/g, '')
    });
    setName('');
    setDomain('');
    queryClient.invalidateQueries({ queryKey: ['projects'] });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Projects" description="Create and manage multiple websites, brands, and SEO workstreams." />
      <div className="grid md:grid-cols-3 gap-3"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Project name" className="rounded-xl" /><Input value={domain} onChange={(e) => setDomain(e.target.value)} placeholder="Domain" className="rounded-xl" /><Button onClick={createProject} className="rounded-xl bg-blue-600 hover:bg-blue-700">Create Project</Button></div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{projects.map((project) => <Card key={project.id}><CardContent className="p-5"><h3 className="font-semibold text-gray-900">{project.name}</h3><p className="text-sm text-gray-500 mt-1">{project.domain || project.site_url || 'No domain yet'}</p><p className="text-xs text-gray-400 mt-2">Mode: {project.auto_mode}</p></CardContent></Card>)}</div>
    </div>
  );
}