import React from 'react';

const guideCards = [
  {
    badge: 'USA',
    badgeClass: 'bg-[#EAF7F1] text-[#1F8F6A]',
    title: 'Newcomers to the USA',
    description: 'Educational explanations of U.S. banking, credit, taxes, ITIN numbers, and first money steps for immigrants and expats.',
    links: [
      { label: 'Read Full Guide', href: '/newcomers-to-the-usa/', primary: true },
      { label: 'Banks Without SSN', href: '/bank-account-immigrants-usa-no-ssn/' },
      { label: 'Build US Credit', href: '/build-credit-international-student-usa/' },
    ],
  },
  {
    badge: 'CANADA',
    badgeClass: 'bg-[#EAF7F1] text-[#1F8F6A]',
    title: 'Newcomers to Canada',
    description: 'Simple educational guides on Canadian banking, savings, housing, tax filing, and credit building for newcomers.',
    links: [
      { label: 'Read Full Guide', href: '/newcomers-to-canada/', primary: true },
      { label: 'Best Banks Canada', href: '/best-banks-newcomers-canada/' },
      { label: 'Build Canadian Credit', href: '/build-credit-canada-newcomer/' },
    ],
  },
  {
    badge: 'START HERE',
    badgeClass: 'bg-[#1F8F6A] text-white',
    title: 'Start Here for Newcomers',
    description: 'A practical starting point to understand transfers, banking, budgeting, and your first financial setup in North America.',
    featured: true,
    links: [
      { label: 'Start Here Guide', href: '/start-here/', primary: true },
      { label: 'Cost of Living 2026', href: '/cost-of-living-canada-2026/' },
      { label: 'Best Transfer Apps', href: '/best-money-transfer-apps-immigrants/' },
    ],
  },
];

export default function HomeGuideCards() {
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-[1200px] px-4 py-14 sm:px-6 lg:px-8">
        <div className="mx-auto mb-8 max-w-3xl text-center">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.18em] text-[#1F8F6A]">Choose Your Path</p>
          <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 sm:text-4xl">Guides designed for your specific situation</h2>
          <p className="mt-3 text-base leading-7 text-slate-500">Whether you are moving to the USA or Canada, start with the right guide and move into tools and comparisons faster.</p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {guideCards.map((card) => (
            <div
              key={card.title}
              className={`rounded-[28px] border bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] ${card.featured ? 'border-[#1F8F6A]' : 'border-slate-200'}`}
            >
              <div className="mb-5 text-center">
                <span className={`inline-flex rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-[0.16em] ${card.badgeClass}`}>
                  {card.badge}
                </span>
              </div>
              <h3 className="text-center text-2xl font-bold text-slate-950">{card.title}</h3>
              <p className="mt-3 text-center text-sm leading-7 text-slate-500">{card.description}</p>
              <div className="mt-6 flex flex-col gap-3">
                {card.links.map((link) => (
                  <a
                    key={link.label}
                    href={link.href}
                    className={link.primary
                      ? 'inline-flex items-center justify-center rounded-full bg-[#1F8F6A] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#187255]'
                      : 'inline-flex items-center justify-center rounded-full border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-900 transition hover:border-slate-300 hover:bg-slate-50'}
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}