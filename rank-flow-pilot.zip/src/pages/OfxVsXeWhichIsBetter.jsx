import React from 'react';
import SeoArticleLayout from '@/components/seo/SeoArticleLayout';
import { articlePages } from '@/lib/seoPages';

export default function OfxVsXeWhichIsBetter() {
  return <SeoArticleLayout page={articlePages.OfxVsXeWhichIsBetter} />;
}