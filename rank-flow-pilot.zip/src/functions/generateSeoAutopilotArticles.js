import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const articleTargets = [
  'how to open a bank account in canada as a newcomer',
  'best bank account for immigrants usa no credit history',
  'how to build credit score as international student usa',
  'wise vs remitly for sending money abroad',
  'budgeting tips for new immigrants canada'
];

const slugify = (value = '') => value.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = req.method === 'POST' ? await req.json().catch(() => ({})) : {};
    const projectId = body.project_id;
    if (!projectId) return Response.json({ error: 'project_id is required' }, { status: 400 });

    const websiteId = body.website_id || '';
    const results = [];

    for (const keyword of articleTargets) {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Write a production-ready SEO article for MoneyAbroadGuide.com about: ${keyword}. Return JSON with keys title, meta_description, intro, table_of_contents, body_markdown, faq, conclusion. Rules: title 55-60 characters, meta description 150-160 characters with keyword and CTA, intro around 150 words, body over 1500 words in markdown, 5 FAQ items with question and answer, human tone, no keyword stuffing, focused on newcomers to Canada/USA and practical finance guidance.`,
        response_json_schema: {
          type: 'object',
          properties: {
            title: { type: 'string' },
            meta_description: { type: 'string' },
            intro: { type: 'string' },
            table_of_contents: { type: 'array', items: { type: 'string' } },
            body_markdown: { type: 'string' },
            faq: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  question: { type: 'string' },
                  answer: { type: 'string' }
                }
              }
            },
            conclusion: { type: 'string' }
          }
        }
      });

      const slug = slugify(keyword);
      const markdown = `# ${response.title}\n\n${response.intro}\n\n## Table of Contents\n${(response.table_of_contents || []).map((item) => `- ${item}`).join('\n')}\n\n${response.body_markdown}\n\n## FAQ\n${(response.faq || []).map((item) => `### ${item.question}\n${item.answer}`).join('\n\n')}\n\n## Conclusion\n${response.conclusion}`;
      const metaJson = {
        keyword,
        title: response.title,
        meta_description: response.meta_description,
        slug,
        faq_count: (response.faq || []).length
      };

      const draft = await base44.asServiceRole.entities.ContentDraft.create({
        project_id: projectId,
        title: response.title,
        slug,
        primary_keyword: keyword,
        meta_title: response.title,
        meta_description: response.meta_description,
        html_content: markdown,
        table_of_contents: response.table_of_contents || [],
        status: 'ready',
        wordpress_status: 'not_sent'
      });

      results.push({ keyword, slug, markdown, metaJson, draft_id: draft.id, website_id: websiteId });
    }

    return Response.json({ success: true, articles: results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});