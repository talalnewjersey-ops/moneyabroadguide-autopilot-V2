import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const toText = (value = '') => typeof value === 'string' ? value : value == null ? '' : String(value);

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'pushDraftToWordPress', required_fields: ['draft_id'], optional_fields: ['connection_id'] });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.draft_id) {
      return Response.json({ endpoint: 'pushDraftToWordPress', required_fields: ['draft_id'], optional_fields: ['connection_id'] });
    }

    const draft = await base44.asServiceRole.entities.ContentDraft.get(payload.draft_id);
    if (!draft) {
      return Response.json({ error: 'Draft not found.' }, { status: 404 });
    }

    const connections = payload.connection_id
      ? [await base44.asServiceRole.entities.WordPressConnection.get(payload.connection_id)].filter(Boolean)
      : await base44.asServiceRole.entities.WordPressConnection.filter({ project_id: draft.project_id }, '-created_date', 1);

    let connection = connections[0];
    if (!connection?.site_url) {
      const websites = await base44.asServiceRole.entities.Website.filter({ project_id: draft.project_id }, '-created_date', 1);
      const website = websites[0];
      if (website?.url && website?.wordpress_api_url && website?.wordpress_api_key) {
        connection = {
          site_url: website.url,
          rest_url: website.wordpress_api_url,
          api_key: website.wordpress_api_key,
        };
      }
    }

    if (!connection?.site_url) {
      return Response.json({ error: 'WordPress connection not found.' }, { status: 404 });
    }

    const baseUrl = `${connection.rest_url || connection.site_url}`.replace(/\/$/, '').replace(/\/wp-json$/, '');
    const endpoint = baseUrl + '/wp-json/ai-seo-autopilot/v1/push-draft';
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-ai-seo-autopilot-key': connection.api_key,
      },
      body: JSON.stringify({
        title: draft.title,
        slug: draft.slug,
        excerpt: draft.excerpt,
        content: draft.html_file_url ? await (await fetch(draft.html_file_url)).text() : draft.html_content,
        meta_title: draft.meta_title,
        meta_description: draft.meta_description,
        faq_html: draft.faq_html,
        schema_markup: draft.schema_markup,
      })
    });

    const rawText = await response.text();
    let result = {};
    try {
      result = JSON.parse(rawText || '{}');
    } catch {
      result = { raw_response: rawText };
    }
    if (!response.ok) {
      return Response.json({ error: result.error || 'WordPress rejected the draft push.', status_code: response.status, details: result }, { status: 500 });
    }

    await base44.asServiceRole.entities.ContentDraft.update(draft.id, { wordpress_status: 'draft', status: 'published' });
    await base44.asServiceRole.entities.ActivityLog.create({
      workspace_id: '',
      project_id: draft.project_id,
      entity_type: 'ContentDraft',
      entity_id: draft.id,
      action_type: 'push_wordpress_draft',
      description: `Draft pushed to WordPress: ${toText(draft.title)}`,
      metadata: JSON.stringify(result)
    });

    return Response.json({ success: true, wordpress: result, draft_id: draft.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});