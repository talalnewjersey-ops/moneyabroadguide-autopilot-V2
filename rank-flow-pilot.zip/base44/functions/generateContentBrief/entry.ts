import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import OpenAI from 'npm:openai@4.104.0';

const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY') });
const toText = (value = '') => typeof value === 'string' ? value : value == null ? '' : String(value);
const toArray = (value) => Array.isArray(value) ? value : [];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'generateContentBrief', required_fields: ['project_id', 'primary_keyword'], optional_fields: ['audience', 'country', 'tone', 'article_type'] });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.project_id || !payload.primary_keyword) {
      return Response.json({ endpoint: 'generateContentBrief', required_fields: ['project_id', 'primary_keyword'], optional_fields: ['audience', 'country', 'tone', 'article_type'] });
    }

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      response_format: { type: 'json_object' },
      messages: [
        {
          role: 'system',
          content: 'You create original SEO content briefs for finance websites serving expats, immigrants, newcomers, foreign workers, and international students in the USA and Canada. Return only valid JSON.'
        },
        {
          role: 'user',
          content: `Create a production-ready content brief for the keyword "${toText(payload.primary_keyword)}". Audience: ${toText(payload.audience || 'expats and newcomers')}. Country: ${toText(payload.country || 'USA and Canada')}. Tone: ${toText(payload.tone || 'helpful expert')}. Article type: ${toText(payload.article_type || 'guide')}. Return JSON with title, secondary_keywords, search_intent, outline, faq_queries, internal_link_targets.`
        }
      ]
    });

    const parsed = JSON.parse(response.choices[0]?.message?.content || '{}');
    const brief = {
      project_id: payload.project_id,
      title: toText(parsed.title || payload.primary_keyword),
      primary_keyword: toText(payload.primary_keyword),
      secondary_keywords: toArray(parsed.secondary_keywords).map((item) => toText(item)).filter(Boolean),
      search_intent: toText(parsed.search_intent || 'informational'),
      audience: toText(payload.audience || 'expats and newcomers'),
      country: toText(payload.country || 'USA and Canada'),
      tone: toText(payload.tone || 'helpful expert'),
      outline: toText(parsed.outline),
      faq_queries: toArray(parsed.faq_queries).map((item) => toText(item)).filter(Boolean),
      internal_link_targets: toArray(parsed.internal_link_targets).map((item) => toText(item)).filter(Boolean),
      status: 'ready',
    };

    const created = await base44.entities.ContentBrief.create(brief);
    await base44.entities.AIUsageLog.create({
      workspace_id: toText(payload.workspace_id),
      project_id: payload.project_id,
      feature_name: 'content_brief',
      provider: 'openai',
      model: 'gpt-4o-mini',
      status: 'success'
    });

    return Response.json({ success: true, brief: created });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});