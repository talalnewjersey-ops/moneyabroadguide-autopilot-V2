import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function BillingPlaceholder() {
  const { data: workspaces = [] } = useQuery({ queryKey: ['workspaces'], queryFn: () => base44.entities.Workspace.list('-created_date', 1) });
  const workspace = workspaces[0];
  const plans = ['free', 'growth', 'agency'];
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <PageHeader title="Billing" description="Billing-ready architecture with workspace plans, limits, and usage visibility." />
      <div className="grid md:grid-cols-3 gap-4">{plans.map((plan) => <Card key={plan} className={workspace?.plan_status === plan ? 'border-blue-500' : ''}><CardContent className="p-5"><h3 className="font-semibold text-gray-900 capitalize">{plan}</h3><p className="text-sm text-gray-500 mt-1">Usage tokens: {workspace?.usage_tokens || 0}</p></CardContent></Card>)}</div>
    </div>
  );
}