import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';
import JSZip from 'npm:jszip@3.10.1';

const pluginPhp = String.raw`<?php
/**
 * Plugin Name: MoneyAbroadGuide Legal Pages Generator
 * Description: Automatically creates and publishes Privacy Policy, About Us, and Contact pages, then adds them to WordPress menus and footer for compliance.
 * Version: 1.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: MoneyAbroadGuide
 */

if (!defined('ABSPATH')) {
    exit;
}

final class MoneyAbroadGuide_Legal_Pages_Generator {
    private const OPTION_PAGE_IDS = 'mag_legal_page_ids';
    private const DISCLOSURE_TEXT = 'This site may earn commissions from affiliate links at no extra cost to you.';

    public static function activate() {
        $instance = new self();
        $page_ids = $instance->create_or_update_pages();
        update_option(self::OPTION_PAGE_IDS, $page_ids, false);
        $instance->sync_menus($page_ids);
        flush_rewrite_rules();
    }

    public function __construct() {
        add_action('admin_init', [$this, 'maybe_bootstrap_pages']);
        add_action('admin_notices', [$this, 'render_admin_notice']);
        add_action('wp_head', [$this, 'output_head_tags'], 5);
        add_action('wp_footer', [$this, 'render_footer_compliance'], 20);
    }

    public function maybe_bootstrap_pages() {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }

        $page_ids = $this->get_page_ids();
        $needs_sync = count($page_ids) < count($this->pages_config());

        if (!$needs_sync) {
            foreach (array_keys($this->pages_config()) as $slug) {
                if (empty($page_ids[$slug]) || get_post_status($page_ids[$slug]) !== 'publish') {
                    $needs_sync = true;
                    break;
                }
            }
        }

        if (!$needs_sync) {
            return;
        }

        $page_ids = $this->create_or_update_pages();
        update_option(self::OPTION_PAGE_IDS, $page_ids, false);
        $this->sync_menus($page_ids);
        set_transient('mag_legal_pages_notice', 'synced', 60);
    }

    public function render_admin_notice() {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }

        if (get_transient('mag_legal_pages_notice') !== 'synced') {
            return;
        }

        delete_transient('mag_legal_pages_notice');
        echo '<div class="notice notice-success is-dismissible"><p>MoneyAbroadGuide Legal Pages Generator has created or updated the Privacy Policy, About, and Contact pages.</p></div>';
    }

    private function pages_config() {
        return [
            'privacy-policy' => [
                'title' => 'Privacy Policy',
                'menu_title' => 'Privacy Policy',
                'meta_description' => 'Read the MoneyAbroadGuide.com Privacy Policy, including cookies, affiliate disclosures, and contact information.',
                'schema_type' => 'WebPage',
                'content' => <<<'HTML'
<h1>Privacy Policy</h1>
<p>Last updated: March 2026</p>

<p>Welcome to MoneyAbroadGuide.com. Your privacy is important to us.</p>

<h2>Information We Collect</h2>
<p>We may collect personal data such as email and usage data.</p>

<h2>Cookies</h2>
<p>We use cookies for analytics and affiliate tracking.</p>

<h2>Affiliate Disclosure</h2>
<p>We may earn commissions through affiliate links at no extra cost to users.</p>

<h2>Third Parties</h2>
<p>We may work with affiliate platforms such as Impact.com.</p>

<h2>Contact</h2>
<p>Email: contact@moneyabroadguide.com</p>
HTML,
            ],
            'about-us' => [
                'title' => 'About Us',
                'menu_title' => 'About',
                'meta_description' => 'Learn about Money Abroad Guide, our mission, who we help, and our affiliate transparency policy.',
                'schema_type' => 'AboutPage',
                'content' => <<<'HTML'
<h1>About Money Abroad Guide</h1>

<p>MoneyAbroadGuide.com helps immigrants and expats manage their finances in the USA and Canada.</p>

<h2>Mission</h2>
<p>We provide clear and actionable financial guidance.</p>

<h2>Who We Help</h2>
<ul>
<li>Newcomers</li>
<li>Immigrants</li>
<li>Expats</li>
</ul>

<h2>Explore</h2>
<p>
<a href="https://preview-sandbox--69b0e5e335d4b05b71b39d24.base44.app/About?hide_badge=true&amp;base44_data_env=prod&amp;server_url=https%3A%2F%2Fpreview-sandbox--69b0e5e335d4b05b71b39d24.base44.app&amp;_preview_token=V-RFNyItU_l2Md74q19QUNCjUEIg0-iynqWwAr1IuCc" target="_blank" rel="noopener noreferrer">
View About Page Preview
</a>
</p>

<h2>Affiliate Transparency</h2>
<p>We may earn commissions through affiliate partnerships.</p>

<h2>Founder</h2>
<p>Created by Talal Eddaouahiri.</p>

<p><strong>Contact:</strong> contact@moneyabroadguide.com</p>
HTML,
            ],
            'contact' => [
                'title' => 'Contact',
                'menu_title' => 'Contact',
                'meta_description' => 'Contact MoneyAbroadGuide.com for partnerships and general inquiries.',
                'schema_type' => 'ContactPage',
                'content' => <<<'HTML'
<h1>Contact Us</h1>

<p>Email: contact@moneyabroadguide.com</p>

<p>For partnerships, use subject: Partnership</p>

<p>Response time: 24-48 hours</p>

<p>This site provides educational financial content only.</p>
HTML,
            ],
        ];
    }

    private function create_or_update_pages() {
        $ids = [];

        foreach ($this->pages_config() as $slug => $config) {
            $existing = get_page_by_path($slug, OBJECT, 'page');
            $page_data = [
                'post_type' => 'page',
                'post_title' => $config['title'],
                'post_name' => $slug,
                'post_status' => 'publish',
                'post_content' => $config['content'],
                'post_excerpt' => $config['meta_description'],
                'comment_status' => 'closed',
                'ping_status' => 'closed',
            ];

            if ($existing instanceof WP_Post) {
                $page_data['ID'] = $existing->ID;
                $page_id = wp_update_post(wp_slash($page_data), true);
            } else {
                $page_id = wp_insert_post(wp_slash($page_data), true);
            }

            if (!is_wp_error($page_id) && $page_id) {
                $ids[$slug] = (int) $page_id;
            }
        }

        return $ids;
    }

    private function find_location(array $preferred_locations) {
        $registered = array_keys(get_registered_nav_menus());

        foreach ($preferred_locations as $location) {
            if (in_array($location, $registered, true)) {
                return $location;
            }
        }

        return '';
    }

    private function ensure_menu_for_location($location, $fallback_name) {
        if (!$location) {
            return 0;
        }

        $locations = get_nav_menu_locations();
        if (!empty($locations[$location])) {
            return (int) $locations[$location];
        }

        $menu = wp_get_nav_menu_object($fallback_name);
        $menu_id = $menu ? (int) $menu->term_id : (int) wp_create_nav_menu($fallback_name);

        if ($menu_id > 0) {
            $locations[$location] = $menu_id;
            set_theme_mod('nav_menu_locations', $locations);
        }

        return $menu_id;
    }

    private function add_pages_to_menu($menu_id, array $page_ids) {
        if (!$menu_id || empty($page_ids)) {
            return;
        }

        $items = wp_get_nav_menu_items($menu_id) ?: [];
        $existing_page_ids = [];

        foreach ($items as $item) {
            if ($item->object === 'page') {
                $existing_page_ids[] = (int) $item->object_id;
            }
        }

        foreach ($page_ids as $page_id) {
            if (in_array((int) $page_id, $existing_page_ids, true)) {
                continue;
            }

            wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-object-id' => (int) $page_id,
                'menu-item-object' => 'page',
                'menu-item-type' => 'post_type',
                'menu-item-status' => 'publish',
            ]);
        }
    }

    private function sync_menus(array $page_ids) {
        $primary_location = $this->find_location(['primary', 'astra-menu', 'menu-1', 'main-menu', 'header_menu', 'header-menu']);
        $footer_location = $this->find_location(['footer', 'footer_menu', 'footer-menu', 'footer-1']);

        $primary_menu_id = $this->ensure_menu_for_location($primary_location, 'Primary Menu');
        $footer_menu_id = $this->ensure_menu_for_location($footer_location, 'Footer Menu');

        $this->add_pages_to_menu($primary_menu_id, $page_ids);
        $this->add_pages_to_menu($footer_menu_id, $page_ids);
    }

    private function get_page_ids() {
        $page_ids = get_option(self::OPTION_PAGE_IDS, []);
        return is_array($page_ids) ? $page_ids : [];
    }

    private function get_current_legal_page() {
        if (!is_page()) {
            return null;
        }

        $page_ids = $this->get_page_ids();
        if (empty($page_ids)) {
            return null;
        }

        $current_id = get_queried_object_id();
        foreach ($this->pages_config() as $slug => $config) {
            if (!empty($page_ids[$slug]) && (int) $page_ids[$slug] === (int) $current_id) {
                return [
                    'slug' => $slug,
                    'config' => $config,
                    'id' => (int) $current_id,
                ];
            }
        }

        return null;
    }

    public function output_head_tags() {
        if (is_admin()) {
            return;
        }

        echo '<style>.mag-legal-footer{margin-top:24px;padding:18px 20px;text-align:center;font-size:14px;line-height:1.7}.mag-legal-footer p{margin:0 0 6px}.mag-legal-footer p:last-child{margin-bottom:0}.mag-legal-footer a{margin:0 8px}</style>';

        $current = $this->get_current_legal_page();
        if (!$current) {
            return;
        }

        $config = $current['config'];
        $title = wp_strip_all_tags(get_the_title($current['id']));
        $description = $config['meta_description'];
        $url = get_permalink($current['id']);
        $schema = [
            '@context' => 'https://schema.org',
            '@type' => $config['schema_type'],
            'name' => $title,
            'url' => $url,
            'description' => $description,
            'publisher' => [
                '@type' => 'Organization',
                'name' => 'Money Abroad Guide',
                'url' => home_url('/'),
            ],
            'author' => [
                '@type' => 'Person',
                'name' => 'Talal Eddaouahiri',
            ],
        ];

        echo '<meta name="description" content="' . esc_attr($description) . '">';
        echo '<meta name="robots" content="index,follow">';
        echo '<link rel="canonical" href="' . esc_url($url) . '">';
        echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
    }

    public function render_footer_compliance() {
        if (is_admin()) {
            return;
        }

        $page_ids = $this->get_page_ids();
        if (empty($page_ids)) {
            return;
        }

        $footer_location = $this->find_location(['footer', 'footer_menu', 'footer-menu', 'footer-1']);
        $locations = get_nav_menu_locations();
        $has_footer_menu = $footer_location && !empty($locations[$footer_location]);

        $links = [];
        foreach (['privacy-policy', 'about-us', 'contact'] as $slug) {
            if (!empty($page_ids[$slug]) && get_post_status($page_ids[$slug]) === 'publish') {
                $links[] = '<a href="' . esc_url(get_permalink($page_ids[$slug])) . '">' . esc_html(get_the_title($page_ids[$slug])) . '</a>';
            }
        }

        echo '<div class="mag-legal-footer" aria-label="Legal and affiliate disclosure">';
        if (!$has_footer_menu && !empty($links)) {
            echo '<p>' . implode(' | ', $links) . '</p>';
        }
        echo '<p>' . esc_html(self::DISCLOSURE_TEXT) . '</p>';
        echo '</div>';
    }
}

register_activation_hook(__FILE__, ['MoneyAbroadGuide_Legal_Pages_Generator', 'activate']);
new MoneyAbroadGuide_Legal_Pages_Generator();`;

async function buildZip() {
  const zip = new JSZip();
  const folder = zip.folder('moneyabroadguide-legal-pages-generator');
  folder.file('moneyabroadguide-legal-pages-generator.php', pluginPhp);
  return await zip.generateAsync({ type: 'uint8array' });
}

Deno.serve(async (req) => {
  try {
    const zipContent = await buildZip();

    if (req.method === 'GET') {
      return new Response(zipContent, {
        status: 200,
        headers: {
          'Content-Type': 'application/zip',
          'Content-Disposition': 'attachment; filename="moneyabroadguide-legal-pages-generator.zip"',
          'Cache-Control': 'no-store',
        },
      });
    }

    const base44 = createClientFromRequest(req);
    const zipFile = new File([zipContent], 'moneyabroadguide-legal-pages-generator.zip', { type: 'application/zip' });
    const upload = await base44.asServiceRole.integrations.Core.UploadFile({ file: zipFile });

    return Response.json({
      success: true,
      file_name: 'moneyabroadguide-legal-pages-generator.zip',
      folder_name: 'moneyabroadguide-legal-pages-generator',
      files: ['moneyabroadguide-legal-pages-generator.php'],
      file_url: upload.file_url,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});