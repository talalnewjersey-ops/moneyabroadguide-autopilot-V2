import React from 'react';

export default function SectionHeading({ eyebrow, title, description, className = '' }) {
  return (
    <div className={`mx-auto mb-8 max-w-3xl space-y-4 text-center sm:mb-10 ${className}`}>
      {eyebrow ? (
        <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#1F8F6A]">
          {eyebrow}
        </p>
      ) : null}
      <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 sm:text-4xl lg:text-[2.8rem] lg:leading-[1.1]">
        {title}
      </h2>
      {description ? (
        <p className="mx-auto max-w-2xl text-base leading-8 text-slate-500 sm:text-lg">
          {description}
        </p>
      ) : null}
    </div>
  );
}