# MoneyAbroadGuide – Elementor Homepage Blueprint

Use this guide to recreate the current landing page natively inside WordPress with Elementor and set it as the homepage.

---

## 1) Create the page

- WordPress → Pages → Add New
- Title: `Home`
- Template: `Elementor Full Width` or `Canvas` (preferred if header/footer are handled by theme builder)
- Click **Edit with Elementor**

---

## 2) Global structure

Build the page in this order:

1. Header
2. Hero
3. Benefits
4. User Story
5. Articles
6. Comparison table
7. Trust metrics
8. Additional guides
9. Final CTA

Recommended content width:
- Main content container: **920px**
- Keep side whitespace on desktop for future AdSense placement
- Section vertical padding: **56px to 72px**
- Border radius: **24px to 32px**
- Soft shadow everywhere, never heavy

---

## 3) Global visual settings

### Colors
- Primary dark navy: `#0B1F3A`
- Accent green: `#1F8F6A`
- Soft background: `#F8FAFC`
- Body text: `#64748B`
- Headings: `#0F172A`
- Card background: `#FFFFFF`

### Typography
- Font family: **Inter**
- H1: 52–60px, 800 weight, tight line-height
- H2: 36–44px, 800 weight
- H3: 24–28px, 700 or 800 weight
- Body: 16–20px, 400/500 weight

### Effects
- Card radius: 28px
- Button radius: full rounded
- Card shadow: soft, premium
- Hover on cards: slight lift + stronger shadow
- Hover on links/menu: underline animation or soft color transition

---

## 4) Header

### Layout
Container width: 920px
- Left: official MoneyAbroadGuide logo
- Center/right: nav menu
- Right: CTA button

### Logo rules
- Use the official logo image
- Do **not** crop
- Keep object-fit behavior equivalent to `contain`
- Add padding around logo area
- Make it visually larger than standard blog logos

### Menu items
- Home
- Start here
- Newcomers to the USA
- Newcomers to Canada

### Header CTA
Text:
- `Find the Cheapest Transfer Now`

### Header style
- White semi-transparent background
- Thin bottom border
- Soft blur effect if possible
- Sticky header enabled

---

## 5) Hero section

### Section settings
- No empty space above the hero
- Background: soft white/light gradient
- Center all content

### Eyebrow text
`Trusted money transfer comparison for immigrants, expats, and global families`

### H1
`Stop Losing Hundreds on Every International Transfer`

### Subheadline
`Compare transfer services, find the cheapest option, and save money instantly with better fees, better exchange rates, and smarter provider choices.`

### Primary CTA
`Compare Fees Now`
Link to comparison or calculator section

### Secondary CTA
`Start Free`
Link to Start Here / Newcomers section

### Trust pills
- Used by expats in USA & Canada
- 80+ providers analyzed
- Updated weekly

### Comparison summary card under hero text
Title:
`Compare top money transfer services at a glance`

Description:
`See which providers help you save more, move faster, and get stronger exchange value before you click out.`

Columns:
- Service
- Fees
- Speed
- Exchange Rate
- Rating
- Action

Rows:
- Wise — Low, transparent — Minutes to 2 days — Mid-market rate — 4.9/5 — View deal
- Remitly — Promo-friendly — Express available — Competitive — 4.8/5 — View deal
- OFX — No fixed fee — 1–3 days — Strong on large transfers — 4.7/5 — View deal
- Xe Money Transfer — Varies — Same day to 3 days — Live rate tools — 4.6/5 — View deal

Mini highlights below the table:
- Lowest cost — Wise
- Fast transfers — Remitly
- Large amounts — OFX
- Rate tools — Xe

---

## 6) Calculator block

Place the calculator to the right of the hero on desktop, below on mobile.

### Content
- Title: `Find the best provider for your transfer`
- Fields:
  - Amount
  - From country
  - To country
- Best provider block
- Savings block
- Stat cards:
  - Total cost
  - Received amount
  - Fee
  - Speed
- CTA button:
  - `Compare Fees Now`

### UX rules
- Equal card heights
- Numbers must fit without wrapping awkwardly
- Use 2-column stat layout on smaller screens and 4-column on large screens

---

## 7) Benefits section

### Section title
`Built to save money, build trust, and drive action`

### Subtitle
`This experience is designed like a fintech platform, not a generic blog, so readers move faster from research to conversion.`

### 3 cards
1. `Save more on every transfer`
   - Compare real transfer fees and exchange rate margins in one place and avoid hidden costs.
2. `Make safer financial decisions`
   - Transparent provider comparisons and educational content create trust before users click.
3. `Convert faster with confidence`
   - A cleaner comparison flow helps users choose the strongest option for their route.

---

## 8) User story section

Create a premium dark testimonial/benefit section.

### Eyebrow
`Real savings story`

### Main title
`Ahmed saved $420 a year by switching transfer provider`

### Story text
`Ahmed was sending money home every month from the USA and assumed his usual provider was already competitive. After comparing fees, FX margins, and delivery times, he switched to a lower-cost option and kept hundreds of dollars each year.`

### Supporting cards
- Before switching:
  `Higher fees + weak FX`
- After comparing:
  `$420/year saved`

### CTA buttons
- `Compare Fees Now`
- `See why users trust us`

---

## 9) Articles section

### Section title
`Latest insights for newcomers to the USA and Canada`

### Subtitle
`Focused educational articles designed for immigrants, expats, and international workers navigating financial systems in North America.`

### 3 cards only, no logos inside cards
1. `Newcomers to the USA`
   - Educational explanations of U.S. financial concepts, including banking basics, saving, and everyday money terminology.
   - CTA: `Read Full Guide`
2. `Newcomers to Canada`
   - Educational information to help readers understand Canadian banking systems, savings basics, and financial fundamentals.
   - CTA: `Read Full Guide`
3. `Start Here for Newcomers`
   - A simple starting point for immigrants learning how financial systems work in the USA and Canada.
   - CTA: `Read Full Guide`

### Card style
- Equal heights
- Same vertical rhythm
- Soft shadow
- Rounded corners
- Hover lift effect

---

## 10) Full comparison section

### Section title
`Compare providers, reduce fees, and move money with more confidence`

### Subtitle
`This table is built to help users compare total value fast and click through only when the offer matches their route, urgency, and amount.`

Use the same 4 providers and CTA buttons.

CTA below table:
- `Compare Fees Now`

---

## 11) Trust metrics section

### Title
`Financial authority that helps users trust the comparison`

### Subtitle
`We focus on real pricing, better clarity, and a more trustworthy user experience so people feel safe making money decisions here.`

### Metrics
- 12,000+ — Expats helped
- $1.8M+ — Potential savings
- 80+ — Providers reviewed
- Weekly — Updated data

CTA below metrics:
- `Compare Fees Now`

---

## 12) Additional guides section

### Title
`Educational content that supports conversion, trust, and repeat visits`

### Subtitle
`Use helpful guides to educate readers first, then direct them back to the calculator when they are ready to compare providers.`

Use 3 clean cards with CTA text:
- `Read Full Guide`

---

## 13) Final CTA section

### Eyebrow
`Ready to save more?`

### Title
`Compare fees, protect your money, and choose a better transfer today`

### Text
`MoneyAbroadGuide helps users avoid hidden markups, compare transfer rates faster, and move money with more confidence.`

### Buttons
- `Compare Fees Now`
- `Start Free`

Use dark gradient background from navy to green.

---

## 14) AdSense-friendly layout

To keep space for future ads:
- Keep all main content centered in **920px max width**
- Do **not** stretch sections full width for text/cards
- Leave left and right whitespace on desktop
- If needed later, add ad containers in theme/sidebar or custom placements outside the 920px content frame

---

## 15) Set as homepage in WordPress

After publishing:
- WordPress → Settings → Reading
- `Your homepage displays` → `A static page`
- Homepage → select `Home`
- Save

---

## 16) Recommended Elementor widgets

Use these widgets:
- Container / Flexbox containers
- Heading
- Text Editor
- Button
- Image
- Icon Box
- Icon
- Inner Container
- HTML widget (if you want to paste table markup)

---

## 17) Fast implementation order

If you want the fastest clean rebuild, do it in this order:
1. Header + logo
2. Hero + CTAs
3. Calculator block
4. User story
5. Articles cards
6. Comparison table
7. Trust metrics
8. Final CTA
9. Set as homepage

---

## 18) If you want me to continue

Next step I can prepare for you:
- exact Elementor section-by-section settings
- ready-to-paste copy for every widget
- or a ready HTML structure to paste into Elementor sections