import React from 'react';
import { ArrowRight, Compass, Flag, MapPinned } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import SectionReveal from '@/components/home/SectionReveal';
import SectionHeading from '@/components/home/SectionHeading';

const startHereArticles = [
  {
    title: 'Cheapest Way to Send Money Abroad',
    description: 'Start with the simplest guide to compare fees, exchange rates, and delivery speed.',
    href: '/CheapestWayToSendMoneyAbroadCompleteGuide',
  },
  {
    title: 'How to Choose the Best Money Transfer Service',
    description: 'A clear method to choose the right service based on your amount and destination.',
    href: '/HowToChooseTheBestMoneyTransferService',
  },
  {
    title: 'Best International Money Transfer Services 2026',
    description: 'A broad ranking of the strongest options before comparing a specific route.',
    href: '/BestInternationalMoneyTransferServices2026',
  },
];

const usaArticles = [
  {
    title: 'USA to France',
    description: 'A dedicated page to compare the best options between the USA and France.',
    href: '/UsaToFrance',
  },
  {
    title: 'USA to India',
    description: 'Top apps and transfer options for sending money from the USA to India.',
    href: '/UsaToIndia',
  },
  {
    title: 'USA to Philippines',
    description: 'A practical guide for fast and affordable transfers to the Philippines.',
    href: '/UsaToPhilippines',
  },
];

const canadaArticles = [
  {
    title: 'Canada to France',
    description: 'The strongest options for transfers from Canada to France.',
    href: '/CanadaToFrance',
  },
  {
    title: 'Canada to India',
    description: 'A clear selection of lower-cost options for this popular route.',
    href: '/CanadaToIndia',
  },
  {
    title: 'Canada to Philippines',
    description: 'A practical route guide for fast and cost-efficient transfers to the Philippines.',
    href: '/CanadaToPhilippines',
  },
];

function ArticleGroup({ id, eyebrow, title, icon: Icon, items }) {
  return (
    <section id={id} className="scroll-mt-28">
      <SectionHeading eyebrow={eyebrow} title={title} className="mb-8" />

      <div className="grid gap-6 md:grid-cols-3">
        {items.map((item) => (
          <Card key={item.href} className="fintech-card fintech-card-hover h-full rounded-[28px] border-0">
            <CardContent className="flex h-full flex-col p-7">
              <div className="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[#EAF7F1] text-[#1F8F6A]">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="text-xl font-bold text-slate-950">{item.title}</h3>
              <p className="mt-3 flex-1 text-sm leading-7 text-slate-500">{item.description}</p>
              <a href={item.href} className="mt-6 inline-flex w-fit items-center gap-2 rounded-full border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:border-slate-300 hover:bg-slate-50">
                Read article <ArrowRight className="h-4 w-4" />
              </a>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}

export default function HomeArticleCollections() {
  return (
    <section className="bg-white">
      <SectionReveal className="mx-auto max-w-[920px] space-y-14 px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
        <ArticleGroup id="start-here" eyebrow="Start here" title="Start here" icon={Compass} items={startHereArticles} />
        <ArticleGroup id="newcomers-usa" eyebrow="Newcomers to the USA" title="Guides for newcomers to the USA" icon={Flag} items={usaArticles} />
        <ArticleGroup id="newcomers-canada" eyebrow="Newcomers to Canada" title="Guides for newcomers to Canada" icon={MapPinned} items={canadaArticles} />
      </SectionReveal>
    </section>
  );
}