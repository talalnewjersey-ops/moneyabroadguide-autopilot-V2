import React from 'react';
import HomeHeader from '@/components/home/HomeHeader';
import HomeFooter from '@/components/home/HomeFooter';

const expertise = [
  'Newcomer banking in the USA and Canada',
  'International money transfers and fee comparison',
  'Credit building for immigrants and expats',
  'Practical financial setup for life in North America',
];

const profilePhotoUrl = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/9b43679f8_TalalEddaouahiriafinancialadvisorspecializingintheUnitedStatesandCanadafinancialsystemsHefoundedMoneyAbroadGuide.png';

export default function About() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-950">
      <HomeHeader />

      <main className="mx-auto max-w-[920px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
        <section className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-10">
          <div className="mx-auto max-w-3xl text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#16a34a]">About Money Abroad Guide</p>
            <h1 className="mt-3 text-4xl font-extrabold tracking-tight sm:text-5xl">Meet Talal Eddaouahiri</h1>
            <p className="mt-5 text-lg leading-8 text-slate-600">
              Money Abroad Guide is a financial education platform built to help immigrants, international students, and expats navigate life in North America with more clarity and confidence.
            </p>
          </div>
        </section>

        <section className="mt-8 rounded-[28px] border border-slate-200 bg-white p-8 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-10">
          <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-start">
            <div>
              <div className="mb-6 rounded-[24px] bg-slate-50 p-3 shadow-[0_12px_30px_rgba(15,23,42,0.08)]">
                <img
                  src={profilePhotoUrl}
                  alt="Talal Eddaouahiri"
                  className="w-full rounded-[20px] object-contain object-top"
                />
              </div>
              <h2 className="text-3xl font-extrabold tracking-tight text-slate-950">Who am I?</h2>
              <p className="mt-4 text-base leading-8 text-slate-600">
                Talal Eddaouahiri is a financial advisor specialising in the financial systems of the United States and Canada. He founded Money Abroad Guide to provide honest, jargon-free guidance for immigrants, international students, and expats navigating their new lives in North America.
              </p>
              <p className="mt-4 text-base leading-8 text-slate-600">
                With a focus on practical, real-world advice, Talal helps newcomers build their financial future — from opening a first bank account to understanding credit, taxes, and money transfers — with greater confidence.
              </p>
            </div>

            <div className="rounded-[24px] border border-slate-200 bg-slate-50 p-6">
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-[#16a34a]">Core expertise</p>
              <ul className="mt-4 space-y-3 text-sm leading-7 text-slate-600">
                {expertise.map((item) => (
                  <li key={item} className="rounded-2xl border border-slate-200 bg-white px-4 py-3">
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section className="mt-8 rounded-[28px] border border-slate-200 bg-white p-8 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-10">
          <h2 className="text-center text-3xl font-extrabold tracking-tight text-slate-950">Why Money Abroad Guide exists</h2>
          <div className="mt-6 space-y-4 text-base leading-8 text-slate-600">
            <p>
              The goal of Money Abroad Guide is to make practical financial information easier to understand for people starting over in a new country. That includes banking, international transfers, budgeting, taxes, and credit-building basics that often feel confusing or full of jargon.
            </p>
            <p>
              The site is built around real user needs, clear explanations, and independent comparisons. Educational clarity comes first, and commercial partnerships do not control editorial rankings or recommendations.
            </p>
          </div>
        </section>

        <section className="mt-8 rounded-[28px] border border-slate-200 bg-white p-8 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-10">
          <h2 className="text-center text-3xl font-extrabold tracking-tight text-slate-950">How content is created</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-5 text-center">
              <strong className="block text-slate-950">Research first</strong>
              <p className="mt-3 text-sm leading-7 text-slate-500">Topics are selected based on real newcomer financial needs and high-value questions.</p>
            </div>
            <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-5 text-center">
              <strong className="block text-slate-950">Independent review</strong>
              <p className="mt-3 text-sm leading-7 text-slate-500">Comparisons are evaluated using fees, value, clarity, and practical usefulness.</p>
            </div>
            <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-5 text-center">
              <strong className="block text-slate-950">Regular updates</strong>
              <p className="mt-3 text-sm leading-7 text-slate-500">Content is reviewed and refreshed to stay useful for current readers and current market conditions.</p>
            </div>
          </div>
        </section>

        <section className="mt-8 rounded-[28px] border border-slate-200 bg-white p-8 text-center shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-10">
          <h2 className="text-3xl font-extrabold tracking-tight text-slate-950">Need help or want to get in touch?</h2>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-8 text-slate-600">
            If you want to learn more about Money Abroad Guide or contact the team, use the contact page below.
          </p>
          <div className="mt-6 flex justify-center">
            <a href="/contact" className="inline-flex h-14 items-center justify-center rounded-full bg-[#16a34a] px-8 text-base font-semibold text-white shadow-[0_18px_40px_rgba(22,163,74,0.25)] transition hover:bg-[#166534]">
              Go to Contact Page
            </a>
          </div>
        </section>
      </main>

      <HomeFooter />
    </div>
  );
}