import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function WorkspaceDashboard() {
  const { data: workspaces = [] } = useQuery({ queryKey: ['workspace-dashboard'], queryFn: () => base44.entities.Workspace.list('-created_date', 1) });
  const workspace = workspaces[0];
  const metrics = [
    ['Plan', workspace?.plan_status || 'free'],
    ['Usage tokens', workspace?.usage_tokens || 0],
    ['Default market', workspace?.default_country || 'USA and Canada'],
    ['Language', workspace?.default_language || 'English'],
  ];
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <PageHeader title="Workspace Dashboard" description="Monitor your team, defaults, usage, and operating context." />
      <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4">{metrics.map(([label, value]) => <Card key={label}><CardContent className="p-5"><p className="text-sm text-gray-500">{label}</p><p className="text-2xl font-semibold text-gray-900 mt-2">{value}</p></CardContent></Card>)}</div>
    </div>
  );
}