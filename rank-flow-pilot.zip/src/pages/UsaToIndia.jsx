import React from 'react';
import CorridorLandingPage from '@/components/transfers/CorridorLandingPage';
import { transferCorridors } from '@/lib/transferCorridors';

export default function UsaToIndia() {
  return <CorridorLandingPage page={transferCorridors.UsaToIndia} />;
}