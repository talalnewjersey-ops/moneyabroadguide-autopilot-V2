import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const normalizeUrl = (url = '') => String(url).toLowerCase().trim().replace(/^https?:\/\//, '').replace(/\/$/, '');
const primaryDomain = 'moneyabroadguide.com';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const websites = await base44.asServiceRole.entities.Website.list();
    const projects = await base44.asServiceRole.entities.Project.list();
    const foreignWebsites = websites.filter((item) => normalizeUrl(item.url) !== primaryDomain);
    const foreignWebsiteIds = foreignWebsites.map((item) => item.id);
    const foreignProjectIds = [...new Set([
      ...foreignWebsites.map((item) => item.project_id).filter(Boolean),
      ...projects.filter((item) => normalizeUrl(item.site_url || item.domain || '') !== primaryDomain).map((item) => item.id)
    ])];

    for (const item of await base44.asServiceRole.entities.Keyword.list()) {
      if (foreignWebsiteIds.includes(item.website_id)) await base44.asServiceRole.entities.Keyword.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.ContentRecommendation.list()) {
      if (foreignWebsiteIds.includes(item.website_id)) await base44.asServiceRole.entities.ContentRecommendation.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.AuditIssue.list()) {
      if (foreignWebsiteIds.includes(item.website_id) || foreignProjectIds.includes(item.project_id)) await base44.asServiceRole.entities.AuditIssue.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.AppliedFix.list()) {
      if (foreignWebsiteIds.includes(item.website_id) || foreignProjectIds.includes(item.project_id)) await base44.asServiceRole.entities.AppliedFix.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.Competitor.list()) {
      if (foreignWebsiteIds.includes(item.website_id)) await base44.asServiceRole.entities.Competitor.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.WordPressConnection.list()) {
      if (foreignWebsiteIds.includes(item.website_id) || foreignProjectIds.includes(item.project_id)) await base44.asServiceRole.entities.WordPressConnection.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.ContentBrief.list()) {
      if (foreignProjectIds.includes(item.project_id)) await base44.asServiceRole.entities.ContentBrief.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.ContentDraft.list()) {
      if (foreignProjectIds.includes(item.project_id)) await base44.asServiceRole.entities.ContentDraft.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.KeywordCluster.list()) {
      if (foreignProjectIds.includes(item.project_id)) await base44.asServiceRole.entities.KeywordCluster.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.KeywordRanking.list()) {
      if (foreignProjectIds.includes(item.project_id)) await base44.asServiceRole.entities.KeywordRanking.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.Report.list()) {
      if (foreignProjectIds.includes(item.project_id)) await base44.asServiceRole.entities.Report.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.ActivityLog.list()) {
      if (foreignProjectIds.includes(item.project_id)) await base44.asServiceRole.entities.ActivityLog.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.AutomationLog.list()) {
      if (foreignWebsiteIds.includes(item.website_id)) await base44.asServiceRole.entities.AutomationLog.delete(item.id);
    }
    for (const item of foreignWebsites) {
      await base44.asServiceRole.entities.Website.delete(item.id);
    }
    for (const item of await base44.asServiceRole.entities.Project.list()) {
      if (foreignProjectIds.includes(item.id)) await base44.asServiceRole.entities.Project.delete(item.id);
    }

    return Response.json({
      success: true,
      removed_websites: foreignWebsiteIds.length,
      removed_projects: foreignProjectIds.length,
      primary_domain: primaryDomain,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});