import React, { useState } from 'react';
import Sidebar from './components/layout/Sidebar';
import TopBar from './components/layout/TopBar';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { cn } from '@/lib/utils';

export default function Layout({ children, currentPageName }) {
  const [collapsed, setCollapsed] = useState(false);
  const [optimizing, setOptimizing] = useState(false);
  const navigate = useNavigate();

  const handleOptimize = () => {
    setOptimizing(true);
    navigate(createPageUrl('OptimizeFlow'));
    setTimeout(() => setOptimizing(false), 1000);
  };

  return (
    <div className="min-h-screen bg-[#f8f9fc]">
      <Sidebar currentPage={currentPageName} collapsed={collapsed} setCollapsed={setCollapsed} />
      <div className={cn("transition-all duration-300", collapsed ? "ml-[68px]" : "ml-[240px]")}>
        <TopBar onOptimize={handleOptimize} optimizing={optimizing} />
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  );
}