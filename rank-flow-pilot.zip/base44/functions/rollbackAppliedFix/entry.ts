import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'rollbackAppliedFix', required_fields: ['fix_id'] });
    }

    const payload = await req.json();
    if (!payload.fix_id) {
      return Response.json({ endpoint: 'rollbackAppliedFix', required_fields: ['fix_id'] });
    }

    const fix = await base44.asServiceRole.entities.AppliedFix.get(payload.fix_id);
    if (!fix) {
      return Response.json({ error: 'Applied fix not found.' }, { status: 404 });
    }

    await base44.asServiceRole.entities.AppliedFix.update(fix.id, { status: 'rolled_back' });
    return Response.json({ success: true, message: 'Fix marked as rolled back.', fix_id: fix.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});