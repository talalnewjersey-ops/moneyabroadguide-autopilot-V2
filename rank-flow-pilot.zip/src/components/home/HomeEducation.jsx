import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { guideCards } from '@/lib/homepageData';
import { ArrowRight, BookOpen } from 'lucide-react';
import SectionReveal from '@/components/home/SectionReveal';
import SectionHeading from '@/components/home/SectionHeading';

export default function HomeEducation() {
  return (
    <section id="guides" className="guides bg-white">
      <SectionReveal className="mx-auto max-w-[920px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
        <SectionHeading
          eyebrow="Learn and save"
          title="Educational content that supports conversion, trust, and repeat visits"
          description="Use helpful guides to educate readers first, then direct them back to the calculator when they are ready to compare providers."
        />
        <div className="grid-3">
          {guideCards.map((guide) => (
            <Card key={guide.title} className="fintech-card fintech-card-hover h-full rounded-[28px] border-0">
              <CardContent className="flex h-full flex-col p-7 text-center">
                <BookOpen className="mx-auto h-8 w-8 text-[#1F8F6A]" />
                <div className="mt-4 flex-1 space-y-3">
                  <h3 className="text-2xl font-bold text-slate-950">{guide.title}</h3>
                  <p className="text-base leading-7 text-slate-500">{guide.description}</p>
                </div>
                <a href={guide.href} className="mt-6 inline-flex w-fit self-center items-center gap-2 rounded-full border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:border-slate-300 hover:bg-slate-50">
                  Read Full Guide <ArrowRight className="h-4 w-4" />
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
      </SectionReveal>
    </section>
  );
}