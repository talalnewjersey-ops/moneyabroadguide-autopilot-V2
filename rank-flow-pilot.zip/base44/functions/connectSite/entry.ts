import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const normalizeUrl = (url = '') => url.toLowerCase().trim().replace(/\/$/, '');
const getWebsiteName = (siteUrl = '', siteName = '') => {
  if (siteName) return siteName;
  const hostname = normalizeUrl(siteUrl).replace(/^https?:\/\//, '').split('/')[0].replace(/^www\./, '');
  const baseName = hostname.split('.')[0] || 'WordPress Site';
  return baseName
    .split(/[-_]/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    if (req.method !== 'POST') {
      return Response.json({
        endpoint: 'connectSite',
        required_fields: ['site_url', 'api_key'],
        optional_fields: ['mode', 'plugin_version', 'rest_url', 'site_name'],
      });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.site_url || !payload.api_key) {
      return Response.json({
        endpoint: 'connectSite',
        required_fields: ['site_url', 'api_key'],
        optional_fields: ['mode', 'plugin_version', 'rest_url', 'site_name'],
      });
    }

    const websites = await base44.asServiceRole.entities.Website.list();
    const existingWebsite = websites.find((item) => normalizeUrl(item.url) === normalizeUrl(payload.site_url));

    if (existingWebsite?.wordpress_api_key && existingWebsite.wordpress_api_key !== payload.api_key) {
      return Response.json({ error: 'Invalid API key for this website.' }, { status: 403 });
    }

    let website = existingWebsite;

    if (!website) {
      website = await base44.asServiceRole.entities.Website.create({
        name: getWebsiteName(payload.site_url, payload.site_name),
        url: payload.site_url,
        status: 'connected',
        seo_score: 0,
        total_pages: 0,
        total_issues: 0,
        wordpress_api_key: payload.api_key,
        wordpress_api_url: payload.rest_url || payload.site_url,
      });
    } else {
      await base44.asServiceRole.entities.Website.update(website.id, {
        name: website.name || getWebsiteName(payload.site_url, payload.site_name),
        wordpress_api_key: payload.api_key,
        wordpress_api_url: payload.rest_url || payload.site_url,
        status: 'connected',
      });
    }

    return Response.json({
      success: true,
      website_id: website.id,
      website_name: website.name || getWebsiteName(payload.site_url, payload.site_name),
      site_url: website.url,
      mode: payload.mode || 'assisted',
      created: !existingWebsite,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});