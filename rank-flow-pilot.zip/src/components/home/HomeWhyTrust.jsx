import React from 'react';
import { Banknote, Shield, TrendingUp } from 'lucide-react';
import SectionReveal from '@/components/home/SectionReveal';
import SectionHeading from '@/components/home/SectionHeading';

const benefitCards = [
  {
    title: 'Save more on every transfer',
    description: 'Compare real transfer fees and exchange rate margins in one place and avoid the hidden costs that quietly reduce what your recipient gets.',
    icon: Banknote,
  },
  {
    title: 'Make safer financial decisions',
    description: 'Transparent provider comparisons and clear educational content create trust before users click through to a partner offer.',
    icon: Shield,
  },
  {
    title: 'Convert faster with confidence',
    description: 'A cleaner comparison flow helps users choose the strongest option for their route, amount, and urgency without confusion.',
    icon: TrendingUp,
  },
];

export default function HomeWhyTrust() {
  return (
    <section className="benefits bg-[#F8FAFC]">
      <SectionReveal className="mx-auto max-w-[920px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
        <SectionHeading
          eyebrow="Why users choose MoneyAbroadGuide"
          title="Built to save money, build trust, and drive action"
          description="This experience is designed like a fintech platform, not a generic blog, so readers move faster from research to conversion."
        />

        <div className="grid-3">
          {benefitCards.map((item) => (
            <div key={item.title} className="fintech-card fintech-card-hover p-7 text-center">
              <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#EAF7F1] text-[#1F8F6A]">
                <item.icon className="h-6 w-6" />
              </div>
              <h3 className="text-2xl font-bold text-slate-950">{item.title}</h3>
              <p className="mt-3 text-base leading-7 text-slate-500">{item.description}</p>
            </div>
          ))}
        </div>
      </SectionReveal>
    </section>
  );
}