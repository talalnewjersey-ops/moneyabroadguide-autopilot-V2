import React from 'react';
import HomeHeader from '@/components/home/HomeHeader';
import HomeFooter from '@/components/home/HomeFooter';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-950">
      <HomeHeader />

      <main className="mx-auto max-w-[920px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
        <section className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-10">
          <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#16a34a]">Legal</p>
          <h1 className="mt-3 text-4xl font-extrabold tracking-tight sm:text-5xl">Privacy Policy</h1>
          <p className="mt-5 text-lg leading-8 text-slate-600">Last updated: March 2026</p>
        </section>

        <section className="mt-8 space-y-6 rounded-[28px] border border-slate-200 bg-white p-8 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-10">
          <div>
            <h2 className="text-2xl font-extrabold tracking-tight text-slate-950">Information We Collect</h2>
            <p className="mt-3 text-base leading-8 text-slate-600">
              We may collect personal data such as email address and usage data when you interact with the site.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-extrabold tracking-tight text-slate-950">Cookies</h2>
            <p className="mt-3 text-base leading-8 text-slate-600">
              We use cookies for analytics, site performance, and affiliate tracking.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-extrabold tracking-tight text-slate-950">Affiliate Disclosure</h2>
            <p className="mt-3 text-base leading-8 text-slate-600">
              We may earn commissions through affiliate links at no extra cost to users.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-extrabold tracking-tight text-slate-950">Third Parties</h2>
            <p className="mt-3 text-base leading-8 text-slate-600">
              We may work with third-party tools and affiliate platforms such as Impact.com.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-extrabold tracking-tight text-slate-950">Contact</h2>
            <p className="mt-3 text-base leading-8 text-slate-600">
              For privacy-related questions, email <a href="mailto:contact@moneyabroadguide.com" className="font-semibold text-[#16a34a] hover:underline">contact@moneyabroadguide.com</a>.
            </p>
          </div>
        </section>
      </main>

      <HomeFooter />
    </div>
  );
}