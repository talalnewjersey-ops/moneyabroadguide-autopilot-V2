import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';
import JSZip from 'npm:jszip@3.10.1';

const pluginMainFile = String.raw`<?php
/**
 * Plugin Name: MoneyAbroadGuide Landing Page
 * Description: Installs the MoneyAbroadGuide fintech landing page and sets it as the WordPress homepage.
 * Version: 1.2.0
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) exit;

class MoneyAbroadGuideLandingPage {
    const PAGE_SLUG = 'moneyabroadguide-home';

    public function __construct() {
        add_shortcode('mag_landing_page', [$this, 'render_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_filter('the_content', [$this, 'render_front_page_content'], 1);
        add_action('init', [$this, 'ensure_homepage_exists']);
        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_notices', [$this, 'render_admin_notice']);
    }

    public static function activate() {
        $instance = new self();
        $instance->ensure_homepage_exists();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public function ensure_homepage_exists() {
        $page = get_page_by_path(self::PAGE_SLUG);
        $page_data = [
            'post_title' => 'Home',
            'post_name' => self::PAGE_SLUG,
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_content' => '[mag_landing_page]',
        ];

        if ($page) {
            $page_data['ID'] = $page->ID;
            $page_id = wp_update_post($page_data, true);
        } else {
            $page_id = wp_insert_post($page_data, true);
        }

        if (!is_wp_error($page_id) && $page_id) {
            update_option('show_on_front', 'page');
            update_option('page_on_front', $page_id);
            update_option('page_for_posts', 0);
            update_post_meta($page_id, '_wp_page_template', 'default');
            wp_cache_flush();
        }

        return $page_id;
    }

    public function register_menu() {
        add_menu_page(
            'MoneyAbroadGuide Landing',
            'MAG Landing',
            'manage_options',
            'moneyabroadguide-landing',
            [$this, 'render_admin_page'],
            'dashicons-welcome-widgets-menus',
            30
        );
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) return;

        $message = '';
        if (!empty($_POST['mag_refresh_landing']) && check_admin_referer('mag_refresh_landing_action')) {
            $page_id = $this->ensure_homepage_exists();
            if (!is_wp_error($page_id) && $page_id) {
                $message = 'Landing page reapplied successfully and set as homepage.';
            }
        }

        $front_id = (int) get_option('page_on_front');
        $front_url = $front_id ? get_permalink($front_id) : home_url('/');

        echo '<div class="wrap"><h1>MoneyAbroadGuide Landing</h1>';
        if ($message) {
            echo '<div class="notice notice-success"><p>' . esc_html($message) . '</p></div>';
        }
        echo '<p>This plugin creates the fintech landing page and applies it as the WordPress homepage.</p>';
        echo '<p><strong>Current homepage:</strong> <a href="' . esc_url($front_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html($front_url) . '</a></p>';
        echo '<form method="post">';
        wp_nonce_field('mag_refresh_landing_action');
        echo '<p><button class="button button-primary" name="mag_refresh_landing" value="1">Reapply landing page now</button></p>';
        echo '</form></div>';
    }

    public function render_admin_notice() {
        if (!current_user_can('manage_options')) return;
        $front_id = (int) get_option('page_on_front');
        if (!$front_id) return;
        $front_url = get_permalink($front_id);
        echo '<div class="notice notice-success is-dismissible"><p><strong>MoneyAbroadGuide Landing Page active.</strong> Homepage: <a href="' . esc_url($front_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html($front_url) . '</a> — manage it via <a href="' . esc_url(admin_url('admin.php?page=moneyabroadguide-landing')) . '">MAG Landing</a>.</p></div>';
    }

    public function enqueue_assets() {
        if (!(is_front_page() || is_page(self::PAGE_SLUG))) {
            return;
        }

        wp_enqueue_style('mag-landing-style', plugins_url('assets/mag-landing.css', __FILE__), [], '1.0.0');
        wp_enqueue_script('mag-landing-script', plugins_url('assets/mag-landing.js', __FILE__), [], '1.0.0', true);
        wp_localize_script('mag-landing-script', 'MAGLandingData', [
            'providers' => [
                [
                    'name' => 'Wise',
                    'fees' => 'Low, transparent',
                    'speed' => 'Minutes to 2 days',
                    'exchangeRate' => 'Mid-market rate',
                    'rating' => '4.9/5',
                    'ratingValue' => 4.9,
                    'baseFeePercent' => 0.35,
                    'fixedFee' => 1.25,
                    'rateMarkupPercent' => 0.15,
                    'href' => 'https://wise.com/'
                ],
                [
                    'name' => 'Remitly',
                    'fees' => 'Promo-friendly',
                    'speed' => 'Express available',
                    'exchangeRate' => 'Competitive',
                    'rating' => '4.8/5',
                    'ratingValue' => 4.8,
                    'baseFeePercent' => 0.42,
                    'fixedFee' => 1.95,
                    'rateMarkupPercent' => 0.2,
                    'href' => 'https://www.remitly.com/'
                ],
                [
                    'name' => 'OFX',
                    'fees' => 'No fixed fee',
                    'speed' => '1–3 days',
                    'exchangeRate' => 'Strong on large transfers',
                    'rating' => '4.7/5',
                    'ratingValue' => 4.7,
                    'baseFeePercent' => 0.28,
                    'fixedFee' => 0,
                    'rateMarkupPercent' => 0.18,
                    'href' => 'https://www.ofx.com/'
                ],
                [
                    'name' => 'Xe Money Transfer',
                    'fees' => 'Varies',
                    'speed' => 'Same day to 3 days',
                    'exchangeRate' => 'Live rate tools',
                    'rating' => '4.6/5',
                    'ratingValue' => 4.6,
                    'baseFeePercent' => 0.4,
                    'fixedFee' => 2.5,
                    'rateMarkupPercent' => 0.21,
                    'href' => 'https://www.xe.com/'
                ]
            ]
        ]);
    }

    public function render_front_page_content($content) {
        if (is_admin() || !is_front_page() || !in_the_loop() || !is_main_query()) {
            return $content;
        }

        return do_shortcode('[mag_landing_page]');
    }

    public function render_shortcode() {
        $logo_url = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/04e698527_principale.png';
        $usa_url = home_url('/newcomers-to-the-usa/');
        $canada_url = home_url('/newcomers-to-canada/');
        $start_here_url = home_url('/start-here/');
        $fallback_best_provider = 'OFX';
        $fallback_summary = 'Top-ranked for USA to France on $1,000.00.';
        $fallback_savings = '$4.02';
        $fallback_total_cost = '$4.60';
        $fallback_received = '$995.40';
        $fallback_fee = '$2.80';
        $fallback_speed = '1–3 days';

        ob_start();
        ?>
        <div class="mag-landing-root" id="top">
          <header class="mag-header">
            <div class="mag-shell mag-header-inner">
              <a href="<?php echo esc_url(home_url('/')); ?>" class="mag-logo-wrap">
                <img src="<?php echo esc_url($logo_url); ?>" alt="MoneyAbroadGuide" class="mag-logo" />
              </a>
              <nav class="mag-nav">
                <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                <a href="#articles">Start here</a>
                <a href="<?php echo esc_url($usa_url); ?>">Newcomers to the USA</a>
                <a href="<?php echo esc_url($canada_url); ?>">Newcomers to Canada</a>
              </nav>
              <a href="#calculator" class="mag-btn mag-btn-primary mag-hide-mobile">Compare Fees Now</a>
            </div>
          </header>

          <section class="mag-hero">
            <div class="mag-shell mag-hero-grid">
              <div class="mag-hero-copy">
                <div class="mag-eyebrow">Trusted money transfer comparison for immigrants, expats, and global families</div>
                <h1>Stop Losing Hundreds on Every International Transfer</h1>
                <p class="mag-subheadline">Compare transfer services, find the cheapest option, and save money instantly with better fees, stronger exchange rates, and smarter provider choices.</p>
                <div class="mag-hero-actions">
                  <a href="#calculator" class="mag-btn mag-btn-primary">Compare Fees Now</a>
                  <a href="#articles" class="mag-btn mag-btn-secondary">Start Free</a>
                </div>
                <div class="mag-pill-row">
                  <span class="mag-pill">Used by expats in USA &amp; Canada</span>
                  <span class="mag-pill">80+ providers analyzed</span>
                  <span class="mag-pill">Updated weekly</span>
                </div>

                <div class="mag-summary-card">
                  <h2>Compare top money transfer services at a glance</h2>
                  <p>See which providers help you save more, move faster, and get stronger exchange value before you click out.</p>
                  <div class="mag-table-wrap">
                    <table class="mag-table">
                      <thead>
                        <tr>
                          <th>Service</th>
                          <th>Fees</th>
                          <th>Speed</th>
                          <th>Exchange Rate</th>
                          <th>Rating</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr><td>Wise</td><td>Low, transparent</td><td>Minutes to 2 days</td><td>Mid-market rate</td><td>4.9/5</td><td><a href="https://wise.com/" target="_blank" rel="noreferrer">View deal</a></td></tr>
                        <tr><td>Remitly</td><td>Promo-friendly</td><td>Express available</td><td>Competitive</td><td>4.8/5</td><td><a href="https://www.remitly.com/" target="_blank" rel="noreferrer">View deal</a></td></tr>
                        <tr><td>OFX</td><td>No fixed fee</td><td>1–3 days</td><td>Strong on large transfers</td><td>4.7/5</td><td><a href="https://www.ofx.com/" target="_blank" rel="noreferrer">View deal</a></td></tr>
                        <tr><td>Xe Money Transfer</td><td>Varies</td><td>Same day to 3 days</td><td>Live rate tools</td><td>4.6/5</td><td><a href="https://www.xe.com/" target="_blank" rel="noreferrer">View deal</a></td></tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="mag-highlight-grid">
                    <div class="mag-highlight"><span>Lowest cost</span><strong>Wise</strong></div>
                    <div class="mag-highlight"><span>Fast transfers</span><strong>Remitly</strong></div>
                    <div class="mag-highlight"><span>Large amounts</span><strong>OFX</strong></div>
                    <div class="mag-highlight"><span>Rate tools</span><strong>Xe</strong></div>
                  </div>
                </div>
              </div>

              <div class="mag-calculator-card" id="calculator">
                <div class="mag-calculator-heading">
                  <p class="mag-calculator-label">Transfer calculator</p>
                  <h2>Find the best provider for your transfer</h2>
                  <p>Enter an amount, choose your route, and instantly see the best provider ranked by total cost, speed, and trust.</p>
                </div>

                <div class="mag-form-grid">
                  <div>
                    <label>Amount</label>
                    <input id="mag-amount" type="number" min="100" value="1000" />
                  </div>
                  <div>
                    <label>From country</label>
                    <select id="mag-from-country">
                      <option>USA</option>
                      <option>Canada</option>
                    </select>
                  </div>
                  <div>
                    <label>To country</label>
                    <select id="mag-to-country">
                      <option>France</option>
                      <option>India</option>
                      <option>Philippines</option>
                      <option>UK</option>
                    </select>
                  </div>
                </div>

                <div class="mag-best-provider">
                  <div>
                    <p class="mag-micro-label">Best provider right now</p>
                    <h3 id="mag-best-name"><?php echo esc_html($fallback_best_provider); ?></h3>
                    <p id="mag-best-summary"><?php echo esc_html($fallback_summary); ?></p>
                  </div>
                  <div class="mag-savings-box">
                    <p>Estimated savings</p>
                    <strong id="mag-savings"><?php echo esc_html($fallback_savings); ?></strong>
                  </div>
                </div>

                <div class="mag-metric-grid">
                  <div class="mag-metric-card"><span>Total cost</span><strong id="mag-total-cost"><?php echo esc_html($fallback_total_cost); ?></strong></div>
                  <div class="mag-metric-card"><span>Received amount</span><strong id="mag-received"><?php echo esc_html($fallback_received); ?></strong></div>
                  <div class="mag-metric-card"><span>Fee</span><strong id="mag-fee"><?php echo esc_html($fallback_fee); ?></strong></div>
                  <div class="mag-metric-card"><span>Speed</span><strong id="mag-speed"><?php echo esc_html($fallback_speed); ?></strong></div>
                </div>

                <div id="mag-ranking-list" class="mag-ranking-list">
                  <div class="mag-rank-item"><div class="mag-rank-left"><div class="mag-rank-badge">#1</div><div><strong>OFX</strong><p>1–3 days • 4.7/5</p></div></div><div><strong>$4.60</strong><span>Receives $995.40</span></div></div>
                  <div class="mag-rank-item"><div class="mag-rank-left"><div class="mag-rank-badge">#2</div><div><strong>Wise</strong><p>Minutes to 2 days • 4.9/5</p></div></div><div><strong>$6.23</strong><span>Receives $993.76</span></div></div>
                  <div class="mag-rank-item"><div class="mag-rank-left"><div class="mag-rank-badge">#3</div><div><strong>Remitly</strong><p>Express available • 4.8/5</p></div></div><div><strong>$8.19</strong><span>Receives $991.81</span></div></div>
                  <div class="mag-rank-item"><div class="mag-rank-left"><div class="mag-rank-badge">#4</div><div><strong>Xe Money Transfer</strong><p>Same day to 3 days • 4.6/5</p></div></div><div><strong>$8.62</strong><span>Receives $991.38</span></div></div>
                </div>

                <div class="mag-calculator-actions">
                  <a id="mag-primary-link" href="https://wise.com/" target="_blank" rel="noreferrer" class="mag-btn mag-btn-primary">Compare Fees Now</a>
                  <a href="#compare" class="mag-inline-link">See full comparison below</a>
                </div>
              </div>
            </div>
          </section>

          <section class="mag-section mag-light">
            <div class="mag-shell">
              <div class="mag-section-heading">
                <p class="mag-kicker">Why users choose MoneyAbroadGuide</p>
                <h2>Built to save money, build trust, and drive action</h2>
                <p>This experience is designed like a fintech platform, not a generic blog, so readers move faster from research to conversion.</p>
              </div>
              <div class="mag-card-grid mag-three-col">
                <article class="mag-card"><h3>Save more on every transfer</h3><p>Compare real transfer fees and exchange rate margins in one place and avoid hidden costs that reduce what your recipient gets.</p></article>
                <article class="mag-card"><h3>Make safer financial decisions</h3><p>Transparent provider comparisons and educational content create trust before users click through to a partner offer.</p></article>
                <article class="mag-card"><h3>Convert faster with confidence</h3><p>A cleaner comparison flow helps users choose the strongest option for their route, amount, and urgency without confusion.</p></article>
              </div>
            </div>
          </section>

          <section class="mag-section">
            <div class="mag-shell">
              <div class="mag-story-card">
                <div>
                  <p class="mag-kicker mag-kicker-light">Real savings story</p>
                  <h2>Ahmed saved $420 a year by switching transfer provider</h2>
                  <p>Ahmed was sending money home every month from the USA and assumed his usual provider was already competitive. After comparing fees, FX margins, and delivery times, he switched to a lower-cost option and kept hundreds of dollars each year.</p>
                  <div class="mag-story-actions">
                    <a href="#calculator" class="mag-btn mag-btn-light">Compare Fees Now</a>
                    <a href="#trust" class="mag-btn mag-btn-ghost">See why users trust us</a>
                  </div>
                </div>
                <div class="mag-story-side">
                  <div class="mag-story-mini"><span>Before switching</span><strong>Higher fees + weak FX</strong><p>Monthly transfers looked fine on the surface, but hidden spread costs kept reducing the received amount.</p></div>
                  <div class="mag-story-mini"><span>After comparing</span><strong>$420/year saved</strong><p>A better provider meant stronger rates, lower total cost, and more money delivered every month.</p></div>
                </div>
              </div>
            </div>
          </section>

          <section class="mag-section mag-light" id="articles">
            <div class="mag-shell">
              <div class="mag-section-heading">
                <p class="mag-kicker">Authority content</p>
                <h2>Guides designed to build trust before users compare fees</h2>
                <p>Educational content for newcomers helps establish authority, improve conversion quality, and move visitors naturally toward the calculator.</p>
              </div>
              <div class="mag-card-grid mag-three-col">
                <article class="mag-card mag-article-card"><div class="mag-tag">USA</div><h3>Newcomers to the USA</h3><p>Educational explanations of U.S. financial concepts, including banking basics, saving, and everyday money terminology.</p><a href="<?php echo esc_url($usa_url); ?>">Read Full Guide</a></article>
                <article class="mag-card mag-article-card"><div class="mag-tag">Canada</div><h3>Newcomers to Canada</h3><p>Educational information to help readers understand Canadian banking systems, savings basics, and financial fundamentals.</p><a href="<?php echo esc_url($canada_url); ?>">Read Full Guide</a></article>
                <article class="mag-card mag-article-card"><div class="mag-tag">Start here</div><h3>Start Here for Newcomers</h3><p>A simple starting point for immigrants learning how financial systems work in the USA and Canada.</p><a href="<?php echo esc_url($start_here_url); ?>">Read Full Guide</a></article>
              </div>
            </div>
          </section>

          <section class="mag-section" id="compare">
            <div class="mag-shell">
              <div class="mag-section-heading">
                <p class="mag-kicker">Compare and convert</p>
                <h2>Compare providers, reduce fees, and move money with more confidence</h2>
                <p>This table is built to help users compare total value fast and click through only when the offer matches their route, urgency, and amount.</p>
              </div>
              <div class="mag-summary-card">
                <div class="mag-table-wrap">
                  <table class="mag-table mag-table-large">
                    <thead>
                      <tr><th>Service</th><th>Fees</th><th>Speed</th><th>Exchange Rate</th><th>Rating</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                      <tr><td>Wise</td><td>Low, transparent</td><td>Minutes to 2 days</td><td>Mid-market rate</td><td>4.9/5</td><td><a href="https://wise.com/" target="_blank" rel="noreferrer">Compare Fees Now</a></td></tr>
                      <tr><td>Remitly</td><td>Promo-friendly</td><td>Express available</td><td>Competitive</td><td>4.8/5</td><td><a href="https://www.remitly.com/" target="_blank" rel="noreferrer">Compare Fees Now</a></td></tr>
                      <tr><td>OFX</td><td>No fixed fee</td><td>1–3 days</td><td>Strong on large transfers</td><td>4.7/5</td><td><a href="https://www.ofx.com/" target="_blank" rel="noreferrer">Compare Fees Now</a></td></tr>
                      <tr><td>Xe Money Transfer</td><td>Varies</td><td>Same day to 3 days</td><td>Live rate tools</td><td>4.6/5</td><td><a href="https://www.xe.com/" target="_blank" rel="noreferrer">Compare Fees Now</a></td></tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="mag-center-cta"><a href="#calculator" class="mag-btn mag-btn-primary">Compare Fees Now</a></div>
            </div>
          </section>

          <section class="mag-section mag-light" id="trust">
            <div class="mag-shell">
              <div class="mag-section-heading">
                <p class="mag-kicker">Built on transparency</p>
                <h2>Financial authority that helps users trust the comparison</h2>
                <p>We focus on real pricing, better clarity, and a more trustworthy user experience so people feel safe making money decisions here.</p>
              </div>
              <div class="mag-card-grid mag-four-col">
                <article class="mag-card mag-metric"><strong>12,000+</strong><span>Expats helped</span></article>
                <article class="mag-card mag-metric"><strong>$1.8M+</strong><span>Potential savings</span></article>
                <article class="mag-card mag-metric"><strong>80+</strong><span>Providers reviewed</span></article>
                <article class="mag-card mag-metric"><strong>Weekly</strong><span>Updated data</span></article>
              </div>
              <div class="mag-center-cta"><a href="#calculator" class="mag-btn mag-btn-primary">Compare Fees Now</a></div>
            </div>
          </section>

          <section class="mag-section">
            <div class="mag-shell">
              <div class="mag-final-cta">
                <p class="mag-kicker mag-kicker-light">Ready to save more?</p>
                <h2>Compare fees, protect your money, and choose a better transfer today</h2>
                <p>MoneyAbroadGuide helps users avoid hidden markups, compare transfer rates faster, and move money with more confidence.</p>
                <div class="mag-story-actions">
                  <a href="#calculator" class="mag-btn mag-btn-light">Compare Fees Now</a>
                  <a href="#articles" class="mag-btn mag-btn-ghost">Start Free</a>
                </div>
              </div>
            </div>
          </section>
        </div>
        <?php
        return ob_get_clean();
    }
}

register_activation_hook(__FILE__, ['MoneyAbroadGuideLandingPage', 'activate']);
register_deactivation_hook(__FILE__, ['MoneyAbroadGuideLandingPage', 'deactivate']);
new MoneyAbroadGuideLandingPage();`;

const pluginCssFile = String.raw`body.home .entry-title,
body.home .ast-article-single .entry-header,
body.home .entry-header {
  display: none !important;
}

body.home .site-content,
body.home .ast-container,
body.home #primary,
body.home .content-area,
body.home .entry-content {
  width: 100% !important;
  max-width: 100% !important;
  margin: 0 !important;
  padding: 0 !important;
}

.mag-landing-root {
  background: #f8fafc;
  color: #0f172a;
  font-family: Inter, Arial, sans-serif;
}

.mag-shell {
  width: min(100%, 980px);
  margin: 0 auto;
  padding: 0 16px;
}

.mag-header {
  position: sticky;
  top: 0;
  z-index: 40;
  border-bottom: 1px solid rgba(226,232,240,.9);
  background: rgba(255,255,255,.92);
  backdrop-filter: blur(16px);
}

.mag-header-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  padding-top: 10px;
  padding-bottom: 10px;
}

.mag-logo-wrap {
  display: inline-flex;
  align-items: center;
  padding: 12px;
  border-radius: 18px;
  background: rgba(255,255,255,.92);
  box-shadow: 0 12px 30px rgba(15,23,42,.06);
}

.mag-logo {
  width: 420px;
  max-width: 100%;
  height: auto;
  display: block;
  object-fit: contain;
}

.mag-nav {
  display: none;
  align-items: center;
  gap: 32px;
}

.mag-nav a {
  position: relative;
  color: #475569;
  text-decoration: none;
  font-size: 15px;
  font-weight: 600;
  transition: color .25s ease;
}

.mag-nav a:hover {
  color: #0f172a;
}

.mag-nav a::after {
  content: '';
  position: absolute;
  left: 0;
  bottom: -6px;
  width: 100%;
  height: 2px;
  background: #1F8F6A;
  transform: scaleX(0);
  transform-origin: left;
  transition: transform .25s ease;
}

.mag-nav a:hover::after {
  transform: scaleX(1);
}

.mag-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 52px;
  padding: 0 28px;
  border-radius: 999px;
  font-size: 15px;
  font-weight: 700;
  text-decoration: none;
  transition: all .25s ease;
}

.mag-btn-primary {
  color: #fff;
  background: linear-gradient(135deg, #1f8f6a, #187255);
  box-shadow: 0 18px 40px rgba(31,143,106,.22);
}

.mag-btn-primary:hover {
  transform: translateY(-1px) scale(1.01);
  box-shadow: 0 24px 48px rgba(31,143,106,.28);
}

.mag-btn-secondary,
.mag-btn-light {
  color: #0f172a;
  background: #fff;
  border: 1px solid #e2e8f0;
  box-shadow: 0 10px 24px rgba(15,23,42,.05);
}

.mag-btn-secondary:hover,
.mag-btn-light:hover {
  background: #f8fafc;
}

.mag-btn-ghost {
  color: #fff;
  background: rgba(255,255,255,.1);
  border: 1px solid rgba(255,255,255,.15);
}

.mag-btn-ghost:hover {
  background: rgba(255,255,255,.16);
}

.mag-hide-mobile {
  display: none;
}

.mag-hero {
  background:
    radial-gradient(circle at top center, rgba(31, 143, 106, 0.12), transparent 32%),
    linear-gradient(180deg, #f8fafc 0%, #ffffff 72%);
  border-bottom: 1px solid rgba(226,232,240,.8);
}

.mag-hero-grid {
  display: grid;
  gap: 32px;
  padding-top: 8px;
  padding-bottom: 56px;
}

.mag-hero-copy {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 28px;
}

.mag-eyebrow,
.mag-kicker {
  display: inline-flex;
  align-items: center;
  border-radius: 999px;
  border: 1px solid #e2e8f0;
  background: rgba(255,255,255,.95);
  padding: 10px 16px;
  font-size: 14px;
  font-weight: 600;
  color: #475569;
  box-shadow: 0 12px 28px rgba(15,23,42,.06);
}

.mag-kicker {
  border: none;
  background: transparent;
  box-shadow: none;
  padding: 0;
  text-transform: uppercase;
  letter-spacing: .22em;
  font-size: 12px;
  color: #1F8F6A;
}

.mag-kicker-light {
  color: rgba(255,255,255,.75);
}

.mag-hero h1,
.mag-section-heading h2,
.mag-summary-card h2,
.mag-final-cta h2,
.mag-story-card h2,
.mag-calculator-heading h2 {
  margin: 0;
  font-weight: 800;
  line-height: 1.04;
  letter-spacing: -.03em;
  color: #0f172a;
}

.mag-hero h1 {
  max-width: 850px;
  font-size: clamp(2.6rem, 5vw, 4.1rem);
}

.mag-subheadline,
.mag-section-heading p,
.mag-summary-card p,
.mag-calculator-heading p,
.mag-story-card p,
.mag-final-cta p,
.mag-card p {
  margin: 0;
  color: #64748b;
  line-height: 1.8;
}

.mag-hero-actions,
.mag-story-actions {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.mag-pill-row {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 12px;
}

.mag-pill {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 8px 14px;
  border-radius: 999px;
  border: 1px solid #e2e8f0;
  background: #fff;
  color: #334155;
  font-size: 14px;
  font-weight: 600;
  box-shadow: 0 8px 20px rgba(15,23,42,.05);
}

.mag-summary-card,
.mag-calculator-card,
.mag-card {
  border-radius: 28px;
  border: 1px solid rgba(226,232,240,.8);
  background: rgba(255,255,255,.97);
  box-shadow: 0 20px 50px rgba(15,23,42,.08);
}

.mag-summary-card {
  width: 100%;
  padding: 20px;
  text-align: left;
}

.mag-table-wrap {
  overflow-x: auto;
}

.mag-table {
  width: 100%;
  min-width: 760px;
  border-collapse: collapse;
}

.mag-table th,
.mag-table td {
  padding: 14px 12px;
  border-bottom: 1px solid #e2e8f0;
  text-align: left;
}

.mag-table th {
  color: #64748b;
  font-size: 13px;
}

.mag-table td {
  color: #334155;
}

.mag-table td:first-child {
  color: #0f172a;
  font-weight: 700;
}

.mag-table a {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 10px 14px;
  border-radius: 999px;
  text-decoration: none;
  color: #fff;
  background: #0f172a;
  font-weight: 700;
  font-size: 12px;
}

.mag-highlight-grid,
.mag-card-grid,
.mag-metric-grid {
  display: grid;
  gap: 16px;
}

.mag-highlight-grid {
  margin-top: 16px;
}

.mag-highlight {
  border-radius: 18px;
  border: 1px solid #e2e8f0;
  background: #f8fafc;
  padding: 16px;
  text-align: center;
}

.mag-highlight span,
.mag-metric-card span,
.mag-metric span {
  display: block;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: .14em;
  color: #64748b;
}

.mag-highlight strong,
.mag-metric-card strong,
.mag-metric strong {
  display: block;
  margin-top: 8px;
  font-size: 20px;
  font-weight: 800;
  color: #0f172a;
}

.mag-calculator-card {
  padding: 24px;
  align-self: start;
}

.mag-calculator-heading {
  text-align: center;
}

.mag-calculator-label {
  margin: 0 0 8px;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: .22em;
  color: #1F8F6A;
  font-weight: 700;
}

.mag-form-grid {
  display: grid;
  gap: 16px;
  margin-top: 24px;
}

.mag-form-grid label {
  display: block;
  margin-bottom: 8px;
  color: #334155;
  font-size: 14px;
  font-weight: 600;
}

.mag-form-grid input,
.mag-form-grid select {
  width: 100%;
  min-height: 48px;
  border-radius: 18px;
  border: 1px solid #e2e8f0;
  padding: 0 16px;
  background: #fff;
}

.mag-best-provider {
  margin-top: 24px;
  border-radius: 24px;
  background: #0B1F3A;
  padding: 22px;
  color: #fff;
  box-shadow: 0 25px 60px rgba(11,31,58,.24);
  display: grid;
  gap: 16px;
}

.mag-micro-label {
  margin: 0;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: .2em;
  color: rgba(255,255,255,.72);
}

.mag-best-provider h3 {
  margin: 8px 0 0;
  font-size: 32px;
  line-height: 1.1;
}

.mag-best-provider p,
.mag-savings-box p {
  color: rgba(255,255,255,.78);
}

.mag-savings-box {
  border-radius: 18px;
  border: 1px solid rgba(255,255,255,.1);
  background: rgba(255,255,255,.08);
  padding: 14px 16px;
}

.mag-savings-box strong {
  display: block;
  margin-top: 6px;
  font-size: 28px;
  color: #fff;
}

.mag-metric-grid {
  margin-top: 16px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.mag-metric-card {
  min-height: 110px;
  border-radius: 18px;
  border: 1px solid rgba(255,255,255,.1);
  background: rgba(255,255,255,.08);
  padding: 16px;
}

.mag-metric-card strong {
  color: #fff;
  font-size: 22px;
}

.mag-ranking-list {
  display: grid;
  gap: 12px;
  margin-top: 20px;
}

.mag-rank-item {
  display: flex;
  justify-content: space-between;
  gap: 14px;
  padding: 16px;
  border-radius: 20px;
  border: 1px solid #e2e8f0;
  background: rgba(248,250,252,.88);
}

.mag-rank-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.mag-rank-badge {
  width: 40px;
  height: 40px;
  border-radius: 999px;
  background: #fff;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  color: #0f172a;
  box-shadow: 0 4px 12px rgba(15,23,42,.08);
}

.mag-rank-item strong {
  display: block;
  color: #0f172a;
}

.mag-rank-item span,
.mag-rank-item p {
  color: #64748b;
  margin: 0;
}

.mag-calculator-actions {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-top: 20px;
}

.mag-inline-link {
  align-self: center;
  color: #0f172a;
  text-decoration: none;
  font-weight: 700;
}

.mag-section {
  padding: 56px 0;
}

.mag-light {
  background: #fff;
}

.mag-section-heading {
  max-width: 780px;
  margin: 0 auto 32px;
  text-align: center;
}

.mag-section-heading h2 {
  font-size: clamp(2rem, 4vw, 3rem);
}

.mag-three-col,
.mag-four-col {
  grid-template-columns: 1fr;
}

.mag-card {
  padding: 28px;
  transition: transform .25s ease, box-shadow .25s ease, border-color .25s ease;
}

.mag-card:hover {
  transform: translateY(-4px) scale(1.01);
  border-color: rgba(148,163,184,.35);
  box-shadow: 0 24px 55px rgba(15,23,42,.1);
}

.mag-card h3 {
  margin: 0;
  font-size: 24px;
  color: #0f172a;
}

.mag-article-card a {
  margin-top: 24px;
  display: inline-flex;
  width: fit-content;
  align-items: center;
  padding: 12px 20px;
  border-radius: 999px;
  border: 1px solid #e2e8f0;
  color: #0f172a;
  text-decoration: none;
  font-weight: 700;
}

.mag-tag {
  display: inline-flex;
  width: fit-content;
  border-radius: 999px;
  background: #EAF7F1;
  color: #1F8F6A;
  padding: 6px 12px;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .14em;
  margin-bottom: 18px;
}

.mag-story-card,
.mag-final-cta {
  border-radius: 32px;
  padding: 32px;
  color: #fff;
  background: linear-gradient(135deg, #0B1F3A 0%, #15304f 52%, #1F8F6A 100%);
  box-shadow: 0 28px 70px rgba(15,23,42,.18);
}

.mag-story-card {
  display: grid;
  gap: 24px;
}

.mag-story-card h2,
.mag-final-cta h2,
.mag-story-card p,
.mag-final-cta p {
  color: #fff;
}

.mag-story-side {
  display: grid;
  gap: 16px;
}

.mag-story-mini {
  border-radius: 24px;
  border: 1px solid rgba(255,255,255,.1);
  background: rgba(255,255,255,.08);
  padding: 20px;
}

.mag-story-mini span {
  display: block;
  color: rgba(255,255,255,.72);
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .16em;
}

.mag-story-mini strong {
  display: block;
  margin-top: 12px;
  font-size: 28px;
}

.mag-center-cta {
  margin-top: 24px;
  display: flex;
  justify-content: center;
}

@media (min-width: 900px) {
  .mag-nav,
  .mag-hide-mobile {
    display: inline-flex;
  }

  .mag-hero-grid {
    grid-template-columns: 1.02fr 0.98fr;
  }

  .mag-highlight-grid,
  .mag-four-col {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }

  .mag-three-col {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  .mag-story-card {
    grid-template-columns: 1.15fr 0.85fr;
    align-items: center;
  }

  .mag-form-grid {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  .mag-metric-grid {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }

  .mag-best-provider {
    grid-template-columns: 1.2fr 0.8fr;
    align-items: end;
  }

  .mag-hero-actions,
  .mag-story-actions,
  .mag-calculator-actions {
    flex-direction: row;
    align-items: center;
  }
}
`;

const pluginJsFile = String.raw`document.addEventListener('DOMContentLoaded', function () {
  const data = window.MAGLandingData;
  if (!data || !Array.isArray(data.providers)) return;

  const amountInput = document.getElementById('mag-amount');
  const fromSelect = document.getElementById('mag-from-country');
  const toSelect = document.getElementById('mag-to-country');
  const bestName = document.getElementById('mag-best-name');
  const bestSummary = document.getElementById('mag-best-summary');
  const savings = document.getElementById('mag-savings');
  const totalCost = document.getElementById('mag-total-cost');
  const received = document.getElementById('mag-received');
  const fee = document.getElementById('mag-fee');
  const speed = document.getElementById('mag-speed');
  const rankingList = document.getElementById('mag-ranking-list');
  const primaryLink = document.getElementById('mag-primary-link');

  if (!amountInput || !fromSelect || !toSelect || !bestName || !bestSummary || !savings || !totalCost || !received || !fee || !speed || !rankingList || !primaryLink) {
    return;
  }

  const routeBias = {
    'USA-Morocco': { Wise: 1.01, Remitly: 1.02, OFX: 1.03, 'Xe Money Transfer': 1.04 },
    'USA-India': { Wise: 0.99, Remitly: 1.0, OFX: 1.03, 'Xe Money Transfer': 1.02 },
    'USA-Philippines': { Wise: 1.02, Remitly: 0.98, OFX: 1.04, 'Xe Money Transfer': 1.03 },
    'USA-Mexico': { Wise: 1.0, Remitly: 0.99, OFX: 1.04, 'Xe Money Transfer': 1.02 },
    'USA-UK': { Wise: 0.98, Remitly: 1.02, OFX: 0.99, 'Xe Money Transfer': 1.01 },
    'USA-France': { Wise: 0.99, Remitly: 1.02, OFX: 1.0, 'Xe Money Transfer': 1.01 },
    'Canada-Morocco': { Wise: 1.01, Remitly: 1.0, OFX: 1.02, 'Xe Money Transfer': 1.03 },
    'Canada-France': { Wise: 0.99, Remitly: 1.03, OFX: 0.98, 'Xe Money Transfer': 1.01 },
    'Canada-India': { Wise: 1.0, Remitly: 0.99, OFX: 1.03, 'Xe Money Transfer': 1.02 },
    'Canada-Philippines': { Wise: 1.01, Remitly: 0.98, OFX: 1.04, 'Xe Money Transfer': 1.03 },
  };

  function formatCurrency(value) {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value || 0);
  }

  function rankProviders(amount, fromCountry, toCountry) {
    const routeKey = fromCountry + '-' + toCountry;

    return data.providers
      .map(function (provider) {
        const routeFactor = routeBias[routeKey] && routeBias[routeKey][provider.name] ? routeBias[routeKey][provider.name] : 1;
        const feeValue = amount * (provider.baseFeePercent / 100) + provider.fixedFee;
        const exchangeLoss = amount * (provider.rateMarkupPercent / 100) * routeFactor;
        const totalCostValue = feeValue + exchangeLoss;
        return Object.assign({}, provider, {
          feeValue: feeValue,
          totalCostValue: totalCostValue,
          receivedAmount: amount - totalCostValue,
        });
      })
      .sort(function (a, b) { return a.totalCostValue - b.totalCostValue || b.ratingValue - a.ratingValue; })
      .map(function (provider, index) {
        return Object.assign({}, provider, { rank: index + 1 });
      });
  }

  function renderRankings(rankings) {
    rankingList.innerHTML = rankings.map(function (item) {
      return '<div class="mag-rank-item">'
        + '<div class="mag-rank-left">'
        + '<div class="mag-rank-badge">#' + item.rank + '</div>'
        + '<div>'
        + '<strong>' + item.name + '</strong>'
        + '<p>' + item.speed + ' • ' + item.rating + '</p>'
        + '</div>'
        + '</div>'
        + '<div>'
        + '<strong>' + formatCurrency(item.totalCostValue) + '</strong>'
        + '<span>Receives ' + formatCurrency(item.receivedAmount) + '</span>'
        + '</div>'
        + '</div>';
    }).join('');
  }

  function updateCalculator() {
    const amount = Math.max(100, Number(amountInput.value) || 1000);
    const fromCountry = fromSelect.value;
    const toCountry = toSelect.value;
    const rankings = rankProviders(amount, fromCountry, toCountry);
    const best = rankings[0];
    const highest = rankings[rankings.length - 1];

    bestName.textContent = best.name;
    bestSummary.textContent = 'Top-ranked for ' + fromCountry + ' to ' + toCountry + ' on ' + formatCurrency(amount) + '.';
    savings.textContent = formatCurrency(Math.max(0, highest.totalCostValue - best.totalCostValue));
    totalCost.textContent = formatCurrency(best.totalCostValue);
    received.textContent = formatCurrency(best.receivedAmount);
    fee.textContent = formatCurrency(best.feeValue);
    speed.textContent = best.speed;
    primaryLink.href = best.href;
    renderRankings(rankings);
  }

  [amountInput, fromSelect, toSelect].forEach(function (el) {
    if (el) el.addEventListener('input', updateCalculator);
  });
  [fromSelect, toSelect].forEach(function (el) {
    if (el) el.addEventListener('change', updateCalculator);
  });
  updateCalculator();
});`;

async function buildZip() {
  const zip = new JSZip();
  const folder = zip.folder('moneyabroadguide-landing-page-v2');
  const assets = folder.folder('assets');
  folder.file('moneyabroadguide-landing-page.php', pluginMainFile);
  assets.file('mag-landing.css', pluginCssFile);
  assets.file('mag-landing.js', pluginJsFile);
  return await zip.generateAsync({ type: 'uint8array' });
}

Deno.serve(async (req) => {
  try {
    const zipContent = await buildZip();

    if (req.method === 'GET') {
      return new Response(zipContent, {
        status: 200,
        headers: {
          'Content-Type': 'application/zip',
          'Content-Disposition': 'attachment; filename="moneyabroadguide-landing-page-v2.zip"',
          'Cache-Control': 'no-store',
        },
      });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    return Response.json({
      success: true,
      file_name: 'moneyabroadguide-landing-page-v2.zip',
      folder_name: 'moneyabroadguide-landing-page-v2',
      files: ['moneyabroadguide-landing-page.php', 'assets/mag-landing.css', 'assets/mag-landing.js'],
      download_url: req.url,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});