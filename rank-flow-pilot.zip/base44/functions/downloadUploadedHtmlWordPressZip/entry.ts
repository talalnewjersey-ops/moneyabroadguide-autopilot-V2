import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';
import JSZip from 'npm:jszip@3.10.1';

const sourceHtmlUrl = 'https://media.base44.com/files/public/69b0e5e335d4b05b71b39d24/9c61c6fa2_moneyabroadguide_fusion_v51.html';

function escapePhpSingleQuotedString(value) {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'");
}

async function buildPluginPhp() {
  const response = await fetch(sourceHtmlUrl);
  if (!response.ok) {
    throw new Error('Impossible de charger le fichier HTML source');
  }

  const html = await response.text();
  const escapedHtml = escapePhpSingleQuotedString(html);

  return `<?php
/**
 * Plugin Name: MoneyAbroadGuide Fusion Uploaded HTML
 * Description: Installe la landing page complète depuis le fichier HTML fourni et la définit comme page d'accueil.
 * Version: 5.1.0
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */
if (!defined('ABSPATH')) exit;
class MoneyAbroadGuideFusionUploadedHtml {
    const PAGE_SLUG = 'moneyabroadguide-fusion-home';
    public function __construct() {
        add_action('init', [$this, 'ensure_homepage_exists']);
        add_filter('template_include', [$this, 'use_blank_template'], 999);
    }
    public static function activate() {
        $instance = new self();
        $instance->ensure_homepage_exists();
        flush_rewrite_rules();
    }
    public static function deactivate() {
        flush_rewrite_rules();
    }
    public function ensure_homepage_exists() {
        $page = get_page_by_path(self::PAGE_SLUG);
        $page_data = [
            'post_title' => 'Home',
            'post_name' => self::PAGE_SLUG,
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_content' => 'MoneyAbroadGuide landing page',
        ];
        if ($page) {
            $page_data['ID'] = $page->ID;
            $page_id = wp_update_post($page_data, true);
        } else {
            $page_id = wp_insert_post($page_data, true);
        }
        if (!is_wp_error($page_id) && $page_id) {
            update_option('show_on_front', 'page');
            update_option('page_on_front', $page_id);
            update_option('page_for_posts', 0);
            wp_cache_flush();
        }
        return $page_id;
    }
    public function use_blank_template($template) {
        if (is_admin() || !(is_front_page() || is_page(self::PAGE_SLUG))) return $template;
        status_header(200);
        nocache_headers();
        echo '${escapedHtml}';
        exit;
    }
}
register_activation_hook(__FILE__, ['MoneyAbroadGuideFusionUploadedHtml', 'activate']);
register_deactivation_hook(__FILE__, ['MoneyAbroadGuideFusionUploadedHtml', 'deactivate']);
new MoneyAbroadGuideFusionUploadedHtml();`;
}

async function buildZip() {
  const pluginPhp = await buildPluginPhp();
  const zip = new JSZip();
  const folder = zip.folder('moneyabroadguide-fusion-v51-wordpress');
  folder.file('moneyabroadguide-fusion-v51-wordpress.php', pluginPhp);
  return await zip.generateAsync({ type: 'uint8array' });
}

Deno.serve(async (req) => {
  try {
    const zipContent = await buildZip();

    if (req.method === 'GET') {
      return new Response(zipContent, {
        status: 200,
        headers: {
          'Content-Type': 'application/zip',
          'Content-Disposition': 'attachment; filename="moneyabroadguide-fusion-v51-wordpress.zip"',
          'Cache-Control': 'no-store',
        },
      });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const zipFile = new File([zipContent], 'moneyabroadguide-fusion-v51-wordpress.zip', { type: 'application/zip' });
    const upload = await base44.asServiceRole.integrations.Core.UploadFile({ file: zipFile });

    return Response.json({
      success: true,
      file_name: 'moneyabroadguide-fusion-v51-wordpress.zip',
      folder_name: 'moneyabroadguide-fusion-v51-wordpress',
      files: ['moneyabroadguide-fusion-v51-wordpress.php'],
      source_html_url: sourceHtmlUrl,
      file_url: upload.file_url,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});