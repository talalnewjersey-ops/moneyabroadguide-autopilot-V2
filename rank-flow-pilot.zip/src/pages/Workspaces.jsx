import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function Workspaces() {
  const [name, setName] = useState('');
  const queryClient = useQueryClient();
  const { data: workspaces = [] } = useQuery({ queryKey: ['workspaces'], queryFn: () => base44.entities.Workspace.list('-created_date', 50) });

  const createWorkspace = async () => {
    if (!name) return;
    await base44.entities.Workspace.create({ name, slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'), plan_status: 'free' });
    setName('');
    queryClient.invalidateQueries({ queryKey: ['workspaces'] });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Workspaces" description="Manage client teams, access, and shared SEO operations." />
      <div className="flex gap-3"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Create a new workspace..." className="rounded-xl" /><Button onClick={createWorkspace} className="rounded-xl bg-blue-600 hover:bg-blue-700">Create Workspace</Button></div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{workspaces.map((workspace) => <Card key={workspace.id}><CardContent className="p-5"><h3 className="font-semibold text-gray-900">{workspace.name}</h3><p className="text-sm text-gray-500 mt-1">Plan: {workspace.plan_status}</p><p className="text-xs text-gray-400 mt-2">Usage tokens: {workspace.usage_tokens || 0}</p></CardContent></Card>)}</div>
    </div>
  );
}