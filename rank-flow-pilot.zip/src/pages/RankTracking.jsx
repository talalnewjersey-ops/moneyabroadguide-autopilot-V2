import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import PageHeader from '../components/common/PageHeader';

export default function RankTracking() {
  const { data: rankings = [] } = useQuery({ queryKey: ['keyword-rankings'], queryFn: () => base44.entities.KeywordRanking.list('-created_date', 100) });
  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Rank Tracking" description="Track keyword winners, losers, and pages that need fresh optimization." />
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="grid grid-cols-12 gap-4 p-4 text-xs font-medium text-gray-500 border-b bg-gray-50/50"><div className="col-span-4">Keyword</div><div className="col-span-3">Target page</div><div className="col-span-2">Position</div><div className="col-span-3">Trend</div></div>
        {rankings.map((item) => <div key={item.id} className="grid grid-cols-12 gap-4 p-4 border-b last:border-0"><div className="col-span-4 text-sm font-medium">{item.keyword}</div><div className="col-span-3 text-sm text-gray-600">{item.target_page}</div><div className="col-span-2 text-sm">{item.current_position ?? '—'}</div><div className="col-span-3 text-sm text-gray-600">{item.trend_status || 'flat'}</div></div>)}
      </div>
    </div>
  );
}