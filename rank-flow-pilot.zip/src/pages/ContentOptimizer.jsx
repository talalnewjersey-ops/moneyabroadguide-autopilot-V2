import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { FileText, Loader2, Sparkles, ArrowRight, CheckCircle2 } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import EmptyState from '../components/common/EmptyState';
import { toast } from 'sonner';

export default function ContentOptimizer() {
  const [analyzing, setAnalyzing] = useState(null);
  const [pageUrl, setPageUrl] = useState('');
  const [addingPage, setAddingPage] = useState(false);
  const queryClient = useQueryClient();

  const { data: websites = [] } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 1),
  });

  const activeWebsite = websites[0];

  const { data: pages = [], isLoading } = useQuery({
    queryKey: ['pages', activeWebsite?.id],
    queryFn: () => base44.entities.Page.filter({ website_id: activeWebsite.id }, '-seo_score'),
    enabled: !!activeWebsite,
  });

  const { data: recommendations = [] } = useQuery({
    queryKey: ['recommendations', activeWebsite?.id],
    queryFn: () => base44.entities.ContentRecommendation.filter({ website_id: activeWebsite.id }),
    enabled: !!activeWebsite,
  });

  const analyzePage = async (page) => {
    setAnalyzing(page.id);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Analyze this webpage for SEO content optimization: ${page.url}
      
      Return detailed SEO analysis including:
      - seo_score (0-100)
      - content_score (0-100)
      - word_count estimate
      - detected keywords (array of strings)
      - has_faq (boolean)
      - internal_links_count estimate
      - issues (array of objects: type, severity, description, recommendation)
      - title suggestion
      - meta_description suggestion
      
      Focus on actionable improvements for ranking better.`,
      response_json_schema: {
        type: "object",
        properties: {
          seo_score: { type: "number" },
          content_score: { type: "number" },
          word_count: { type: "number" },
          keywords: { type: "array", items: { type: "string" } },
          has_faq: { type: "boolean" },
          internal_links_count: { type: "number" },
          issues: {
            type: "array",
            items: {
              type: "object",
              properties: {
                type: { type: "string" },
                severity: { type: "string" },
                description: { type: "string" },
                recommendation: { type: "string" }
              }
            }
          },
          suggested_title: { type: "string" },
          suggested_meta: { type: "string" }
        }
      },
      add_context_from_internet: true,
    });

    await base44.entities.Page.update(page.id, {
      seo_score: result.seo_score,
      content_score: result.content_score,
      word_count: result.word_count,
      keywords: result.keywords,
      has_faq: result.has_faq,
      internal_links_count: result.internal_links_count,
      issues: result.issues,
      status: 'analyzed',
    });

    if (result.suggested_title) {
      await base44.entities.ContentRecommendation.create({
        website_id: activeWebsite.id,
        page_url: page.url,
        type: 'rewrite_title',
        priority: 'high',
        description: 'Improved title tag for better CTR',
        suggested_content: result.suggested_title,
        impact_score: 8,
      });
    }
    if (result.suggested_meta) {
      await base44.entities.ContentRecommendation.create({
        website_id: activeWebsite.id,
        page_url: page.url,
        type: 'rewrite_meta',
        priority: 'high',
        description: 'Optimized meta description',
        suggested_content: result.suggested_meta,
        impact_score: 7,
      });
    }

    queryClient.invalidateQueries({ queryKey: ['pages'] });
    queryClient.invalidateQueries({ queryKey: ['recommendations'] });
    setAnalyzing(null);
    toast.success('Page analysis complete!');
  };

  const addPage = async () => {
    if (!pageUrl || !activeWebsite) return;
    setAddingPage(true);
    let url = pageUrl;
    if (!url.startsWith('http')) url = 'https://' + url;
    await base44.entities.Page.create({ website_id: activeWebsite.id, url, status: 'pending' });
    queryClient.invalidateQueries({ queryKey: ['pages'] });
    setPageUrl('');
    setAddingPage(false);
  };

  if (!activeWebsite) {
    return <EmptyState icon={FileText} title="No website connected" description="Add a website in Settings first." />;
  }

  const scoreColor = (s) => s >= 80 ? 'text-green-600 bg-green-50' : s >= 50 ? 'text-amber-600 bg-amber-50' : 'text-red-600 bg-red-50';

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Content Optimizer" description="Analyze and improve your pages for better rankings" />

      <div className="flex gap-3">
        <Input
          placeholder="Add a page URL to analyze..."
          value={pageUrl}
          onChange={e => setPageUrl(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && addPage()}
          className="flex-1 rounded-xl"
        />
        <Button onClick={addPage} disabled={addingPage} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
          {addingPage ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
          Add Page
        </Button>
      </div>

      {pages.length === 0 && !isLoading ? (
        <EmptyState icon={FileText} title="No pages added" description="Add page URLs above to start optimizing content." />
      ) : (
        <div className="space-y-3">
          {pages.map(page => (
            <Card key={page.id} className="hover:shadow-sm transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{page.url}</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      {page.seo_score != null && (
                        <Badge className={scoreColor(page.seo_score)}>SEO: {page.seo_score}</Badge>
                      )}
                      {page.content_score != null && (
                        <Badge className={scoreColor(page.content_score)}>Content: {page.content_score}</Badge>
                      )}
                      {page.word_count && (
                        <span className="text-xs text-gray-400">{page.word_count} words</span>
                      )}
                      {page.status === 'optimized' && (
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      )}
                    </div>
                    {page.keywords?.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {page.keywords.slice(0, 5).map((kw, i) => (
                          <span key={i} className="text-[10px] px-2 py-0.5 rounded-full bg-purple-50 text-purple-600">{kw}</span>
                        ))}
                      </div>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => analyzePage(page)}
                    disabled={analyzing === page.id}
                    className="rounded-xl gap-2"
                  >
                    {analyzing === page.id ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Sparkles className="w-4 h-4" />
                    )}
                    {analyzing === page.id ? 'Analyzing...' : 'Analyze'}
                  </Button>
                </div>

                {page.issues?.length > 0 && (
                  <div className="mt-4 border-t border-gray-100 pt-3 space-y-1.5">
                    {page.issues.slice(0, 3).map((issue, i) => (
                      <div key={i} className="text-xs flex items-start gap-2">
                        <span className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${issue.severity === 'critical' ? 'bg-red-500' : issue.severity === 'warning' ? 'bg-amber-500' : 'bg-blue-500'}`} />
                        <span className="text-gray-600">{issue.description}</span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {recommendations.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Content Recommendations</h3>
          <div className="space-y-2">
            {recommendations.map(rec => (
              <div key={rec.id} className="flex items-start gap-3 p-3 rounded-xl bg-gray-50/50">
                <Sparkles className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-800">{rec.description}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{rec.page_url}</p>
                  {rec.suggested_content && (
                    <p className="text-xs text-gray-600 mt-1 bg-white p-2 rounded-lg border border-gray-100">{rec.suggested_content}</p>
                  )}
                </div>
                <Badge variant="secondary" className="text-[10px]">{rec.type.replace(/_/g, ' ')}</Badge>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}