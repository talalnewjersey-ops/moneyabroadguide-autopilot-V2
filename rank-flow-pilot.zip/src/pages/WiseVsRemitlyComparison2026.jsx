import React from 'react';
import SeoArticleLayout from '@/components/seo/SeoArticleLayout';
import { articlePages } from '@/lib/seoPages';

export default function WiseVsRemitlyComparison2026() {
  return <SeoArticleLayout page={articlePages.WiseVsRemitlyComparison2026} />;
}