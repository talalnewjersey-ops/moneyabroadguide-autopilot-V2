import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function ProjectOverview() {
  const { data: projects = [] } = useQuery({ queryKey: ['projects'], queryFn: () => base44.entities.Project.list('-created_date', 1) });
  const { data: websites = [] } = useQuery({ queryKey: ['websites'], queryFn: () => base44.entities.Website.list('-created_date', 50) });
  const { data: drafts = [] } = useQuery({ queryKey: ['content-drafts'], queryFn: () => base44.entities.ContentDraft.list('-created_date', 50) });
  const { data: fixes = [] } = useQuery({ queryKey: ['applied-fixes'], queryFn: () => base44.entities.AppliedFix.list('-created_date', 50) });
  const project = projects[0];
  const stats = [
    { label: 'Projects', value: projects.length },
    { label: 'Connected websites', value: websites.length },
    { label: 'Article drafts', value: drafts.length },
    { label: 'Applied fixes', value: fixes.length },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Project Overview" description={project ? `Primary project: ${project.name}` : 'Your operational SEO cockpit across websites and content.'} />
      <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4">{stats.map((item) => <Card key={item.label}><CardContent className="p-5"><p className="text-sm text-gray-500">{item.label}</p><p className="text-3xl font-semibold text-gray-900 mt-2">{item.value}</p></CardContent></Card>)}</div>
    </div>
  );
}