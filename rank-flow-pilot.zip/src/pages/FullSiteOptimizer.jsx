import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function FullSiteOptimizer() {
  const { data: websites = [] } = useQuery({ queryKey: ['optimizer-websites'], queryFn: () => base44.entities.Website.list('-created_date', 50) });
  const { data: recommendations = [] } = useQuery({ queryKey: ['optimizer-recommendations'], queryFn: () => base44.entities.ContentRecommendation.list('-created_date', 100) });
  const { data: fixes = [] } = useQuery({ queryKey: ['optimizer-fixes'], queryFn: () => base44.entities.AppliedFix.list('-created_date', 100) });
  const stats = [{ label: 'Connected sites', value: websites.length }, { label: 'Open recommendations', value: recommendations.length }, { label: 'Applied fixes', value: fixes.length }];
  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Full Site Optimizer" description="Scale metadata, internal links, content refreshes, and safe automated fixes across whole websites." />
      <div className="grid md:grid-cols-3 gap-4">{stats.map((item) => <Card key={item.label}><CardContent className="p-5"><p className="text-sm text-gray-500">{item.label}</p><p className="text-3xl font-semibold text-gray-900 mt-2">{item.value}</p></CardContent></Card>)}</div>
    </div>
  );
}