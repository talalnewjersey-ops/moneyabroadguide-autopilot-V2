import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  FileText, Key, Search, Link2, Globe, Shield, TrendingUp,
  ArrowRight, Loader2, Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import ScoreGauge from '../components/dashboard/ScoreGauge';
import MetricCard from '../components/dashboard/MetricCard';
import IssuesList from '../components/dashboard/IssuesList';
import EmptyState from '../components/common/EmptyState';
import PageHeader from '../components/common/PageHeader';

export default function Dashboard() {
  const { data: websites = [], isLoading: loadingWebsites } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 10),
  });

  const activeWebsite = websites[0];

  const { data: scans = [] } = useQuery({
    queryKey: ['scans', activeWebsite?.id],
    queryFn: () => base44.entities.SiteScan.filter({ website_id: activeWebsite.id }, '-created_date', 1),
    enabled: !!activeWebsite,
  });

  const { data: pages = [] } = useQuery({
    queryKey: ['pages', activeWebsite?.id],
    queryFn: () => base44.entities.Page.filter({ website_id: activeWebsite.id }),
    enabled: !!activeWebsite,
  });

  const { data: keywords = [] } = useQuery({
    queryKey: ['keywords', activeWebsite?.id],
    queryFn: () => base44.entities.Keyword.filter({ website_id: activeWebsite.id }),
    enabled: !!activeWebsite,
  });

  const { data: backlinks = [] } = useQuery({
    queryKey: ['backlinks', activeWebsite?.id],
    queryFn: () => base44.entities.BacklinkOpportunity.filter({ website_id: activeWebsite.id }),
    enabled: !!activeWebsite,
  });

  const latestScan = scans[0];

  if (loadingWebsites) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-6 h-6 text-blue-500 animate-spin" />
      </div>
    );
  }

  if (!activeWebsite) {
    return (
      <EmptyState
        icon={Globe}
        title="Welcome to SEO Autopilot"
        description="Add your first website to start optimizing your SEO with AI."
        action="+ Add Website"
        onAction={() => window.location.href = createPageUrl('AppSettings')}
      />
    );
  }

  const optimizedPages = pages.filter(p => p.status === 'optimized').length;
  const issuesList = latestScan?.issues || [];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader
        title="Dashboard"
        description={`Monitoring ${activeWebsite.name} — ${activeWebsite.url}`}
      />

      {/* Score + Quick Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        <div className="lg:col-span-1 bg-white rounded-2xl border border-gray-100 p-6 flex items-center justify-center">
          <ScoreGauge score={activeWebsite.seo_score || 0} label="SEO Score" />
        </div>
        <div className="lg:col-span-4 grid grid-cols-2 md:grid-cols-4 gap-4">
          <MetricCard title="Pages Scanned" value={pages.length} icon={FileText} color="blue" />
          <MetricCard title="Pages Optimized" value={optimizedPages} icon={TrendingUp} color="green" />
          <MetricCard title="Keywords Tracked" value={keywords.length} icon={Key} color="purple" />
          <MetricCard title="Backlink Opportunities" value={backlinks.length} icon={Globe} color="cyan" />
        </div>
      </div>

      {/* Issues + Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">Recent Issues</h3>
            <Link to={createPageUrl('SiteAudit')} className="text-xs text-blue-500 hover:text-blue-600 flex items-center gap-1">
              View All <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <IssuesList issues={issuesList} />
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-2">
            {[
              { label: 'View Public Homepage', page: 'HomePage', href: '/HomePage', icon: Globe, color: 'text-emerald-500' },
              { label: 'Run Site Audit', page: 'SiteAudit', icon: Search, color: 'text-blue-500' },
              { label: 'Discover Keywords', page: 'KeywordCenter', icon: Key, color: 'text-purple-500' },
              { label: 'Optimize Content', page: 'ContentOptimizer', icon: FileText, color: 'text-green-500' },
              { label: 'Check E-E-A-T', page: 'EEAT', icon: Shield, color: 'text-amber-500' },
              { label: 'Find Backlinks', page: 'Backlinks', icon: Link2, color: 'text-cyan-500' },
              { label: 'SEO Autopilot Center', page: 'SeoAutopilotCenter', href: '/seo-autopilot-center', icon: Shield, color: 'text-slate-700' },
              { label: 'Download Writesonic Plugin', page: 'WritesonicPluginDownload', icon: Plus, color: 'text-rose-500' },
            ].map(item => (
              <Link
                key={item.page}
                to={item.href || (item.page === 'WritesonicPluginDownload' ? '/WritesonicPluginDownload' : createPageUrl(item.page))}
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors group"
              >
                <item.icon className={`w-4 h-4 ${item.color}`} />
                <span className="text-sm text-gray-700 group-hover:text-gray-900">{item.label}</span>
                <ArrowRight className="w-3 h-3 ml-auto text-gray-300 group-hover:text-gray-500 transition-colors" />
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}