import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import OpenAI from 'npm:openai@4.104.0';

const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY') });
const normalizeUrl = (url = '') => url.toLowerCase().trim().replace(/\/$/, '');
const toText = (value = '') => typeof value === 'string' ? value : value == null ? '' : String(value);
const toNumber = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const toArray = (value) => Array.isArray(value) ? value : [];

const getWebsite = async (base44, siteUrl, apiKey) => {
  const websites = await base44.asServiceRole.entities.Website.list();
  return websites.find((item) => normalizeUrl(item.url) === normalizeUrl(siteUrl) && item.wordpress_api_key === apiKey);
};

const askOpenAI = async (prompt) => {
  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: 'You are an SEO keyword strategist using ChatGPT. Return only valid JSON with no markdown.'
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
  });

  return JSON.parse(response.choices[0]?.message?.content || '{}');
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'keywordOpportunities', required_fields: ['site_url', 'api_key'], optional_fields: ['pages', 'niche', 'language', 'country'] });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.site_url || !payload.api_key) {
      return Response.json({ endpoint: 'keywordOpportunities', required_fields: ['site_url', 'api_key'], optional_fields: ['pages', 'niche', 'language', 'country'] });
    }

    const website = await getWebsite(base44, payload.site_url, payload.api_key);
    if (!website) {
      return Response.json({ error: 'Unauthorized WordPress connection.' }, { status: 403 });
    }

    const contextPages = toArray(payload.pages).slice(0, 50).map((page) => ({
      title: toText(page.title),
      url: toText(page.url),
      categories: toArray(page.categories),
      tags: toArray(page.tags),
    }));

    const rawResult = await askOpenAI(`Generate strong keyword opportunities for ${website.url}. Prioritize finance, banking, credit building, money transfers, budgeting, and newcomer topics for expats, immigrants, foreign workers, and international students in the USA and Canada unless the payload specifies another niche. Payload niche: ${toText(payload.niche || 'expat finance')}. Language: ${toText(payload.language || 'English')}. Country: ${toText(payload.country || 'USA and Canada')}. Use these existing pages as context: ${JSON.stringify(contextPages)}. Return JSON with a keywords array. Each keyword must include: keyword, search_volume, difficulty, intent, cluster, assigned_page, current_position, status.`);

    const keywords = toArray(rawResult.keywords).map((keyword) => ({
      keyword: toText(keyword.keyword),
      search_volume: toNumber(keyword.search_volume),
      difficulty: toText(keyword.difficulty || 'medium'),
      intent: toText(keyword.intent || 'informational'),
      cluster: toText(keyword.cluster),
      assigned_page: toText(keyword.assigned_page),
      current_position: toNumber(keyword.current_position),
      status: toText(keyword.status || 'opportunity'),
    })).filter((keyword) => keyword.keyword);

    for (const keyword of keywords) {
      await base44.asServiceRole.entities.Keyword.create({
        website_id: website.id,
        keyword: keyword.keyword,
        search_volume: keyword.search_volume,
        difficulty: keyword.difficulty,
        intent: keyword.intent,
        cluster: keyword.cluster,
        assigned_page: keyword.assigned_page,
        current_position: keyword.current_position,
        status: keyword.status,
      });
    }

    return Response.json({ success: true, keywords });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});