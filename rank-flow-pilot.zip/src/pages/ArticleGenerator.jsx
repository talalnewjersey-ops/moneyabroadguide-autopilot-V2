import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

export default function ArticleGenerator() {
  const [keyword, setKeyword] = useState('');
  const [titleHint, setTitleHint] = useState('');
  const [loading, setLoading] = useState(false);
  const queryClient = useQueryClient();
  const { data: projects = [] } = useQuery({ queryKey: ['projects'], queryFn: () => base44.entities.Project.list('-created_date', 1) });
  const { data: drafts = [] } = useQuery({ queryKey: ['content-drafts'], queryFn: () => base44.entities.ContentDraft.list('-created_date', 50) });

  const generate = async () => {
    if (!projects[0] || !keyword) return;
    setLoading(true);
    await base44.functions.invoke('generateContentBrief', { project_id: projects[0].id, workspace_id: projects[0].workspace_id, primary_keyword: keyword, audience: 'expats and newcomers', country: 'USA and Canada', tone: 'helpful expert', article_type: 'guide' });
    await base44.functions.invoke('generateArticleDraft', { project_id: projects[0].id, workspace_id: projects[0].workspace_id, primary_keyword: keyword, title_hint: titleHint, audience: 'expats and newcomers', country: 'USA and Canada', tone: 'helpful expert', article_type: 'guide', length: '3000 words' });
    setKeyword('');
    setTitleHint('');
    setLoading(false);
    queryClient.invalidateQueries({ queryKey: ['content-drafts'] });
    queryClient.invalidateQueries({ queryKey: ['content-briefs'] });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Article Generator" description="Create full SEO articles and WordPress-ready HTML drafts with one workflow." />
      <div className="grid md:grid-cols-3 gap-3"><Input value={keyword} onChange={(e) => setKeyword(e.target.value)} placeholder="Primary keyword" className="rounded-xl" /><Input value={titleHint} onChange={(e) => setTitleHint(e.target.value)} placeholder="Optional title hint" className="rounded-xl" /><Button onClick={generate} disabled={loading} className="rounded-xl bg-blue-600 hover:bg-blue-700 gap-2">{loading && <Loader2 className="w-4 h-4 animate-spin" />}Generate Article</Button></div>
      <div className="space-y-3">{drafts.map((draft) => <Card key={draft.id}><CardContent className="p-5"><div className="flex items-start justify-between gap-3"><div><h3 className="font-semibold text-gray-900">{draft.title}</h3><p className="text-sm text-gray-500 mt-1">{draft.primary_keyword}</p><p className="text-xs text-gray-400 mt-2">{draft.meta_title || 'Meta pending'} · {draft.wordpress_status}</p></div><Button size="sm" variant="outline" className="rounded-lg" onClick={() => base44.functions.invoke('pushDraftToWordPress', { draft_id: draft.id })}>Push to WordPress</Button></div></CardContent></Card>)}</div>
    </div>
  );
}