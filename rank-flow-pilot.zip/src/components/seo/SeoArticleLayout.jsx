import React from 'react';
import { ArrowRight, CheckCircle2, Shield, Zap } from 'lucide-react';
import HomeHeader from '@/components/home/HomeHeader';
import HomeFooter from '@/components/home/HomeFooter';
import HomeFinalCta from '@/components/home/HomeFinalCta';
import HomeComparison from '@/components/home/HomeComparison';
import MoneyTransferCalculator from '@/components/home/MoneyTransferCalculator';
import StickyCompareBar from '@/components/home/StickyCompareBar';
import SectionReveal from '@/components/home/SectionReveal';
import SeoMeta from '@/components/seo/SeoMeta';
import { transferServices } from '@/lib/homepageData';

const trustPoints = [
  'Updated for 2026 search intent',
  'Built to convert calculator traffic',
  'Focused on total cost, speed, and safety',
];

export default function SeoArticleLayout({ page }) {
  const featuredProviders = transferServices.slice(0, 3);

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-950">
      <SeoMeta title={page.title} description={page.metaDescription} />
      <HomeHeader />

      <section className="hero border-b border-slate-200">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
          <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
            <div className="space-y-5">
              <div className="inline-flex items-center rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 shadow-sm">
                SEO page • {page.slug}
              </div>
              <h1 className="max-w-4xl text-4xl font-extrabold tracking-tight text-[#0F172A] sm:text-5xl lg:text-[52px] lg:leading-[1.06]">
                {page.h1}
              </h1>
              <p className="max-w-3xl text-lg leading-8 text-slate-500">
                {page.intro}
              </p>
              <div className="flex flex-col gap-3 sm:flex-row">
                <a href="#calculator" className="cta-primary h-14 px-7 text-base">Find the Cheapest Transfer Now</a>
                <a href="#compare" className="inline-flex h-14 items-center justify-center rounded-full border border-slate-200 bg-white px-7 text-base font-semibold text-slate-900 transition hover:border-slate-300 hover:bg-slate-50">See provider comparison</a>
              </div>
            </div>

            <div className="fintech-card grid gap-4 p-6 sm:grid-cols-3 lg:grid-cols-1">
              {page.summaryItems.map((item) => (
                <div key={item.label} className="rounded-[20px] bg-slate-50 p-5">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">{item.label}</p>
                  <p className="mt-3 text-lg font-semibold text-slate-950">{item.value}</p>
                </div>
              ))}
            </div>
          </div>
        </SectionReveal>
      </section>

      <section id="trust" className="trust bg-white">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6 lg:px-8 lg:py-10">
          <div className="grid gap-4 md:grid-cols-3">
            {trustPoints.map((point, index) => {
              const Icon = index === 0 ? CheckCircle2 : index === 1 ? Zap : Shield;
              return (
                <div key={point} className="fintech-card p-5">
                  <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#EAF7F1] text-[#1F8F6A]">
                      <Icon className="h-5 w-5" />
                    </div>
                    <p className="text-sm leading-7 text-slate-600">{point}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </SectionReveal>
      </section>

      <section id="calculator" className="bg-[#F8FAFC]">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 lg:px-8 lg:py-14">
          <MoneyTransferCalculator />
        </SectionReveal>
      </section>

      <section className="bg-[#F8FAFC]">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-4 sm:px-6 lg:px-8 lg:py-8">
          <div className="grid gap-5 md:grid-cols-3">
            {featuredProviders.map((provider, index) => (
              <div key={provider.name} className="fintech-card fintech-card-hover p-6">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#1F8F6A]">
                  {index === 0 ? 'Best deal' : index === 1 ? 'Fast payout' : 'Large transfer option'}
                </p>
                <h2 className="mt-3 text-2xl font-semibold text-slate-950">{provider.name}</h2>
                <p className="mt-3 text-base leading-7 text-slate-500">
                  {provider.fees} fees, {provider.exchangeRate.toLowerCase()}, and a {provider.rating} user rating.
                </p>
                <a href={provider.href} target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 rounded-full bg-black px-5 py-3 text-sm font-semibold text-white transition hover:opacity-90">
                  View Deal <ArrowRight className="h-4 w-4" />
                </a>
              </div>
            ))}
          </div>
        </SectionReveal>
      </section>

      <section className="bg-white">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
          <div className="space-y-5">
            {page.sections.map((section) => (
              <article key={section.title} className="fintech-card p-6 sm:p-8">
                <h2 className="text-3xl font-semibold tracking-tight text-slate-950">{section.title}</h2>
                <div className="mt-4 space-y-4">
                  {section.paragraphs.map((paragraph, idx) => (
                    <p key={idx} className="text-base leading-8 text-slate-600">{paragraph}</p>
                  ))}
                </div>
                {section.bullets?.length ? (
                  <ul className="mt-5 space-y-3">
                    {section.bullets.map((bullet) => (
                      <li key={bullet} className="flex gap-3 text-base leading-7 text-slate-600">
                        <CheckCircle2 className="mt-1 h-5 w-5 flex-shrink-0 text-[#1F8F6A]" />
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>
                ) : null}
              </article>
            ))}
          </div>
        </SectionReveal>
      </section>

      <HomeComparison />

      <section id="guides" className="guides bg-white">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
          <div className="fintech-card p-6 sm:p-8">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">Internal links</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">Keep exploring MoneyAbroadGuide</h2>
            <div className="mt-6 grid gap-4 md:grid-cols-3">
              {page.internalLinks.map((link) => (
                <a key={link.href} href={link.href} className="rounded-[20px] border border-slate-200 bg-slate-50 p-5 transition hover:-translate-y-1 hover:bg-white hover:shadow-[0_20px_40px_rgba(15,23,42,0.08)]">
                  <p className="text-lg font-semibold text-slate-950">{link.label}</p>
                  <p className="mt-2 text-sm leading-7 text-slate-500">{link.description}</p>
                </a>
              ))}
            </div>
            <a href="/Calculator" className="mt-6 inline-flex items-center gap-2 rounded-full bg-[#1F8F6A] px-6 py-3 text-sm font-semibold text-white transition hover:bg-[#187255]">
              Send Money Now <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </SectionReveal>
      </section>

      <section className="bg-[#F8FAFC]">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
          <div className="space-y-4">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">FAQ</p>
            <h2 className="text-3xl font-semibold tracking-tight text-slate-950">Frequently asked questions</h2>
            <div className="grid gap-4">
              {page.faq.map((item) => (
                <div key={item.question} className="fintech-card p-6">
                  <h3 className="text-xl font-semibold text-slate-950">{item.question}</h3>
                  <p className="mt-3 text-base leading-8 text-slate-600">{item.answer}</p>
                </div>
              ))}
            </div>
          </div>
        </SectionReveal>
      </section>

      <HomeFinalCta />
      <HomeFooter />
      <StickyCompareBar />
    </div>
  );
}