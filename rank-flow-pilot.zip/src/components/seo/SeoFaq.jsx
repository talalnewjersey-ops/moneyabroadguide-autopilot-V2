import React from 'react';
import { ChevronRight } from 'lucide-react';

export default function SeoFaq({ items }) {
  return (
    <div className="space-y-4">
      {items.map((item) => (
        <div key={item.question} className="fintech-card p-5">
          <div className="flex items-start gap-3">
            <ChevronRight className="mt-1 h-4 w-4 text-[#1F8F6A]" />
            <div>
              <h3 className="text-lg font-semibold text-slate-950">{item.question}</h3>
              <p className="mt-2 text-base leading-7 text-slate-500">{item.answer}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}