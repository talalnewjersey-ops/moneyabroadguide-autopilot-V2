import React, { useMemo, useState } from 'react';
import HomeFooter from '@/components/home/HomeFooter';

const providerData = [
  { name: 'Wise', feePct: { USD: 0.006, EUR: 0.0055 }, fixedFee: { USD: 2.49, EUR: 2.29 }, speedRank: 2, speed: 'Minutes to 2 days', ratePenalty: 0, href: 'https://wise.com/' },
  { name: 'Remitly', feePct: { USD: 0.008, EUR: 0.0075 }, fixedFee: { USD: 3.99, EUR: 3.79 }, speedRank: 1, speed: 'Express minutes', ratePenalty: 0.12, href: 'https://www.remitly.com/' },
  { name: 'Western Union', feePct: { USD: 0.011, EUR: 0.0105 }, fixedFee: { USD: 5.99, EUR: 5.49 }, speedRank: 3, speed: 'Minutes to 1 day', ratePenalty: 0.22, href: 'https://www.westernunion.com/' },
  { name: 'XE', feePct: { USD: 0.009, EUR: 0.0085 }, fixedFee: { USD: 4.49, EUR: 4.29 }, speedRank: 4, speed: 'Same day to 2 days', ratePenalty: 0.16, href: 'https://www.xe.com/' },
  { name: 'OFX', feePct: { USD: 0.0072, EUR: 0.0068 }, fixedFee: { USD: 0, EUR: 0 }, speedRank: 5, speed: '1–3 days', ratePenalty: 0.08, href: 'https://www.ofx.com/' },
];

const rates = {
  India: { USD: 82.4, EUR: 89.6, symbol: '₹' },
  Mexico: { USD: 16.9, EUR: 18.4, symbol: 'MX$' },
  Philippines: { USD: 56.2, EUR: 61.4, symbol: '₱' },
  UK: { USD: 0.79, EUR: 0.86, symbol: '£' },
  Germany: { USD: 0.92, EUR: 1.0, symbol: '€' },
};

const usaGuides = [
  { title: 'Best Banks for Immigrants in the USA', desc: 'Banking choices for newcomers building a financial life in the United States.' },
  { title: 'How to Build Credit in the USA', desc: 'Starter guidance for immigrants who need to build credit safely.' },
  { title: 'Cost of Living in the USA 2026', desc: 'Understand core expenses before planning cross-border support.' },
];

const canadaGuides = [
  { title: 'Best Banks for Newcomers in Canada', desc: 'Understand which banks are most practical for new arrivals.' },
  { title: 'Canada Banking Fees Guide', desc: 'Avoid hidden charges and compare common account costs.' },
  { title: 'Financial Checklist for Newcomers to Canada', desc: 'A simple roadmap for building financial stability faster.' },
];

const corridors = ['USA → India', 'USA → Mexico', 'USA → Philippines', 'Europe → UK', 'Europe → Germany'];
const faqs = [
  ['What is the cheapest transfer method?', 'The cheapest method depends on fee structure and exchange-rate quality together.'],
  ['How do I get the best exchange rate?', 'Compare the final amount received because a weaker FX rate can cost more than the visible fee.'],
  ['Which provider is fastest?', 'Speed depends on the route, transfer method, and payout option.'],
  ['How do immigrants avoid hidden fees?', 'Compare multiple providers and review the final amount received before sending.'],
  ['Is this financial advice?', 'No. This content is educational only and users should verify details directly with providers.'],
];

function money(value, currency) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(value || 0);
}

export default function MagAutoLandingProPreview() {
  const [amount, setAmount] = useState(1000);
  const [currency, setCurrency] = useState('USD');
  const [country, setCountry] = useState('Philippines');
  const [sortBy, setSortBy] = useState('best');

  const results = useMemo(() => {
    const safeAmount = Math.max(100, Number(amount) || 1000);
    const rateInfo = rates[country];

    const rows = providerData.map((provider) => {
      const fee = safeAmount * provider.feePct[currency] + provider.fixedFee[currency];
      const exchangeRate = rateInfo[currency] - provider.ratePenalty;
      const received = Math.max((safeAmount - fee) * exchangeRate, 0);
      const valueScore = received - fee * 0.35;
      return { ...provider, fee, exchangeRate, received, valueScore, symbol: rateInfo.symbol };
    });

    const sorted = [...rows].sort((a, b) => {
      if (sortBy === 'cheapest') return a.fee - b.fee;
      if (sortBy === 'fastest') return a.speedRank - b.speedRank;
      return b.valueScore - a.valueScore;
    });

    return sorted;
  }, [amount, currency, country, sortBy]);

  const best = results[0];
  const cheapest = [...results].sort((a, b) => a.fee - b.fee)[0];
  const fastest = [...results].sort((a, b) => a.speedRank - b.speedRank)[0];
  const avgFee = results.reduce((sum, item) => sum + item.fee, 0) / results.length;
  const saved = Math.max(0, avgFee - best.fee);

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-950">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1320px] items-center justify-between gap-6 px-4 py-4 lg:px-6">
          <a href="#top" className="flex items-center">
            <img src="https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/7807cf1df_logoMoneyabroadGuide.jpeg" alt="MoneyAbroadGuide" className="h-16 w-auto object-contain" loading="lazy" />
          </a>
          <nav className="hidden items-center gap-8 text-sm font-semibold text-slate-600 lg:flex">
            <a href="#compare" className="hover:text-[#166534]">Compare</a>
            <a href="#guides" className="hover:text-[#166534]">Guides</a>
            <a href="#trust" className="hover:text-[#166534]">Trust</a>
            <a href="#faq" className="hover:text-[#166534]">FAQ</a>
          </nav>
        </div>
      </header>

      <main id="top" className="mx-auto grid max-w-[1320px] grid-cols-1 gap-8 px-4 py-8 lg:grid-cols-[180px_minmax(0,900px)_180px] lg:px-6">
        <aside className="hidden lg:block">
          <div className="sticky top-28 rounded-2xl border border-slate-200 bg-white p-4 text-center text-sm text-slate-500 shadow-sm">Advertisement</div>
        </aside>

        <div className="space-y-8">
          <div className="rounded-2xl border border-amber-200 bg-amber-50 px-5 py-4 text-sm leading-7 text-amber-900">This page may contain affiliate links. We may earn a commission at no extra cost to you. Our editorial content remains independent and based on real user needs.</div>
          <div className="rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm leading-7 text-slate-600">MoneyAbroadGuide provides educational financial content for informational purposes only and does not constitute financial, legal, or tax advice.</div>
          <div className="rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm leading-7 text-slate-600">We independently research and compare financial services to help newcomers, immigrants, and expats make better decisions.</div>

          <section className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-10">
            <div className="mx-auto max-w-3xl text-center">
              <p className="mb-5 text-sm font-semibold uppercase tracking-[0.22em] text-[#16a34a]">Trusted financial education platform</p>
              <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-[58px] lg:leading-[1.02]">Save Up to 90% on International Money Transfers</h1>
              <p className="mt-5 text-lg leading-8 text-slate-600">Compare real-time rates from trusted providers and avoid hidden fees.</p>
              <div className="mt-6 flex flex-wrap justify-center gap-3 text-sm font-semibold">
                <span className="rounded-full border border-slate-200 bg-[#f0fdf4] px-4 py-2 text-[#166534]">Trusted by newcomers and expats</span>
                <span className="rounded-full border border-slate-200 bg-[#f0fdf4] px-4 py-2 text-[#166534]">Transparent fees</span>
                <span className="rounded-full border border-slate-200 bg-[#f0fdf4] px-4 py-2 text-[#166534]">Expert-reviewed content</span>
              </div>
              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <a href="#compare" className="inline-flex h-14 items-center justify-center rounded-full bg-[#16a34a] px-8 text-base font-semibold text-white shadow-[0_18px_40px_rgba(22,163,74,0.25)] transition hover:bg-[#166534]">Compare Now</a>
                <a href="#compare" className="inline-flex h-14 items-center justify-center rounded-full border border-slate-200 bg-white px-8 text-base font-semibold text-slate-950 transition hover:bg-slate-50">See Best Providers</a>
              </div>
              <div className="mt-8 grid gap-3 sm:grid-cols-3">
                <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-center"><strong className="block text-base text-slate-950">★★★★★</strong><span className="mt-2 block text-sm text-slate-500">Trusted by thousands of users</span></div>
                <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-center"><strong className="block text-base text-slate-950">Step 1</strong><span className="mt-2 block text-sm text-slate-500">Enter amount</span></div>
                <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-center"><strong className="block text-base text-slate-950">Step 2</strong><span className="mt-2 block text-sm text-slate-500">Compare providers</span></div>
              </div>
              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-center sm:col-start-2"><strong className="block text-base text-slate-950">Step 3</strong><span className="mt-2 block text-sm text-slate-500">Send money</span></div>
              </div>
            </div>
          </section>

          <section id="trust" className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-8">
            <div className="mx-auto max-w-3xl text-center">
              <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#16a34a]">Author & editorial authority</p>
              <h2 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">Financial education built for newcomers in North America</h2>
            </div>
            <div className="mt-6 rounded-[24px] border border-slate-200 bg-slate-50 p-6">
              <p className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-500">Author</p>
              <h3 className="mt-3 text-2xl font-bold text-slate-950">Talal Eddaouahiri</h3>
              <p className="mt-2 text-base font-medium text-[#166534]">Financial Guide for Newcomers in North America</p>
              <p className="mt-4 text-sm leading-7 text-slate-600">Talal Eddaouahiri writes educational financial guides focused on immigrants, expats, and newcomers navigating banking, money transfers, credit building, and financial setup in the USA and Canada.</p>
              <div className="mt-5 grid gap-4 md:grid-cols-4">
                <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><strong className="block text-slate-950">Trusted by immigrants</strong><span className="mt-2 block text-sm text-slate-500">USA & Canada audience</span></div>
                <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><strong className="block text-slate-950">Expert-reviewed</strong><span className="mt-2 block text-sm text-slate-500">Content updated regularly</span></div>
                <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><strong className="block text-slate-950">Methodology</strong><span className="mt-2 block text-sm text-slate-500">Fees, FX, speed, and value</span></div>
                <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><strong className="block text-slate-950">Independent</strong><span className="mt-2 block text-sm text-slate-500">Educational purpose only</span></div>
              </div>
            </div>
          </section>

          <section id="calculator" className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-8">
            <div className="mx-auto max-w-3xl text-center">
              <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#16a34a]">Dynamic calculator</p>
              <h2 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">Compare transfer options instantly</h2>
              <p className="mt-3 text-base leading-8 text-slate-500">Lightweight client-side calculation only, with minimal DOM updates and no external API calls.</p>
            </div>
            <div className="mt-8 grid gap-4 md:grid-cols-4">
              <label className="block text-sm font-medium text-slate-700">Amount<input type="number" min="100" value={amount} onChange={(e) => setAmount(e.target.value)} className="mt-2 h-12 w-full rounded-xl border border-slate-200 px-4" /></label>
              <label className="block text-sm font-medium text-slate-700">Currency<select value={currency} onChange={(e) => setCurrency(e.target.value)} className="mt-2 h-12 w-full rounded-xl border border-slate-200 px-4"><option value="USD">USD</option><option value="EUR">EUR</option></select></label>
              <label className="block text-sm font-medium text-slate-700">Destination<select value={country} onChange={(e) => setCountry(e.target.value)} className="mt-2 h-12 w-full rounded-xl border border-slate-200 px-4">{Object.keys(rates).map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
              <label className="block text-sm font-medium text-slate-700">Sort by<select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="mt-2 h-12 w-full rounded-xl border border-slate-200 px-4"><option value="best">Best value</option><option value="cheapest">Cheapest</option><option value="fastest">Fastest</option></select></label>
            </div>

            <div className="mt-6 grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
              <div className="rounded-[26px] border border-[#bbf7d0] bg-[linear-gradient(180deg,#f0fdf4_0%,#ffffff_100%)] p-6 shadow-[0_18px_40px_rgba(22,163,74,0.10)]">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full bg-[#16a34a] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-white">{best.badge}</span>
                  <span className="rounded-full bg-[#dcfce7] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#166534]">Independent comparison</span>
                </div>
                <p className="mt-4 text-sm font-semibold uppercase tracking-[0.18em] text-[#166534]">Best option</p>
                <h3 className="mt-2 text-4xl font-extrabold tracking-tight text-slate-950">{best.name}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">{best.badge} for {currency} → {country} when you want a better balance of fees, rate, and delivery time.</p>
                <div className="mt-6 rounded-[22px] bg-[#f8fafc] p-5">
                  <span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">You receive</span>
                  <strong className="mt-2 block text-4xl font-extrabold text-[#16a34a]">{best.symbol}{best.received.toLocaleString(undefined, { maximumFractionDigits: 0 })}</strong>
                  <p className="mt-3 text-sm leading-7 text-slate-500">Estimated amount after fees and exchange-rate impact.</p>
                </div>
                <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                  <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">Fees</span><strong className="mt-2 block text-2xl font-bold text-slate-950">{money(best.fee, currency)}</strong></div>
                  <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">Speed</span><strong className="mt-2 block text-2xl font-bold text-slate-950">{best.speed}</strong></div>
                  <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">You save vs avg</span><strong className="mt-2 block text-2xl font-bold text-slate-950">{money(saved, currency)}</strong></div>
                  <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">Trust note</span><strong className="mt-2 block text-lg font-bold text-slate-950">Updated regularly</strong></div>
                </div>
              </div>

              <div className="grid gap-4">
                <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Cheapest</p><strong className="mt-2 block text-2xl font-bold text-slate-950">{cheapest.name}</strong><p className="mt-2 text-sm text-slate-500">Typical fee {money(cheapest.fee, currency)}</p></div>
                <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Fastest</p><strong className="mt-2 block text-2xl font-bold text-slate-950">{fastest.name}</strong><p className="mt-2 text-sm text-slate-500">{fastest.speed}</p></div>
                <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Exchange rate impact</p><strong className="mt-2 block text-2xl font-bold text-slate-950">{best.exchangeRate.toFixed(2)}</strong><p className="mt-2 text-sm text-slate-500">Transparent comparison without heavy scripts or external APIs.</p></div>
              </div>
            </div>
          </section>

          <section id="compare" className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-8">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Dynamic comparison tool</h2>
              <p className="mt-3 text-base leading-8 text-slate-500">Sort by best value, cheapest, or fastest and compare what you really receive before you click through.</p>
            </div>
            <div className="mt-6 overflow-x-auto">
              <table className="w-full min-w-[900px] border-collapse text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                    <th className="px-4 py-4 font-semibold">Provider</th>
                    <th className="px-4 py-4 font-semibold">Fees</th>
                    <th className="px-4 py-4 font-semibold">Exchange rate</th>
                    <th className="px-4 py-4 font-semibold">You receive</th>
                    <th className="px-4 py-4 font-semibold">Speed</th>
                    <th className="px-4 py-4 font-semibold">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {results.map((provider) => (
                    <tr key={provider.name} className={`border-b border-slate-100 ${provider.name === best.name ? 'bg-emerald-50/70' : 'bg-white'}`}>
                      <td className="px-4 py-4 font-semibold text-slate-950">{provider.name} {provider.name === best.name ? '• BEST VALUE' : provider.name === cheapest.name ? '• LOWEST FEES' : provider.name === fastest.name ? '• FASTEST' : ''}</td>
                      <td className="px-4 py-4 text-slate-600">{money(provider.fee, currency)}</td>
                      <td className="px-4 py-4 text-slate-600">{provider.exchangeRate.toFixed(2)}</td>
                      <td className="px-4 py-4 font-semibold text-slate-950">{provider.symbol}{provider.received.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                      <td className="px-4 py-4 text-slate-600">{provider.speed}</td>
                      <td className="px-4 py-4"><a href={provider.href} rel="nofollow sponsored" target="_blank" className="inline-flex rounded-full bg-[#16a34a] px-4 py-2 text-xs font-semibold text-white transition hover:bg-[#166534]">View Offer</a></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white p-5 text-center shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Recommended Partner</p>
            <p className="mt-3 text-base text-slate-700">Space reserved for partner recommendations or AdSense-safe native banners.</p>
          </section>

          <section id="guides" className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-8">
            <div className="mx-auto max-w-3xl text-center">
              <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#16a34a]">Financial Guides for Newcomers in North America</p>
              <h2 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">Expert-written guides by Talal Eddaouahiri</h2>
              <p className="mt-3 text-base leading-8 text-slate-500">Carefully written educational articles for immigrants and newcomers in the USA and Canada.</p>
            </div>
            <div className="mt-6 grid gap-6 md:grid-cols-2">
              <div className="rounded-[24px] border border-slate-200 bg-slate-50 p-6">
                <h3 className="text-2xl font-bold text-slate-950">Newcomers to USA</h3>
                <div className="mt-5 space-y-4">
                  {usaGuides.map((guide) => (
                    <div key={guide.title} className="rounded-2xl border border-slate-200 bg-white p-5">
                      <div className="mb-4 flex h-32 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#f0fdf4_0%,#ffffff_100%)] text-4xl">{guide.accent}</div>
                      <p className="text-lg font-semibold text-slate-950">{guide.title}</p>
                      <div className="mt-2 flex flex-wrap gap-2 text-xs text-slate-500"><span>{guide.published}</span><span>•</span><span>{guide.updated}</span></div>
                      <p className="mt-3 text-sm leading-7 text-slate-500">{guide.desc}</p>
                      <p className="mt-3 text-sm font-medium text-[#166534]">By Talal Eddaouahiri</p>
                      <a href="#" className="mt-4 inline-flex rounded-full border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-950">Read Guide</a>
                    </div>
                  ))}
                </div>
              </div>
              <div className="rounded-[24px] border border-slate-200 bg-slate-50 p-6">
                <h3 className="text-2xl font-bold text-slate-950">Newcomers to Canada</h3>
                <div className="mt-5 space-y-4">
                  {canadaGuides.map((guide) => (
                    <div key={guide.title} className="rounded-2xl border border-slate-200 bg-white p-5">
                      <div className="mb-4 flex h-32 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#f0fdf4_0%,#ffffff_100%)] text-4xl">{guide.accent}</div>
                      <p className="text-lg font-semibold text-slate-950">{guide.title}</p>
                      <div className="mt-2 flex flex-wrap gap-2 text-xs text-slate-500"><span>{guide.published}</span><span>•</span><span>{guide.updated}</span></div>
                      <p className="mt-3 text-sm leading-7 text-slate-500">{guide.desc}</p>
                      <p className="mt-3 text-sm font-medium text-[#166534]">By Talal Eddaouahiri</p>
                      <a href="#" className="mt-4 inline-flex rounded-full border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-950">Read Guide</a>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          <section className="rounded-[28px] border border-slate-200 bg-white p-8 text-center shadow-[0_18px_45px_rgba(15,23,42,0.08)]">
            <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl text-slate-950">Stop Overpaying Transfer Fees</h2>
            <p className="mt-3 text-base leading-8 text-slate-500">Takes less than 30 seconds to compare stronger rates and lower fees.</p>
            <div className="mt-6 flex justify-center">
              <a href="#compare" className="inline-flex h-14 items-center justify-center rounded-full bg-[#16a34a] px-8 text-base font-semibold text-white shadow-[0_18px_40px_rgba(22,163,74,0.25)] transition hover:bg-[#166534]">Compare Now</a>
            </div>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white p-5 text-center shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Sponsored Recommendation</p>
            <p className="mt-3 text-base text-slate-700">Second sponsored block reserved for partners, affiliate offers, or AdSense-safe placements.</p>
          </section>

          <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-8">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Best Ways to Send Money Internationally</h2>
            </div>
            <div className="prose prose-slate mt-6 max-w-none text-slate-600">
              <h3>Best Ways to Send Money</h3>
              <p>Sending money internationally is not just about clicking the cheapest provider on the screen. For newcomers in North America, the best route depends on how often you send, how urgent the transfer is, what currency you are using, and what the recipient needs on the other side. A provider with a low visible fee can still be expensive if the exchange rate is weak or if the payout method adds hidden costs.</p>
              <p>That is why a lightweight but structured comparison experience matters. Users need a clean path to compare fees, exchange rates, speed, and the final amount received. Search engines also reward pages that combine educational clarity with topical depth and a logical internal-linking structure.</p>
              <h3>How to Avoid Fees</h3>
              <p>The easiest way to reduce transfer costs is to compare final value, not just fee labels. Hidden FX markup can quietly cost more than the service fee itself. Users should also compare bank deposit versus mobile wallet versus pickup options because each route changes both cost and convenience.</p>
              <h3>USD vs EUR Explained</h3>
              <p>USD and EUR transfers behave differently depending on the destination corridor, but the comparison principle remains the same. Compare total fees, compare the exchange rate, and compare the amount received. This is especially useful for recurring remittances where even small savings become meaningful over time.</p>
              <h3>Best Options for Newcomers</h3>
              <p>Newcomers often care about more than price. They may need a provider with easier onboarding, better language clarity, or stronger trust signals. That is why educational content and comparison tools should work together to reduce friction and increase confidence before a financial decision is made.</p>
            </div>
          </section>

          <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-8">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Popular Transfer Corridors</h2>
            </div>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {corridors.map((item) => (
                <div key={item} className="rounded-2xl border border-slate-200 bg-slate-50 p-5 shadow-sm">
                  <h3 className="text-xl font-bold text-slate-950">{item}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-500">High-intent corridor for comparison and affiliate monetization.</p>
                </div>
              ))}
            </div>
          </section>

          <section id="faq" className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-8">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Frequently Asked Questions</h2>
            </div>
            <div className="mt-6 grid gap-4">
              {faqs.map(([question, answer]) => (
                <div key={question} className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
                  <h3 className="text-lg font-bold text-slate-950">{question}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-500">{answer}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-[28px] border border-slate-200 bg-[#16a34a] p-8 text-center text-white shadow-[0_18px_45px_rgba(22,163,74,0.22)]">
            <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Start Saving on International Transfers Today</h2>
            <p className="mt-3 text-base leading-8 text-white/85">100% free comparison – no hidden fees.</p>
            <div className="mt-6 flex justify-center">
              <a href="#compare" className="inline-flex h-14 items-center justify-center rounded-full bg-white px-8 text-base font-semibold text-[#166534] transition hover:bg-slate-100">Compare &amp; Save Now</a>
            </div>
          </section>

          <div className="rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm leading-7 text-slate-500 shadow-sm">
            We strive to provide accurate and up-to-date financial information, but we recommend verifying details directly with providers. MoneyAbroadGuide.com provides informational content only and does not constitute financial, legal, or tax advice.
          </div>
        </div>

        <aside className="hidden lg:block">
          <div className="sticky top-28 rounded-2xl border border-slate-200 bg-white p-4 text-center text-sm text-slate-500 shadow-sm">Advertisement</div>
        </aside>
      </main>

      <HomeFooter />
    </div>
  );
}