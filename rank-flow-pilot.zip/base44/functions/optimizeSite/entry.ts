import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import OpenAI from 'npm:openai@4.104.0';

const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY') });
const normalizeUrl = (url = '') => url.toLowerCase().trim().replace(/\/$/, '');
const toText = (value = '') => typeof value === 'string' ? value : value == null ? '' : String(value);
const toNumber = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const toArray = (value) => Array.isArray(value) ? value : [];
const flattenTextParts = (value) => {
  if (typeof value === 'string') return [value];
  if (typeof value === 'number') return [String(value)];
  if (Array.isArray(value)) return value.flatMap((item) => flattenTextParts(item));
  if (value && typeof value === 'object') {
    const preferred = [value.title, value.name, value.label, value.description, value.summary].filter(Boolean);
    if (preferred.length > 0) return preferred.flatMap((item) => flattenTextParts(item));
    return Object.values(value).flatMap((item) => flattenTextParts(item));
  }
  return [];
};
const toRichText = (value) => flattenTextParts(value).map((item) => String(item).trim()).filter(Boolean).join(' · ');

const getWebsite = async (base44, siteUrl, apiKey) => {
  const websites = await base44.asServiceRole.entities.Website.list();
  return websites.find((item) => normalizeUrl(item.url) === normalizeUrl(siteUrl) && item.wordpress_api_key === apiKey);
};

const askOpenAI = async (prompt) => {
  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: 'You are an expert SEO strategist using ChatGPT. Return only valid JSON with no markdown.'
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
  });

  return JSON.parse(response.choices[0]?.message?.content || '{}');
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'optimizeSite', required_fields: ['site_url', 'api_key'], optional_fields: ['pages', 'mode'] });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.site_url || !payload.api_key) {
      return Response.json({ endpoint: 'optimizeSite', required_fields: ['site_url', 'api_key'], optional_fields: ['pages', 'mode'] });
    }

    const website = await getWebsite(base44, payload.site_url, payload.api_key);
    if (!website) {
      return Response.json({ error: 'Unauthorized WordPress connection.' }, { status: 403 });
    }

    const pages = toArray(payload.pages).slice(0, 50).map((page) => ({
      id: toNumber(page.id),
      url: toText(page.url),
      title: toText(page.title),
      meta_description: toText(page.meta_description),
      h1: toText(page.h1),
      content: toText(page.content).slice(0, 3500),
      internal_links: toArray(page.internal_links),
      images: toArray(page.images).slice(0, 20),
      categories: toArray(page.categories),
      tags: toArray(page.tags),
    }));

    const rawResult = await askOpenAI(`Create a prioritized SEO optimization plan for ${website.url}. Prioritize finance and banking content for expats, immigrants, newcomers, foreign workers, and international students in the USA and Canada unless the payload says otherwise. Payload niche: ${toText(payload.niche || 'expat finance')}. Language: ${toText(payload.language || 'English')}. Country: ${toText(payload.country || 'USA and Canada')}. Use this page data: ${JSON.stringify(pages)}. Return JSON with keys: summary, priorities, auto_fixes, improvements, backlink_opportunities, eeat_recommendations, sitewide_fixes. auto_fixes must contain page_id, page_url, optimized_title, optimized_meta_description, image_alt_updates. improvements must contain page_url, type, priority, description, suggested_content, impact_score. backlink_opportunities must contain source_name, source_url, type, relevance_score, notes. eeat_recommendations must be an array of strings. sitewide_fixes must contain homepage_h1, og_title, og_description, og_image_url. Generate safe WordPress-ready fixes for as many relevant pages as possible.`);

    const result = {
      summary: toRichText(rawResult.summary),
      priorities: toArray(rawResult.priorities).map((item) => toRichText(item)).filter(Boolean),
      auto_fixes: toArray(rawResult.auto_fixes).map((fix) => ({
        page_id: toNumber(fix.page_id),
        page_url: toText(fix.page_url),
        optimized_title: toRichText(fix.optimized_title),
        optimized_meta_description: toRichText(fix.optimized_meta_description),
        image_alt_updates: toArray(fix.image_alt_updates).map((update) => ({
          image_url: toText(update.image_url),
          alt_text: toText(update.alt_text),
        })).filter((update) => update.image_url && update.alt_text),
      })).filter((fix) => fix.page_url),
      improvements: toArray(rawResult.improvements).map((improvement) => ({
        page_url: toText(improvement.page_url),
        type: toText(improvement.type || 'content_refresh'),
        priority: toText(improvement.priority || 'medium'),
        description: toRichText(improvement.description),
        suggested_content: toRichText(improvement.suggested_content),
        impact_score: toNumber(improvement.impact_score),
      })).filter((item) => item.description),
      backlink_opportunities: toArray(rawResult.backlink_opportunities).map((item) => ({
        source_name: toText(item.source_name),
        source_url: toText(item.source_url),
        type: toText(item.type || 'guest_post'),
        relevance_score: toNumber(item.relevance_score),
        notes: toRichText(item.notes),
      })).filter((item) => item.source_url),
      eeat_recommendations: toArray(rawResult.eeat_recommendations).map((item) => toRichText(item)).filter(Boolean),
      sitewide_fixes: {
        homepage_h1: toRichText(rawResult.sitewide_fixes?.homepage_h1),
        og_title: toRichText(rawResult.sitewide_fixes?.og_title),
        og_description: toRichText(rawResult.sitewide_fixes?.og_description),
        og_image_url: toText(rawResult.sitewide_fixes?.og_image_url || 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/f902e43fa_generated_image.png'),
      },
    };

    for (const improvement of result.improvements) {
      await base44.asServiceRole.entities.ContentRecommendation.create({
        website_id: website.id,
        page_url: improvement.page_url || website.url,
        type: improvement.type,
        priority: improvement.priority,
        description: improvement.description,
        suggested_content: improvement.suggested_content,
        impact_score: improvement.impact_score,
        status: 'pending',
      });
    }

    const existingBacklinks = await base44.asServiceRole.entities.BacklinkOpportunity.filter({ website_id: website.id }, '-created_date', 200);
    const existingUrls = new Set(existingBacklinks.map((item) => toText(item.source_url).toLowerCase()));

    for (const backlink of result.backlink_opportunities) {
      const sourceUrl = backlink.source_url.toLowerCase();
      if (!sourceUrl || existingUrls.has(sourceUrl)) continue;
      await base44.asServiceRole.entities.BacklinkOpportunity.create({
        website_id: website.id,
        source_url: backlink.source_url,
        source_name: backlink.source_name,
        type: backlink.type,
        relevance_score: backlink.relevance_score,
        notes: backlink.notes,
        status: 'discovered',
      });
      existingUrls.add(sourceUrl);
    }

    return Response.json({
      success: true,
      mode: payload.mode || 'assisted',
      summary: result.summary,
      priorities: result.priorities,
      auto_fixes: result.auto_fixes,
      improvements: result.improvements,
      backlink_opportunities: result.backlink_opportunities,
      eeat_recommendations: result.eeat_recommendations,
      sitewide_fixes: result.sitewide_fixes,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});