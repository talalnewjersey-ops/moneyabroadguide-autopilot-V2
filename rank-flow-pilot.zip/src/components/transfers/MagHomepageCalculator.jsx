import React, { useMemo, useState } from 'react';

const providerConfigs = [
  { name: 'Wise', feePct: { USD: 0.006, EUR: 0.0055 }, fixedFee: { USD: 2.49, EUR: 2.29 }, speed: 'Minutes to 24h', badge: 'Best Value', ratePenalty: 0 },
  { name: 'Remitly', feePct: { USD: 0.008, EUR: 0.0075 }, fixedFee: { USD: 3.99, EUR: 3.79 }, speed: 'Express minutes', badge: 'Fastest', ratePenalty: 0.12 },
  { name: 'Western Union', feePct: { USD: 0.011, EUR: 0.0105 }, fixedFee: { USD: 5.99, EUR: 5.49 }, speed: 'Minutes to 1 day', badge: 'Pickup Network', ratePenalty: 0.22 },
  { name: 'XE', feePct: { USD: 0.009, EUR: 0.0085 }, fixedFee: { USD: 4.49, EUR: 4.29 }, speed: 'Same day to 2 days', badge: 'Rate Tools', ratePenalty: 0.16 },
  { name: 'OFX', feePct: { USD: 0.0072, EUR: 0.0068 }, fixedFee: { USD: 0.0, EUR: 0.0 }, speed: '1–3 days', badge: 'Large Transfers', ratePenalty: 0.08 },
];

const countryRates = {
  Mexico: { USD: 16.9, EUR: 18.4, symbol: 'MX$' },
  India: { USD: 82.4, EUR: 89.6, symbol: '₹' },
  Philippines: { USD: 56.2, EUR: 61.4, symbol: '₱' },
  Canada: { USD: 1.36, EUR: 1.47, symbol: 'C$' },
  USA: { USD: 1.0, EUR: 1.08, symbol: '$' },
};

export default function MagHomepageCalculator() {
  const [amount, setAmount] = useState(1000);
  const [currency, setCurrency] = useState('USD');
  const [country, setCountry] = useState('Philippines');
  const [sortBy, setSortBy] = useState('best');

  const rankedProviders = useMemo(() => {
    const safeAmount = Math.max(100, Number(amount) || 1000);
    const rateInfo = countryRates[country] || countryRates.Philippines;

    const results = providerConfigs.map((provider) => {
      const fee = safeAmount * provider.feePct[currency] + provider.fixedFee[currency];
      const exchangeRate = rateInfo[currency] - provider.ratePenalty;
      const received = Math.max((safeAmount - fee) * exchangeRate, 0);
      const valueScore = received - fee * 0.35;
      return {
        ...provider,
        fee,
        exchangeRate,
        received,
        valueScore,
      };
    });

    const sorted = [...results].sort((a, b) => {
      if (sortBy === 'cheapest') return a.fee - b.fee;
      if (sortBy === 'fastest') return a.speed.localeCompare(b.speed);
      return b.valueScore - a.valueScore;
    });

    return sorted.map((provider, index) => ({ ...provider, rank: index + 1, symbol: rateInfo.symbol }));
  }, [amount, country, currency, sortBy]);

  const best = rankedProviders[0];
  const cheapest = [...rankedProviders].sort((a, b) => a.fee - b.fee)[0];
  const fastest = [...rankedProviders].sort((a, b) => a.speed.localeCompare(b.speed))[0];
  const avgFee = rankedProviders.reduce((sum, item) => sum + item.fee, 0) / rankedProviders.length;

  return (
    <section id="calculator" className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-8">
      <div className="mx-auto max-w-3xl text-center">
        <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#16a34a]">Transfer calculator</p>
        <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-slate-950 sm:text-4xl">Compare transfer options instantly</h2>
        <p className="mt-3 text-base leading-8 text-slate-500">Lightweight calculator with client-side logic only, designed for fast comparisons and low-RAM WordPress environments.</p>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-4">
        <label className="block text-sm font-medium text-slate-700">
          Amount
          <input type="number" min="100" value={amount} onChange={(e) => setAmount(e.target.value)} className="mt-2 h-12 w-full rounded-xl border border-slate-200 px-4" />
        </label>
        <label className="block text-sm font-medium text-slate-700">
          Currency
          <select value={currency} onChange={(e) => setCurrency(e.target.value)} className="mt-2 h-12 w-full rounded-xl border border-slate-200 px-4">
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
          </select>
        </label>
        <label className="block text-sm font-medium text-slate-700">
          Destination
          <select value={country} onChange={(e) => setCountry(e.target.value)} className="mt-2 h-12 w-full rounded-xl border border-slate-200 px-4">
            {Object.keys(countryRates).map((item) => (
              <option key={item} value={item}>{item}</option>
            ))}
          </select>
        </label>
        <label className="block text-sm font-medium text-slate-700">
          Sort by
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="mt-2 h-12 w-full rounded-xl border border-slate-200 px-4">
            <option value="best">Best value</option>
            <option value="cheapest">Cheapest</option>
            <option value="fastest">Fastest</option>
          </select>
        </label>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="rounded-[26px] border border-[#bbf7d0] bg-[linear-gradient(180deg,#f0fdf4_0%,#ffffff_100%)] p-6 shadow-[0_18px_40px_rgba(22,163,74,0.10)]">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-[#16a34a] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-white">Best Value</span>
            <span className="rounded-full bg-[#dcfce7] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#166534]">Updated regularly</span>
          </div>
          <p className="mt-4 text-sm font-semibold uppercase tracking-[0.18em] text-[#166534]">Best option</p>
          <h3 className="mt-2 text-4xl font-extrabold tracking-tight text-slate-950">{best.name}</h3>
          <p className="mt-3 text-sm leading-7 text-slate-600">{best.badge} for {currency} → {country} transfers right now.</p>
          <div className="mt-5 rounded-[22px] bg-white p-5">
            <span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">You receive</span>
            <strong className="mt-2 block text-4xl font-extrabold text-[#16a34a]">{best.symbol}{best.received.toLocaleString(undefined, { maximumFractionDigits: 0 })}</strong>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-center"><span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">Fees</span><strong className="mt-2 block text-2xl font-bold text-slate-950">{currency} {best.fee.toFixed(2)}</strong></div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-center"><span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">Rate</span><strong className="mt-2 block text-2xl font-bold text-slate-950">{best.exchangeRate.toFixed(2)}</strong></div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-center"><span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">Speed</span><strong className="mt-2 block text-2xl font-bold text-slate-950">{best.speed}</strong></div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-center"><span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">Save vs avg</span><strong className="mt-2 block text-2xl font-bold text-slate-950">{currency} {Math.max(0, avgFee - best.fee).toFixed(2)}</strong></div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-center"><span className="text-[11px] uppercase tracking-[0.14em] text-slate-500">Trust</span><strong className="mt-2 block text-lg font-bold text-slate-950">Independent</strong></div>
          </div>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <a href={best.href} rel="nofollow sponsored" target="_blank" className="inline-flex h-12 items-center justify-center rounded-full bg-[#16a34a] px-6 text-sm font-semibold text-white shadow-[0_14px_32px_rgba(22,163,74,0.24)] transition hover:bg-[#166534]">Get Best Rate</a>
            <a href="#compare" className="inline-flex h-12 items-center justify-center rounded-full border border-slate-200 px-6 text-sm font-semibold text-slate-950 transition hover:bg-slate-50">Compare Now</a>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-1">
          <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Cheapest</p><strong className="mt-2 block text-2xl font-bold text-slate-950">{cheapest.name}</strong></div>
          <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Fastest</p><strong className="mt-2 block text-2xl font-bold text-slate-950">{fastest.name}</strong></div>
          <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Best value</p><strong className="mt-2 block text-2xl font-bold text-slate-950">{best.name}</strong></div>
        </div>
      </div>
    </section>
  );
}