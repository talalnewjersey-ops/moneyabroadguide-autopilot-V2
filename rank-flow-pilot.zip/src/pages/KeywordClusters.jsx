import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function KeywordClusters() {
  const [name, setName] = useState('');
  const [keyword, setKeyword] = useState('');
  const queryClient = useQueryClient();
  const { data: projects = [] } = useQuery({ queryKey: ['projects'], queryFn: () => base44.entities.Project.list('-created_date', 1) });
  const { data: clusters = [] } = useQuery({ queryKey: ['keyword-clusters'], queryFn: () => base44.entities.KeywordCluster.list('-created_date', 100) });

  const createCluster = async () => {
    if (!projects[0] || !name || !keyword) return;
    await base44.entities.KeywordCluster.create({ project_id: projects[0].id, name, primary_keyword: keyword, secondary_keywords: [], intent: 'informational', priority: 'high' });
    setName('');
    setKeyword('');
    queryClient.invalidateQueries({ queryKey: ['keyword-clusters'] });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Keyword Clusters" description="Group keywords into pillar pages, supporting content, and internal-linking maps." />
      <div className="grid md:grid-cols-3 gap-3"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Cluster name" className="rounded-xl" /><Input value={keyword} onChange={(e) => setKeyword(e.target.value)} placeholder="Primary keyword" className="rounded-xl" /><Button onClick={createCluster} className="rounded-xl bg-blue-600 hover:bg-blue-700">Create Cluster</Button></div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{clusters.map((cluster) => <Card key={cluster.id}><CardContent className="p-5"><h3 className="font-semibold text-gray-900">{cluster.name}</h3><p className="text-sm text-gray-500 mt-1">{cluster.primary_keyword}</p><p className="text-xs text-gray-400 mt-2">Intent: {cluster.intent}</p></CardContent></Card>)}</div>
    </div>
  );
}