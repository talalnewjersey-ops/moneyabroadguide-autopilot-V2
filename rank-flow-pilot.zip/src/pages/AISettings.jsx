import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import PageHeader from '../components/common/PageHeader';

export default function AISettings() {
  const queryClient = useQueryClient();
  const { data: projects = [] } = useQuery({ queryKey: ['projects'], queryFn: () => base44.entities.Project.list('-created_date', 1) });
  const project = projects[0];
  const [model, setModel] = useState('gpt-4o-mini');
  const [temperature, setTemperature] = useState('0.7');
  const [maxTokens, setMaxTokens] = useState('4000');

  useEffect(() => {
    if (project) {
      setModel(project.ai_model || 'gpt-4o-mini');
      setTemperature(String(project.ai_temperature ?? 0.7));
      setMaxTokens(String(project.ai_max_tokens ?? 4000));
    }
  }, [project]);

  const save = async () => {
    if (!project) return;
    await base44.entities.Project.update(project.id, { ai_model: model, ai_temperature: Number(temperature), ai_max_tokens: Number(maxTokens) });
    queryClient.invalidateQueries({ queryKey: ['projects'] });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <PageHeader title="AI Settings" description="Set model, temperature, and generation limits for project-level AI workflows." />
      <div className="grid md:grid-cols-3 gap-3"><Input value={model} onChange={(e) => setModel(e.target.value)} placeholder="Model" className="rounded-xl" /><Input value={temperature} onChange={(e) => setTemperature(e.target.value)} placeholder="Temperature" className="rounded-xl" /><Input value={maxTokens} onChange={(e) => setMaxTokens(e.target.value)} placeholder="Max tokens" className="rounded-xl" /></div>
      <Button onClick={save} className="rounded-xl bg-blue-600 hover:bg-blue-700">Save AI Settings</Button>
    </div>
  );
}