import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import SectionHeading from '@/components/home/SectionHeading';
import HomeSideAds from '@/components/home/HomeSideAds';

const newcomerArticles = [
  {
    id: 'usa-newcomers',
    title: 'Newcomers to the USA',
    excerpt: 'Educational explanations of U.S. financial concepts, including banking basics, saving, and everyday money terminology.',
    link: 'https://moneyabroadguide.com/newcomers-to-the-usa/',
    category: 'USA',
  },
  {
    id: 'canada-newcomers',
    title: 'Newcomers to Canada',
    excerpt: 'Educational information to help readers understand Canadian banking systems, savings basics, and financial fundamentals.',
    link: 'https://moneyabroadguide.com/newcomers-to-canada/',
    category: 'Canada',
  },
  {
    id: 'start-here-newcomers',
    title: 'Start Here for Newcomers',
    excerpt: 'A simple starting point for immigrants learning how financial systems work in the USA and Canada.',
    link: 'https://moneyabroadguide.com/start-here/',
    category: 'Start here',
  }
];

export default function HomeBlogPreview() {
  return (
    <section id="blog" className="bg-white">
      <div className="mx-auto max-w-[1400px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
        <div className="grid gap-6 xl:grid-cols-[220px_minmax(0,1fr)_220px]">
          <HomeSideAds />

          <div>
            <div className="mx-auto max-w-[920px]">
              <SectionHeading
                eyebrow="Authority content"
                title="Guides designed to build trust before users compare fees"
                description="Educational content for newcomers helps establish authority, improve conversion quality, and move visitors naturally toward the calculator."
              />
            </div>

            <div className="mx-auto grid max-w-[920px] grid-cols-1 gap-6 md:grid-cols-3">
              {newcomerArticles.map((post) => (
                <Card key={post.id} className="fintech-card fintech-card-hover h-full overflow-hidden rounded-[28px] border-0">
                  <div className="flex h-full flex-col text-center">
                    <div className="flex justify-center px-7 pt-7">
                      <div className="inline-flex rounded-full bg-[#EAF7F1] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#1F8F6A]">
                        {post.category}
                      </div>
                    </div>
                    <CardContent className="flex flex-1 flex-col items-center px-7 pb-7 pt-5">
                      <h3 className="text-xl font-bold leading-tight text-slate-950">{post.title}</h3>
                      <p className="mt-3 flex-1 text-sm leading-7 text-slate-500">{post.excerpt}</p>
                      <a href={post.link} target="_blank" rel="noreferrer" className="mt-6 inline-flex w-fit items-center gap-2 rounded-full border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:border-slate-300 hover:bg-slate-50">
                        Read Full Guide <ArrowRight className="h-4 w-4" />
                      </a>
                    </CardContent>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <HomeSideAds />
        </div>
      </div>
    </section>
  );
}