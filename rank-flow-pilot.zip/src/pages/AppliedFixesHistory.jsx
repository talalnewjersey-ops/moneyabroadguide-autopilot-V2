import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import PageHeader from '../components/common/PageHeader';

export default function AppliedFixesHistory() {
  const queryClient = useQueryClient();
  const { data: items = [] } = useQuery({
    queryKey: ['applied-fixes-history'],
    queryFn: () => base44.entities.AppliedFix.list('-created_date', 100)
  });

  const rollback = async (fixId) => {
    await base44.functions.invoke('rollbackAppliedFix', { fix_id: fixId });
    queryClient.invalidateQueries({ queryKey: ['applied-fixes-history'] });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Applied Fixes History" description="Review generated changes, rollback references, and every automatic action taken." />
      <div className="space-y-2">
        {items.map((item) => (
          <div key={item.id} className="bg-white rounded-2xl border border-gray-100 p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-sm font-medium text-gray-900">{item.action_type}</p>
                <p className="text-sm text-gray-600 mt-1">{item.page_url || 'Sitewide change'}</p>
                <p className="text-xs text-gray-400 mt-2">
                  Rollback: {item.rollback_possible ? 'available' : 'not available'} · Status: {item.status}
                </p>
              </div>
              {item.rollback_possible && item.status !== 'rolled_back' && (
                <Button size="sm" variant="outline" className="rounded-lg" onClick={() => rollback(item.id)}>
                  Rollback
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}