import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import HomeHeader from '@/components/home/HomeHeader';
import HomeFooter from '@/components/home/HomeFooter';
import StickyCompareBar from '@/components/home/StickyCompareBar';
import SectionReveal from '@/components/home/SectionReveal';
import MoneyTransferCalculator from '@/components/home/MoneyTransferCalculator';
import TransferComparisonTable from '@/components/home/TransferComparisonTable';
import SeoFaq from '@/components/seo/SeoFaq';
import { buildArticleSections, getSeoArticle } from '@/lib/seoArticles';

export default function SeoArticlePage() {
  const { slug } = useParams();
  const article = getSeoArticle(slug);
  const sections = buildArticleSections(article);

  useEffect(() => {
    if (!article) return;
    document.title = `${article.seoTitle} | MoneyAbroadGuide`;
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'description';
      document.head.appendChild(meta);
    }
    meta.content = article.metaDescription;
  }, [article]);

  if (!article) {
    return <div className="min-h-screen bg-[#F8FAFC]"><HomeHeader /><div className="mx-auto max-w-[1200px] px-4 py-20">Article not found.</div><HomeFooter /></div>;
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-950">
      <HomeHeader />

      <section className="hero border-b border-slate-200">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-20">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3 text-sm text-slate-500">
              <Link to="/HomePage" className="hover:text-slate-950">Home</Link>
              <span>•</span>
              <Link to="/SeoHub" className="hover:text-slate-950">SEO Hub</Link>
              <span>•</span>
              <span>{article.slug}</span>
            </div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">Ready-to-publish SEO page</p>
            <h1 className="max-w-4xl text-4xl font-extrabold tracking-tight sm:text-5xl">{article.h1}</h1>
            <p className="max-w-3xl text-lg leading-8 text-slate-500">{article.intro}</p>
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <div className="fintech-card p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">SEO Title</p>
              <p className="mt-2 text-base font-semibold text-slate-950">{article.seoTitle}</p>
            </div>
            <div className="fintech-card p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Meta Description</p>
              <p className="mt-2 text-base leading-7 text-slate-600">{article.metaDescription}</p>
            </div>
            <div className="fintech-card p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">URL Slug</p>
              <p className="mt-2 text-base font-semibold text-slate-950">/guides/{article.slug}</p>
            </div>
          </div>
        </SectionReveal>
      </section>

      <section className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
        <MoneyTransferCalculator initialFromCountry={article.fromCountry} initialToCountry={article.toCountry} />
      </section>

      <section className="mx-auto max-w-[1200px] px-4 py-4 sm:px-6 lg:px-8 lg:py-8">
        <SectionReveal className="space-y-6">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">Provider comparison</p>
          <h2 className="text-3xl font-semibold">Compare leading providers before you choose</h2>
          <p className="max-w-3xl text-base leading-8 text-slate-500">This comparison block supports the article with commercial-intent data, affiliate CTAs, and a fast path to the calculator.</p>
          <TransferComparisonTable />
        </SectionReveal>
      </section>

      <section className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_320px]">
          <div className="space-y-10">
            {sections.map((section) => (
              <SectionReveal key={section.heading} className="space-y-4">
                <h2 className="text-3xl font-semibold tracking-tight text-slate-950">{section.heading}</h2>
                {section.paragraphs.map((paragraph, index) => (
                  <p key={index} className="text-base leading-8 text-slate-600">{paragraph}</p>
                ))}
              </SectionReveal>
            ))}
          </div>

          <div className="space-y-6">
            <SectionReveal className="fintech-card p-6">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">Internal links</p>
              <div className="mt-4 space-y-3">
                {article.internalLinks.map((item) => (
                  <Link key={item.href} to={item.href} className="block rounded-2xl bg-slate-50 px-4 py-3 text-sm font-medium text-slate-900 transition hover:bg-slate-100">
                    {item.label}
                  </Link>
                ))}
              </div>
            </SectionReveal>

            <SectionReveal className="rounded-[24px] bg-[#0B1F3A] p-6 text-white">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-white/70">CTA</p>
              <h3 className="mt-3 text-2xl font-semibold">Find the best provider for your transfer</h3>
              <p className="mt-3 text-base leading-8 text-white/80">Use the calculator to rank providers by total cost, speed, and rating before clicking through.</p>
              <a href="#calculator" className="mt-6 inline-flex rounded-full bg-white px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-slate-100">Send Money Now</a>
            </SectionReveal>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1200px] px-4 pb-20 sm:px-6 lg:px-8">
        <SectionReveal className="space-y-6">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">FAQ</p>
          <h2 className="text-3xl font-semibold">Frequently asked questions</h2>
          <SeoFaq items={article.faq} />
        </SectionReveal>
      </section>

      <HomeFooter />
      <StickyCompareBar />
    </div>
  );
}