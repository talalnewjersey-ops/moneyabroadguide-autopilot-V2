import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Globe, FileCode, Server, ExternalLink, Shield, Download } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import CodeCard from '../components/wordpress/CodeCard';

const pluginMainFile = String.raw`<?php
/**
 * Plugin Name: AI SEO Autopilot
 * Description: Original AI SEO autopilot for audits, fixes, content improvements, and WordPress automation.
 * Version: 1.9.0
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) exit;

class SEOAutopilotAIConnector {
    private $option_name = 'seo_autopilot_ai_settings';
    private $cron_hook = 'seo_autopilot_ai_daily_automation';
    private $app_base_url = '';

    public function __construct() {
        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_seo_autopilot_optimize_site', [$this, 'ajax_optimize_site']);
        add_action('rest_api_init', [$this, 'register_rest_routes']);
        add_action('init', [$this, 'sync_automation_schedule']);
        add_action('init', [$this, 'ensure_editorial_policy_page']);
        add_action('init', [$this, 'ensure_support_pages']);
        add_action('wp_head', [$this, 'output_frontend_seo_assets']);
        add_filter('the_content', [$this, 'normalize_heading_hierarchy'], 8);
        add_filter('the_content', [$this, 'append_author_box']);
        add_filter('the_content', [$this, 'prepend_homepage_h1']);
        add_filter('the_content', [$this, 'remove_empty_social_links']);
        add_filter('pre_get_document_title', [$this, 'override_document_title']);
        add_action($this->cron_hook, [$this, 'run_scheduled_automation']);
    }

    public function enqueue_assets() {
        wp_enqueue_style('seo-autopilot-admin', plugins_url('admin.css', __FILE__), [], '1.9.3');
    }

    public function register_menu() {
        add_menu_page('AI SEO Autopilot', 'AI SEO Autopilot', 'manage_options', 'ai-seo-autopilot', [$this, 'render_dashboard'], 'dashicons-chart-area', 56);
        add_submenu_page('ai-seo-autopilot', 'Dashboard', 'Dashboard', 'manage_options', 'ai-seo-autopilot', [$this, 'render_dashboard']);
        add_submenu_page('ai-seo-autopilot', 'Site Audit', 'Site Audit', 'manage_options', 'ai-seo-autopilot-audit', [$this, 'render_audit']);
        add_submenu_page('ai-seo-autopilot', 'Content Optimizer', 'Content Optimizer', 'manage_options', 'ai-seo-autopilot-content', [$this, 'render_content']);
        add_submenu_page('ai-seo-autopilot', 'Keyword Opportunities', 'Keyword Opportunities', 'manage_options', 'ai-seo-autopilot-keywords', [$this, 'render_keywords']);
        add_submenu_page('ai-seo-autopilot', 'Backlink Opportunities', 'Backlink Opportunities', 'manage_options', 'ai-seo-autopilot-backlinks', [$this, 'render_backlinks']);
        add_submenu_page('ai-seo-autopilot', 'E-E-A-T Optimization', 'E-E-A-T Optimization', 'manage_options', 'ai-seo-autopilot-eeat', [$this, 'render_eeat']);
        add_submenu_page('ai-seo-autopilot', 'Automations', 'Automations', 'manage_options', 'ai-seo-autopilot-automations', [$this, 'render_automations']);
        add_submenu_page('ai-seo-autopilot', 'Reports', 'Reports', 'manage_options', 'ai-seo-autopilot-reports', [$this, 'render_reports']);
        add_submenu_page('ai-seo-autopilot', 'Applied History', 'Applied History', 'manage_options', 'ai-seo-autopilot-history', [$this, 'render_history']);
        add_submenu_page('ai-seo-autopilot', 'Settings', 'Settings', 'manage_options', 'ai-seo-autopilot-settings', [$this, 'render_settings']);
    }

    public function register_settings() {
        register_setting($this->option_name, $this->option_name, [$this, 'sanitize_settings']);
    }

    private function endpoint_defaults($base_url = null) {
        $base = rtrim($base_url ?: $this->app_base_url, '/');
        return [
            'connect_url' => $base ? $base . '/functions/connectSite' : '',
            'site_audit_url' => $base ? $base . '/functions/siteAudit' : '',
            'optimize_site_url' => $base ? $base . '/functions/optimizeSite' : '',
            'optimize_page_url' => $base ? $base . '/functions/optimizePage' : '',
            'keyword_url' => $base ? $base . '/functions/keywordOpportunities' : '',
            'content_url' => $base ? $base . '/functions/contentRecommendations' : '',
        ];
    }

    public function sanitize_settings($input) {
        $defaults = $this->endpoint_defaults();
        $defaults = $this->endpoint_defaults();
        $base_url = esc_url_raw($input['app_base_url'] ?? $this->app_base_url);
        $defaults = $this->endpoint_defaults($base_url);
        return [
            'site_url' => esc_url_raw($input['site_url'] ?? home_url('/')),
            'api_key' => sanitize_text_field($input['api_key'] ?? ''),
            'app_base_url' => $base_url,
            'connect_url' => esc_url_raw($input['connect_url'] ?? $defaults['connect_url']),
            'site_audit_url' => esc_url_raw($input['site_audit_url'] ?? $defaults['site_audit_url']),
            'optimize_site_url' => esc_url_raw($input['optimize_site_url'] ?? $defaults['optimize_site_url']),
            'optimize_page_url' => esc_url_raw($input['optimize_page_url'] ?? $defaults['optimize_page_url']),
            'keyword_url' => esc_url_raw($input['keyword_url'] ?? $defaults['keyword_url']),
            'content_url' => esc_url_raw($input['content_url'] ?? $defaults['content_url']),
            'mode' => in_array(($input['mode'] ?? 'assisted'), ['manual', 'assisted', 'auto'], true) ? $input['mode'] : 'assisted',
        ];
    }

    private function settings() {
        $defaults = array_merge([
            'site_url' => home_url('/'),
            'api_key' => '',
            'app_base_url' => '',
            'mode' => 'assisted',
        ], $this->endpoint_defaults(''));

        return wp_parse_args(get_option($this->option_name, []), $defaults);

        return $settings;
    }

    private function store_result($key, $value) {
        update_option($key, is_array($value) ? $value : [], false);
    }

    private function get_result($key) {
        $value = get_option($key, []);
        return is_array($value) ? $value : [];
    }

    private function render_text($value) {
        if (is_array($value)) {
            $flattened = [];
            array_walk_recursive($value, function ($item) use (&$flattened) {
                if (is_scalar($item) && $item !== '') $flattened[] = $item;
            });
            return esc_html(implode(' • ', array_slice($flattened, 0, 12)));
        }
        return esc_html((string) $value);
    }

    private function render_list_items($items) {
        $output = [];
        foreach (($items ?? []) as $item) {
            if (is_array($item)) {
                $flattened = [];
                array_walk_recursive($item, function ($value) use (&$flattened) {
                    if (is_scalar($value) && $value !== '') $flattened[] = $value;
                });
                $text = implode(' • ', array_slice($flattened, 0, 10));
            } else {
                $text = (string) $item;
            }
            if (!empty($text)) $output[] = $text;
        }
        return $output;
    }

    private function friendly_error($message) {
        $message = (string) $message;
        if (stripos($message, 'private') !== false || stripos($message, 'auth_required') !== false || stripos($message, 'do not have access') !== false) {
            return 'This plugin is still pointing to a private preview URL. Open Base44 → Code → Functions and paste the live function URLs into the plugin Settings screen.';
        }
        return $message;
    }

    private function append_fix_history_entries($entries) {
        $history = get_option('seo_autopilot_ai_fix_history', []);
        $history = is_array($history) ? $history : [];
        foreach (($entries ?? []) as $entry) {
            $history[] = $entry;
        }
        update_option('seo_autopilot_ai_fix_history', array_slice($history, -200), false);
    }

    private function run_endpoint_job($endpoint_key, $option_key) {
        $settings = $this->settings();

        if (empty($settings[$endpoint_key])) {
            return ['success' => false, 'message' => 'Endpoint URL is missing.'];
        }

        if (empty($settings['api_key'])) {
            return ['success' => false, 'message' => 'API Key is missing.'];
        }

        $result = $this->call_endpoint($settings[$endpoint_key], $this->collect_site_payload());

        if (empty($result['success'])) {
            if (empty($result['message']) && !empty($result['error'])) {
                $result['message'] = $result['error'];
            }
            $result['message'] = $this->friendly_error($result['message'] ?? 'Request failed');
            return $result ?: ['success' => false, 'message' => 'Request failed'];
        }

        $this->store_result($option_key, $result);
        return $result;
    }

    private function collect_site_payload() {
        $posts = get_posts([
            'post_type' => ['post', 'page'],
            'post_status' => 'publish',
            'numberposts' => 50,
        ]);

        $items = [];
        foreach ($posts as $post) {
            $content = wp_strip_all_tags($post->post_content);
            preg_match('/<h1[^>]*>(.*?)<\/h1>/is', $post->post_content, $h1_match);
            preg_match_all('/<a[^>]+href=["\']([^"\']+)["\']/i', $post->post_content, $links_match);

            $images = get_attached_media('image', $post->ID);
            $image_data = [];
            foreach ($images as $image) {
                $image_data[] = [
                    'url' => wp_get_attachment_url($image->ID),
                    'alt_text' => get_post_meta($image->ID, '_wp_attachment_image_alt', true),
                ];
            }

            $items[] = [
                'id' => $post->ID,
                'type' => $post->post_type,
                'title' => get_the_title($post->ID),
                'url' => get_permalink($post->ID),
                'slug' => $post->post_name,
                'publication_date' => get_the_date('c', $post->ID),
                'modified_date' => get_the_modified_date('c', $post->ID),
                'meta_description' => get_post_meta($post->ID, '_yoast_wpseo_metadesc', true),
                'h1' => $h1_match[1] ?? '',
                'content' => mb_substr($content, 0, 6000),
                'internal_links' => array_values(array_filter($links_match[1] ?? [])),
                'images' => $image_data,
                'categories' => wp_get_post_terms($post->ID, 'category', ['fields' => 'names']),
                'tags' => wp_get_post_terms($post->ID, 'post_tag', ['fields' => 'names']),
            ];
        }

        return [
            'site_url' => home_url('/'),
            'site_name' => get_bloginfo('name'),
            'api_key' => $this->settings()['api_key'],
            'mode' => $this->settings()['mode'],
            'niche' => 'expat finance',
            'language' => 'English',
            'country' => 'USA and Canada',
            'pages' => $items,
        ];
    }

    private function call_endpoint($url, $payload) {
        $response = wp_remote_post($url, [
            'timeout' => 60,
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($payload),
        ]);

        if (is_wp_error($response)) {
            return ['success' => false, 'message' => $response->get_error_message()];
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        return is_array($data) ? $data : ['success' => false, 'message' => 'Invalid response from endpoint.'];
    }

    public function register_rest_routes() {
        register_rest_route('ai-seo-autopilot/v1', '/push-draft', [
            'methods' => 'POST',
            'callback' => [$this, 'push_draft_to_wordpress'],
            'permission_callback' => '__return_true'
        ]);
    }

    public function push_draft_to_wordpress($request) {
        $settings = $this->settings();
        $provided_key = sanitize_text_field($request->get_header('x-ai-seo-autopilot-key'));
        if (empty($settings['api_key']) || $provided_key !== $settings['api_key']) {
            return new WP_REST_Response(['error' => 'Invalid API key.'], 403);
        }

        $payload = $request->get_json_params();
        $post_id = wp_insert_post([
            'post_title' => sanitize_text_field($payload['title'] ?? 'AI SEO Draft'),
            'post_name' => sanitize_title($payload['slug'] ?? ''),
            'post_excerpt' => sanitize_textarea_field($payload['excerpt'] ?? ''),
            'post_content' => wp_kses_post(($payload['content'] ?? '') . "\n\n" . ($payload['faq_html'] ?? '') . "\n\n" . ($payload['schema_markup'] ?? '')),
            'post_status' => 'draft',
            'post_type' => 'post'
        ], true);

        if (is_wp_error($post_id)) {
            return new WP_REST_Response(['error' => $post_id->get_error_message()], 500);
        }

        if (!empty($payload['meta_title'])) {
            update_post_meta($post_id, '_yoast_wpseo_title', sanitize_text_field($payload['meta_title']));
        }
        if (!empty($payload['meta_description'])) {
            update_post_meta($post_id, '_yoast_wpseo_metadesc', sanitize_text_field($payload['meta_description']));
        }

        return new WP_REST_Response(['success' => true, 'post_id' => $post_id, 'edit_url' => admin_url('post.php?post=' . $post_id . '&action=edit')], 200);
    }

    private function format_datetime($value) {
        if (empty($value)) return 'Not available';
        $timestamp = is_numeric($value) ? intval($value) : strtotime($value);
        if (!$timestamp) return 'Not available';
        return wp_date(get_option('date_format') . ' ' . get_option('time_format'), $timestamp);
    }

    private function current_sitewide_fixes() {
        $value = get_option('seo_autopilot_ai_sitewide_fixes', []);
        return is_array($value) ? $value : [];
    }

    private function author_bio_html() {
        return '<div class="seo-autopilot-author-box"><h3>About the author</h3><p><strong>Talal Eddaouahiri</strong> is a financial specialist focused on helping expatriates understand financial systems in North America. He is the founder of Money Abroad Guide, a platform that provides practical guides on banking, international money transfers, credit building, and financial tools for newcomers moving to the United States and Canada. Through independent research and detailed comparisons, he helps expats make smarter financial decisions and avoid costly banking fees when living abroad.</p></div>';
    }

    private function editorial_policy_html() {
        return '<h1>Editorial Policy</h1><p>At Money Abroad Guide, our mission is to provide reliable, practical, and easy-to-understand financial information for expatriates, immigrants, and newcomers moving to the United States and Canada.</p><h2>Our Content Principles</h2><p>All content published on Money Abroad Guide follows three key principles:</p><h3>Accuracy</h3><p>We aim to provide accurate and up-to-date financial information by researching banking services, financial applications, and money transfer platforms available in North America.</p><h3>Independence</h3><p>Our content is based on independent research and analysis. Comparisons and recommendations are made based on factors such as:</p><ul><li>Fees</li><li>Accessibility for newcomers</li><li>Features and usability</li><li>Financial transparency</li></ul><h3>Practical Value</h3><p>Our goal is to provide practical guides that help expatriates:</p><ul><li>Open bank accounts</li><li>Understand credit systems</li><li>Reduce international transfer costs</li><li>Choose the best financial apps for their needs</li></ul><h2>Content Creation Process</h2><p>Articles on Money Abroad Guide are written and reviewed by financial researcher Talal Eddaouahiri, who focuses on financial services for expatriates in North America.</p><p>Each article is designed to provide clear explanations and actionable advice to help readers make informed financial decisions.</p><h2>Transparency</h2><p>Some articles may contain references to financial products or services. Our goal is always to provide transparent information and highlight both advantages and potential limitations of financial services.</p>';
    }

    private function team_page_html() {
        return '<h1>Team</h1><p><strong>Talal Eddaouahiri</strong> leads Money Abroad Guide and focuses on personal finance education for expats, immigrants, newcomers, and international students in North America.</p><p>Our editorial approach is practical, beginner-friendly, and designed to help readers make confident money decisions in the USA and Canada.</p>';
    }

    private function disclaimer_page_html() {
        return '<h1>Disclaimer</h1><p>Money Abroad Guide provides educational information only and does not offer financial, legal, tax, or investment advice.</p><p>Readers should consult qualified professionals before making important financial decisions.</p>';
    }

    private function about_page_html() {
        return '<h1>About Money Abroad Guide</h1><p>Money Abroad Guide helps expats, immigrants, newcomers, and international students understand banking, credit, budgeting, taxes, and day-to-day money decisions in the USA and Canada.</p><p><strong>Talal Eddaouahiri</strong> leads the editorial direction of the site with a practical, research-based approach focused on financial education for newcomers.</p>';
    }

    private function home_page_html() {
        return '<h1>Money Abroad Guide: Finance for Expats in the USA & Canada</h1><p>Welcome to Money Abroad Guide, your educational resource for banking, credit, taxes, budgeting, and money management in North America.</p>';
    }

    public function append_author_box($content) {
        if (is_admin() || !is_singular('post') || !in_the_loop() || !is_main_query()) {
            return $content;
        }

        if (strpos($content, 'seo-autopilot-author-box') !== false) {
            return $content;
        }

        return $content . $this->author_bio_html();
    }

    public function prepend_homepage_h1($content) {
        if (is_admin() || !(is_front_page() || is_home()) || !in_the_loop() || !is_main_query()) {
            return $content;
        }
        $fixes = $this->current_sitewide_fixes();
        $homepage_h1 = sanitize_text_field($fixes['homepage_h1'] ?? 'Money Abroad Guide: Finance for Expats in the USA & Canada');
        if (stripos($content, '<h1') !== false) {
            return $content;
        }
        return '<h1 class="seo-autopilot-homepage-h1">' . esc_html($homepage_h1) . '</h1>' . $content;
    }

    public function override_document_title($title) {
        if (is_admin() || !(is_front_page() || is_home())) {
            return $title;
        }
        $fixes = $this->current_sitewide_fixes();
        return !empty($fixes['og_title']) ? sanitize_text_field($fixes['og_title']) : 'Money Abroad Guide | Finance for Expats in USA & Canada';
    }

    public function output_frontend_seo_assets() {
        if (is_admin()) {
            return;
        }

        $fixes = $this->current_sitewide_fixes();
        echo '<style>.seo-autopilot-author-box{margin-top:32px;padding:20px;border:1px solid #e2e8f0;border-radius:16px;background:#f8fafc}.seo-autopilot-author-box h3{margin:0 0 10px;font-size:20px}.seo-autopilot-author-box p{margin:0;line-height:1.7;color:#334155}.seo-autopilot-homepage-h1{font-size:2rem;line-height:1.15;margin:0 0 16px;color:#0f172a}</style>';
        if (is_front_page() || is_home()) {
            $meta_description = !empty($fixes['og_description']) ? $fixes['og_description'] : 'Explore banking, credit, taxes, budgeting, and money management tips for expats in the USA and Canada.';
            $og_title = !empty($fixes['og_title']) ? $fixes['og_title'] : 'Money Abroad Guide | Finance for Expats in USA & Canada';
            $og_image = !empty($fixes['og_image_url']) ? $fixes['og_image_url'] : 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/f902e43fa_generated_image.png';
            echo '<meta name="description" content="' . esc_attr($meta_description) . '">';
            echo '<meta property="og:title" content="' . esc_attr($og_title) . '">';
            echo '<meta property="og:description" content="' . esc_attr($meta_description) . '">';
            echo '<meta property="og:image" content="' . esc_url($og_image) . '">';
            echo '<meta property="og:type" content="website">';
            echo '<meta property="og:url" content="' . esc_url(home_url('/')) . '">';
            echo "<script>document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll(\"a.elementor-social-icon:not([href]), a.elementor-social-icon[href=''], a.elementor-social-icon[href='#']\").forEach(function(el){el.remove();});});</script>";
        }
        echo '<script type="application/ld+json">' . wp_json_encode([
            '@context' => 'https://schema.org',
            '@type' => 'Person',
            'name' => 'Talal Eddaouahiri',
            'url' => 'https://moneyabroadguide.com/about',
            'jobTitle' => 'Financial Specialist for Expats',
            'worksFor' => [
                '@type' => 'Organization',
                'name' => 'Money Abroad Guide',
            ],
            'description' => 'Talal Eddaouahiri is a financial specialist helping expatriates navigate banking, credit systems, and international money transfers when moving to the United States and Canada.',
            'sameAs' => ['https://moneyabroadguide.com'],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
    }

    public function ensure_editorial_policy_page() {
        $content = $this->editorial_policy_html();
        $hash = md5($content);
        if (get_option('seo_autopilot_ai_editorial_policy_hash') === $hash) {
            return;
        }

        $page = get_page_by_path('editorial-policy');
        $page_data = [
            'post_title' => 'Editorial Policy – Money Abroad Guide',
            'post_name' => 'editorial-policy',
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_content' => $content,
        ];

        if ($page) {
            $page_data['ID'] = $page->ID;
            wp_update_post($page_data);
        } else {
            wp_insert_post($page_data);
        }

        update_option('seo_autopilot_ai_editorial_policy_hash', $hash, false);
    }

    public function ensure_support_pages() {
        $pages = [
            ['slug' => 'about', 'title' => 'About', 'content' => $this->about_page_html()],
            ['slug' => 'team', 'title' => 'Team', 'content' => $this->team_page_html()],
            ['slug' => 'disclaimer', 'title' => 'Disclaimer', 'content' => $this->disclaimer_page_html()],
            ['slug' => 'home', 'title' => 'Home', 'content' => $this->home_page_html()],
        ];

        foreach ($pages as $page_config) {
            $page = get_page_by_path($page_config['slug']);
            $data = [
                'post_title' => $page_config['title'],
                'post_name' => $page_config['slug'],
                'post_type' => 'page',
                'post_status' => 'publish',
                'post_content' => $page_config['content'],
            ];
            if ($page) {
                $data['ID'] = $page->ID;
                wp_update_post($data);
            } else {
                wp_insert_post($data);
            }
        }
    }

    public function remove_empty_social_links($content) {
        return preg_replace('/<a\b(?=[^>]*elementor-social-icon)(?![^>]*href=)[^>]*>.*?<\/a>/is', '', $content);
    }

    public function normalize_heading_hierarchy($content) {
        if (is_admin() || !is_string($content) || stripos($content, '<h') === false) {
            return $content;
        }

        $last_level = 1;
        $seen_h1 = false;
        return preg_replace_callback('/<h([1-6])(\b[^>]*)>(.*?)<\/h\1>/is', function ($matches) use (&$last_level, &$seen_h1) {
            $current_level = intval($matches[1]);
            $attributes = $matches[2];
            $inner = $matches[3];

            if (!$seen_h1 && $current_level === 1) {
                $seen_h1 = true;
                $last_level = 1;
                return $matches[0];
            }

            if (!$seen_h1 && $current_level > 1) {
                $current_level = 2;
                $last_level = 2;
                return '<h2' . $attributes . '>' . $inner . '</h2>';
            }

            $normalized_level = $current_level > ($last_level + 1) ? ($last_level + 1) : $current_level;
            if ($normalized_level < 2) $normalized_level = 2;
            $last_level = $normalized_level;
            return '<h' . $normalized_level . $attributes . '>' . $inner . '</h' . $normalized_level . '>';
        }, $content);
    }

    private function apply_content_recommendations($recommendations) {
        $applied = 0;
        $history_entries = [];

        foreach (($recommendations ?? []) as $recommendation) {
            $page_url = esc_url_raw($recommendation['page_url'] ?? '');
            $suggested_content = wp_kses_post($recommendation['suggested_content'] ?? '');
            $post_id = url_to_postid($page_url);
            if (!$post_id || !$suggested_content) continue;

            $post = get_post($post_id);
            if (!$post) continue;

            if (strpos($post->post_content, wp_strip_all_tags($suggested_content)) !== false) continue;

            wp_update_post([
                'ID' => $post_id,
                'post_content' => rtrim($post->post_content) . "\n\n" . $suggested_content,
            ]);
            $history_entries[] = [
                'page_url' => $page_url,
                'action_type' => 'content_refresh',
                'new_value' => wp_trim_words(wp_strip_all_tags($suggested_content), 20),
                'applied_at' => current_time('mysql')
            ];
            $applied++;
        }

        if (!empty($history_entries)) {
            $this->append_fix_history_entries($history_entries);
        }
        return $applied;
    }

    public function sync_automation_schedule() {
        $settings = $this->settings();
        $scheduled = wp_next_scheduled($this->cron_hook);
        $should_schedule = !empty($settings['api_key']) && !empty($settings['optimize_site_url']) && ($settings['mode'] ?? 'assisted') !== 'manual';

        if ($should_schedule && !$scheduled) {
            wp_schedule_event(time() + 300, 'daily', $this->cron_hook);
        }

        if (!$should_schedule && $scheduled) {
            wp_unschedule_event($scheduled, $this->cron_hook);
        }
    }

    private function apply_auto_fixes($result) {
        $applied = 0;
        $backups = [];
        $history_entries = [];

        foreach (($result['auto_fixes'] ?? []) as $fix) {
            $page_url = esc_url_raw($fix['page_url'] ?? '');
            $post_id = url_to_postid($page_url);
            if (!$post_id) continue;

            $backups[] = [
                'post_id' => $post_id,
                'title' => get_the_title($post_id),
                'meta_description' => get_post_meta($post_id, '_yoast_wpseo_metadesc', true),
            ];

            if (!empty($fix['optimized_title'])) {
                wp_update_post([
                    'ID' => $post_id,
                    'post_title' => sanitize_text_field($fix['optimized_title']),
                ]);
                $history_entries[] = [
                    'page_url' => $page_url,
                    'action_type' => 'title_update',
                    'new_value' => sanitize_text_field($fix['optimized_title']),
                    'applied_at' => current_time('mysql')
                ];
                $applied++;
            }

            if (!empty($fix['optimized_meta_description'])) {
                update_post_meta($post_id, '_yoast_wpseo_metadesc', sanitize_text_field($fix['optimized_meta_description']));
                $history_entries[] = [
                    'page_url' => $page_url,
                    'action_type' => 'meta_description_update',
                    'new_value' => sanitize_text_field($fix['optimized_meta_description']),
                    'applied_at' => current_time('mysql')
                ];
                $applied++;
            }

            foreach (($fix['image_alt_updates'] ?? []) as $image_fix) {
                $image_url = esc_url_raw($image_fix['image_url'] ?? '');
                $alt_text = sanitize_text_field($image_fix['alt_text'] ?? '');
                if (!$image_url || !$alt_text) continue;
                $attachment_id = attachment_url_to_postid($image_url);
                if (!$attachment_id) continue;
                update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt_text);
                $history_entries[] = [
                    'page_url' => $page_url,
                    'action_type' => 'image_alt_update',
                    'new_value' => $alt_text,
                    'applied_at' => current_time('mysql')
                ];
                $applied++;
            }
        }

        update_option('seo_autopilot_ai_last_backup', $backups, false);
        if (!empty($history_entries)) {
            $this->append_fix_history_entries($history_entries);
        }
        return $applied;
    }

    private function remember_automation_result($success, $message, $applied = 0) {
        update_option('seo_autopilot_ai_last_automation_result', [
            'success' => $success,
            'message' => sanitize_text_field($message),
            'applied_changes' => intval($applied),
            'ran_at' => current_time('mysql'),
        ], false);
    }

    private function run_optimization_job($force_apply = false) {
        $settings = $this->settings();

        if (empty($settings['optimize_site_url'])) {
            $result = ['success' => false, 'message' => 'Optimize Site Endpoint URL is missing.'];
            $this->remember_automation_result(false, $result['message']);
            return $result;
        }

        if (empty($settings['api_key'])) {
            $result = ['success' => false, 'message' => 'API Key is missing.'];
            $this->remember_automation_result(false, $result['message']);
            return $result;
        }

        $payload = $this->collect_site_payload();
        $mode = $settings['mode'] ?? 'assisted';
        $apply_safe_fixes = $force_apply || in_array($mode, ['assisted', 'auto'], true);
        $apply_content_blocks = $force_apply || $mode === 'auto';
        $total_applied = 0;

        if (!empty($settings['site_audit_url'])) {
            $audit_result = $this->call_endpoint($settings['site_audit_url'], $payload);
            if (!empty($audit_result['success'])) {
                $this->store_result('seo_autopilot_ai_last_site_audit', $audit_result);
            }
        }

        if (!empty($settings['content_url'])) {
            $content_result = $this->call_endpoint($settings['content_url'], $payload);
            if (!empty($content_result['success'])) {
                if ($apply_content_blocks) {
                    $total_applied += $this->apply_content_recommendations($content_result['recommendations'] ?? []);
                }
                $this->store_result('seo_autopilot_ai_last_content', $content_result);
            }
        }

        if (!empty($settings['keyword_url'])) {
            $keyword_result = $this->call_endpoint($settings['keyword_url'], $payload);
            if (!empty($keyword_result['success'])) {
                $this->store_result('seo_autopilot_ai_last_keywords', $keyword_result);
            }
        }

        $result = $this->call_endpoint($settings['optimize_site_url'], $payload);

        if (empty($result['success'])) {
            if (empty($result['message']) && !empty($result['error'])) {
                $result['message'] = $result['error'];
            }
            $this->remember_automation_result(false, $result['message'] ?? 'Optimization failed');
            return $result ?: ['success' => false, 'message' => 'Optimization failed'];
        }

        if ($apply_safe_fixes) {
            $total_applied += $this->apply_auto_fixes($result);
        }
        if (!empty($result['sitewide_fixes']) && is_array($result['sitewide_fixes'])) {
            update_option('seo_autopilot_ai_sitewide_fixes', $result['sitewide_fixes'], false);
            $this->append_fix_history_entries([[
                'page_url' => home_url('/'),
                'action_type' => 'homepage_seo_update',
                'new_value' => sanitize_text_field($result['sitewide_fixes']['homepage_h1'] ?? 'Homepage SEO update'),
                'applied_at' => current_time('mysql')
            ]]);
            $total_applied += 1;
        }

        $this->ensure_editorial_policy_page();
        $result['applied_changes'] = $total_applied;
        $result['author_box_enabled'] = true;
        $result['author_schema_enabled'] = true;
        $result['editorial_policy_enabled'] = true;
        $this->store_result('seo_autopilot_ai_last_optimize_result', $result);
        $this->remember_automation_result(true, $result['summary'] ?? 'Optimization completed', $total_applied);

        return $result;
    }

    public function run_scheduled_automation() {
        if (($this->settings()['mode'] ?? 'assisted') === 'manual') {
            return;
        }
        $this->run_optimization_job(true);
    }

    public function ajax_optimize_site() {
        check_ajax_referer('seo_autopilot_optimize_site', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized'], 403);
        }

        $result = $this->run_optimization_job(false);

        if (!empty($result['success'])) {
            wp_send_json_success($result);
        }

        wp_send_json_error($result ?: ['message' => 'Optimization failed'], 500);
    }

    public function render_dashboard() {
        $settings = $this->settings();
        $connect_result = [];
        $fix_all_result = [];
        $last_run = get_option('seo_autopilot_ai_last_automation_result', []);
        $next_run = wp_next_scheduled($this->cron_hook);

        if (!empty($_POST['seo_autopilot_connect']) && check_admin_referer('seo_autopilot_connect_action')) {
            $connect_result = $this->call_endpoint($settings['connect_url'], [
                'site_url' => home_url('/'),
                'site_name' => get_bloginfo('name'),
                'api_key' => $settings['api_key'],
                'mode' => $settings['mode'],
                'plugin_version' => '1.8.0',
                'rest_url' => rest_url(),
            ]);
        }

        if (!empty($_POST['seo_autopilot_fix_all']) && check_admin_referer('seo_autopilot_fix_all_action')) {
            $fix_all_result = $this->run_optimization_job(true);
        }

        echo '<div class="wrap seo-autopilot-wrap">';
        echo '<div class="seo-hero" style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;background:linear-gradient(135deg,#0f172a,#1e3a8a);border-radius:18px;padding:24px;color:#fff;margin-bottom:18px;"><div><h1 style="margin:0;color:#fff;font-size:30px;line-height:1.1;">AI SEO Autopilot</h1><p class="seo-hero-text" style="margin:8px 0 0;color:rgba(255,255,255,.82);max-width:680px;">A cleaner WordPress control panel for automated audits, fixes, EEAT assets, and content actions.</p></div><div class="seo-pill-row" style="display:flex;flex-wrap:wrap;gap:8px;"><span class="seo-pill" style="display:inline-block;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.16);color:#fff;border-radius:999px;padding:8px 12px;font-size:12px;white-space:nowrap;">Daily automation</span><span class="seo-pill" style="display:inline-block;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.16);color:#fff;border-radius:999px;padding:8px 12px;font-size:12px;white-space:nowrap;">Safe fixes</span><span class="seo-pill" style="display:inline-block;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.16);color:#fff;border-radius:999px;padding:8px 12px;font-size:12px;white-space:nowrap;">WordPress-ready</span></div></div>';
        echo '<div class="notice notice-info"><p>Connect your site once, then let WordPress run audit, content recommendations, keyword discovery, direct SEO corrections, author box injection, author schema, and the Editorial Policy page automatically.</p></div>';
        echo '<div class="notice notice-warning"><p><strong>Important:</strong> if buttons do not work, your plugin is likely still using a private preview URL. Open Base44 → Code → Functions and paste the live function URLs into Settings.</p></div>';

        if (!empty($connect_result['success'])) {
            echo '<div class="notice notice-success"><p>Connected successfully.</p></div>';
        } elseif (!empty($connect_result['message']) || !empty($connect_result['error'])) {
            echo '<div class="notice notice-error"><p>' . esc_html($connect_result['message'] ?? $connect_result['error']) . '</p></div>';
        }

        if (!empty($fix_all_result['success'])) {
            echo '<div class="notice notice-success"><p>All available fixes were generated and applied automatically.</p></div>';
        } elseif (!empty($fix_all_result['message']) || !empty($fix_all_result['error'])) {
            echo '<div class="notice notice-error"><p>' . esc_html($fix_all_result['message'] ?? $fix_all_result['error']) . '</p></div>';
        }

        echo '<form method="post" style="margin:16px 0 0;">';
        wp_nonce_field('seo_autopilot_fix_all_action');
        echo '<button class="button button-primary button-hero" name="seo_autopilot_fix_all" value="1">Fix all issues in one click</button>';
        echo '</form>';
        echo '<div class="seo-autopilot-grid">';
        echo '<div class="seo-card"><h2>Connection</h2><p><strong>Site:</strong> ' . esc_html(home_url('/')) . '</p><p><strong>Mode:</strong> ' . esc_html(ucfirst($settings['mode'])) . '</p><form method="post">';
        wp_nonce_field('seo_autopilot_connect_action');
        echo '<button class="button button-primary" name="seo_autopilot_connect" value="1">Connect Site</button></form></div>';

        echo '<div class="seo-card"><h2>Optimize</h2><p>Send your current content inventory to SEO Autopilot and receive safe SEO improvements.</p><button class="button button-primary" id="seo-autopilot-optimize">Optimize My Website</button><p id="seo-autopilot-status"></p></div>';

        echo '<div class="seo-card"><h2>Automation</h2><p><strong>Mode:</strong> ' . esc_html(ucfirst($settings['mode'] ?? 'assisted')) . '</p><p><strong>Next run:</strong> ' . esc_html($this->format_datetime($next_run)) . '</p><p><strong>Last run:</strong> ' . esc_html($this->format_datetime($last_run['ran_at'] ?? null)) . '</p><p><strong>Last applied changes:</strong> ' . esc_html((string) intval($last_run['applied_changes'] ?? 0)) . '</p></div>';
        echo '</div>';

        $last_optimize = $this->get_result('seo_autopilot_ai_last_optimize_result');
        $last_audit = $this->get_result('seo_autopilot_ai_last_site_audit');
        $last_content = $this->get_result('seo_autopilot_ai_last_content');
        $last_keywords = $this->get_result('seo_autopilot_ai_last_keywords');
        echo '<div class="seo-metrics"><div class="seo-metric"><span>Audit issues</span><strong>' . esc_html((string) count($last_audit['audit']['issues'] ?? [])) . '</strong></div><div class="seo-metric"><span>Content ideas</span><strong>' . esc_html((string) count($last_content['recommendations'] ?? [])) . '</strong></div><div class="seo-metric"><span>Keyword ideas</span><strong>' . esc_html((string) count($last_keywords['keywords'] ?? [])) . '</strong></div><div class="seo-metric"><span>Auto fixes</span><strong>' . esc_html((string) count($last_optimize['auto_fixes'] ?? [])) . '</strong></div></div>';
        if (!empty($last_optimize['summary']) || !empty($last_optimize['priorities']) || !empty($last_optimize['auto_fixes'])) {
            echo '<div class="seo-section"><h2>Latest AI results</h2>';
            if (!empty($last_optimize['summary'])) {
                echo '<p class="seo-summary">' . $this->render_text($last_optimize['summary']) . '</p>';
            }
            if (!empty($last_optimize['priorities'])) {
                echo '<h3>Top priorities</h3><ul class="seo-list">';
                foreach ($this->render_list_items($last_optimize['priorities'] ?? []) as $priority) {
                    echo '<li>' . esc_html($priority) . '</li>';
                }
                echo '</ul>';
            }
            if (!empty($last_optimize['auto_fixes'])) {
                echo '<h3>Corrections generated</h3><table class="seo-table"><thead><tr><th>Page</th><th>New title</th><th>New meta</th><th>ALT updates</th></tr></thead><tbody>';
                foreach (($last_optimize['auto_fixes'] ?? []) as $fix) {
                    echo '<tr>';
                    echo '<td>' . $this->render_text($fix['page_url'] ?? '') . '</td>';
                    echo '<td>' . $this->render_text($fix['optimized_title'] ?? '—') . '</td>';
                    echo '<td>' . $this->render_text($fix['optimized_meta_description'] ?? '—') . '</td>';
                    echo '<td>' . esc_html((string) count($fix['image_alt_updates'] ?? [])) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            }
            echo '</div>';
        }

        echo '<script>
          document.addEventListener("DOMContentLoaded", function () {
            const button = document.getElementById("seo-autopilot-optimize");
            const status = document.getElementById("seo-autopilot-status");
            if (!button) return;
            button.addEventListener("click", function () {
              button.disabled = true;
              status.innerText = "Optimizing...";
              const body = new URLSearchParams();
              body.append("action", "seo_autopilot_optimize_site");
              body.append("nonce", "' . esc_js(wp_create_nonce('seo_autopilot_optimize_site')) . '");
              fetch(ajaxurl, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: body.toString() })
                .then((r) => r.json())
                .then((data) => {
                  status.innerText = data.success ? ((data.data?.applied_changes || 0) > 0 ? ("Optimization complete - " + data.data.applied_changes + " corrections applied automatically") : "Optimization complete") : (data.data?.message || "Optimization failed");
                  button.disabled = false;
                })
                .catch(() => {
                  status.innerText = "Request failed";
                  button.disabled = false;
                });
            });
          });
        </script>';
        echo '</div>';
    }

    public function render_settings() {
        $settings = $this->settings();
        echo '<div class="wrap"><h1>AI SEO Autopilot Settings</h1><form method="post" action="options.php">';
        settings_fields($this->option_name);
        echo '<table class="form-table">';
        $fields = [
            'site_url' => 'Site URL',
            'api_key' => 'API Key',
            'connect_url' => 'Connect Endpoint URL',
            'site_audit_url' => 'Site Audit Endpoint URL',
            'optimize_site_url' => 'Optimize Site Endpoint URL',
            'optimize_page_url' => 'Optimize Page Endpoint URL',
            'keyword_url' => 'Keyword Opportunities Endpoint URL',
            'content_url' => 'Content Recommendations Endpoint URL',
        ];
        foreach ($fields as $key => $label) {
            echo '<tr><th scope="row">' . esc_html($label) . '</th><td><input class="regular-text" name="' . esc_attr($this->option_name . '[' . $key . ']') . '" value="' . esc_attr($settings[$key]) . '"></td></tr>';
        }
        echo '<tr><th scope="row">Mode</th><td><select name="' . esc_attr($this->option_name . '[mode]') . '"><option value="manual" ' . selected($settings['mode'], 'manual', false) . '>Manual Mode</option><option value="assisted" ' . selected($settings['mode'], 'assisted', false) . '>Assisted Mode</option><option value="auto" ' . selected($settings['mode'], 'auto', false) . '>Full Auto Mode</option></select><p class="description">Manual Mode only analyzes. Assisted Mode applies safe SEO fixes. Full Auto Mode also applies content blocks and keeps the expat finance niche prioritized.</p><p class="description"><strong>Important:</strong> replace preview URLs with the live function URLs from Base44 → Code → Functions if WordPress shows private access errors.</p></td></tr>';
        echo '</table>';
        submit_button('Save Settings');
        echo '</form></div>';
    }

    public function render_audit() {
        $run_result = [];
        if (!empty($_POST['seo_autopilot_run_audit']) && check_admin_referer('seo_autopilot_run_audit_action')) {
            $run_result = $this->run_endpoint_job('site_audit_url', 'seo_autopilot_ai_last_site_audit');
        }
        $result = $this->get_result('seo_autopilot_ai_last_site_audit');
        $audit = $result['audit'] ?? [];
        echo '<div class="wrap"><h1>Site Audit</h1><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">';
        echo '<form method="post" style="margin:0;">';
        wp_nonce_field('seo_autopilot_run_audit_action');
        echo '<p style="margin:0;"><button class="button button-primary" name="seo_autopilot_run_audit" value="1">Run Site Audit</button></p></form>';
        echo '<form method="post" style="margin:0;">';
        wp_nonce_field('seo_autopilot_fix_all_action');
        echo '<p style="margin:0;"><button class="button button-secondary" name="seo_autopilot_fix_all" value="1">Apply All Homepage Fixes</button></p></form></div>';
        if (!empty($run_result['message']) || !empty($run_result['error'])) {
            echo '<div class="notice notice-error"><p>' . esc_html($run_result['message'] ?? $run_result['error']) . '</p></div>';
        }
        if (empty($audit)) {
            echo '<p class="seo-empty">Run a site audit to display real results here.</p></div>';
            return;
        }
        echo '<div class="seo-metrics">';
        echo '<div class="seo-metric"><span>SEO score</span><strong>' . esc_html((string) ($audit['seo_score'] ?? 0)) . '</strong></div>';
        echo '<div class="seo-metric"><span>Pages</span><strong>' . esc_html((string) ($audit['total_pages_scanned'] ?? 0)) . '</strong></div>';
        echo '<div class="seo-metric"><span>Critical</span><strong>' . esc_html((string) ($audit['critical_issues'] ?? 0)) . '</strong></div>';
        echo '<div class="seo-metric"><span>Warnings</span><strong>' . esc_html((string) ($audit['warnings'] ?? 0)) . '</strong></div>';
        echo '</div>';
        if (!empty($audit['summary'])) {
            echo '<p class="seo-summary">' . esc_html($audit['summary']) . '</p>';
        }
        if (!empty($audit['issues'])) {
            echo '<table class="seo-table"><thead><tr><th>Severity</th><th>Page</th><th>Issue</th><th>Recommendation</th></tr></thead><tbody>';
            foreach (($audit['issues'] ?? []) as $issue) {
                echo '<tr>';
                echo '<td>' . esc_html($issue['severity'] ?? '') . '</td>';
                echo '<td>' . esc_html($issue['page_url'] ?? '') . '</td>';
                echo '<td>' . esc_html($issue['description'] ?? '') . '</td>';
                echo '<td>' . esc_html($issue['recommendation'] ?? '') . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';
    }

    public function render_content() {
        $run_result = [];
        if (!empty($_POST['seo_autopilot_run_content']) && check_admin_referer('seo_autopilot_run_content_action')) {
            $run_result = $this->run_endpoint_job('content_url', 'seo_autopilot_ai_last_content');
        }
        $result = $this->get_result('seo_autopilot_ai_last_content');
        $items = $result['recommendations'] ?? [];
        echo '<div class="wrap"><h1>Content Optimizer</h1><form method="post">';
        wp_nonce_field('seo_autopilot_run_content_action');
        echo '<p><button class="button button-primary" name="seo_autopilot_run_content" value="1">Generate Content Recommendations</button></p></form>';
        if (!empty($run_result['message']) || !empty($run_result['error'])) {
            echo '<div class="notice notice-error"><p>' . esc_html($run_result['message'] ?? $run_result['error']) . '</p></div>';
        }
        if (empty($items)) {
            echo '<p class="seo-empty">Generate recommendations to display real content improvements here.</p></div>';
            return;
        }
        echo '<table class="seo-table"><thead><tr><th>Page</th><th>Type</th><th>Priority</th><th>Description</th><th>Suggested content</th></tr></thead><tbody>';
        foreach ($items as $item) {
            echo '<tr>';
            echo '<td>' . esc_html($item['page_url'] ?? '') . '</td>';
            echo '<td>' . esc_html($item['type'] ?? '') . '</td>';
            echo '<td>' . esc_html($item['priority'] ?? '') . '</td>';
            echo '<td>' . esc_html($item['description'] ?? '') . '</td>';
            echo '<td>' . esc_html($item['suggested_content'] ?? '') . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

    public function render_keywords() {
        $run_result = [];
        if (!empty($_POST['seo_autopilot_run_keywords']) && check_admin_referer('seo_autopilot_run_keywords_action')) {
            $run_result = $this->run_endpoint_job('keyword_url', 'seo_autopilot_ai_last_keywords');
        }
        $result = $this->get_result('seo_autopilot_ai_last_keywords');
        $items = $result['keywords'] ?? [];
        echo '<div class="wrap"><h1>Keyword Opportunities</h1><form method="post">';
        wp_nonce_field('seo_autopilot_run_keywords_action');
        echo '<p><button class="button button-primary" name="seo_autopilot_run_keywords" value="1">Generate Keyword Opportunities</button></p></form>';
        if (!empty($run_result['message']) || !empty($run_result['error'])) {
            echo '<div class="notice notice-error"><p>' . esc_html($run_result['message'] ?? $run_result['error']) . '</p></div>';
        }
        if (empty($items)) {
            echo '<p class="seo-empty">Generate keywords to display real opportunities here.</p></div>';
            return;
        }
        echo '<table class="seo-table"><thead><tr><th>Keyword</th><th>Volume</th><th>Difficulty</th><th>Intent</th><th>Assigned page</th></tr></thead><tbody>';
        foreach ($items as $item) {
            echo '<tr>';
            echo '<td>' . esc_html($item['keyword'] ?? '') . '</td>';
            echo '<td>' . esc_html((string) ($item['search_volume'] ?? 0)) . '</td>';
            echo '<td>' . esc_html($item['difficulty'] ?? '') . '</td>';
            echo '<td>' . esc_html($item['intent'] ?? '') . '</td>';
            echo '<td>' . esc_html($item['assigned_page'] ?? '') . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

    public function render_backlinks() {
        $result = $this->get_result('seo_autopilot_ai_last_optimize_result');
        $items = $result['backlink_opportunities'] ?? [];
        echo '<div class="wrap"><h1>Backlink Opportunities</h1>';
        if (empty($items)) {
            echo '<p class="seo-empty">Run Optimize My Website to generate backlink opportunities here.</p></div>';
            return;
        }
        echo '<ul class="seo-list">';
        foreach ($items as $item) {
            echo '<li><strong>' . esc_html($item['source_name'] ?? $item['source_url'] ?? '') . '</strong> — ' . esc_html($item['source_url'] ?? '') . ' (' . esc_html($item['type'] ?? '') . ')</li>';
        }
        echo '</ul></div>';
    }

    public function render_eeat() {
        $result = $this->get_result('seo_autopilot_ai_last_optimize_result');
        $items = $result['eeat_recommendations'] ?? [];
        echo '<div class="wrap"><h1>E-E-A-T Optimization</h1>';
        echo '<form method="post" style="margin:16px 0;">';
        wp_nonce_field('seo_autopilot_fix_all_action');
        echo '<button class="button button-primary" name="seo_autopilot_fix_all" value="1">Apply E-E-A-T Improvements</button>';
        echo '</form>';
        echo '<div class="seo-section"><h2>Ready-to-apply trust content</h2><table class="seo-table"><thead><tr><th>Asset</th><th>Status</th><th>Purpose</th></tr></thead><tbody>';
        echo '<tr><td>About page</td><td>Generated</td><td>Clarifies who runs the site and the editorial mission.</td></tr>';
        echo '<tr><td>Team page</td><td>Generated</td><td>Strengthens transparency and people-first trust signals.</td></tr>';
        echo '<tr><td>Editorial Policy</td><td>Generated</td><td>Explains how content is created and reviewed.</td></tr>';
        echo '<tr><td>Disclaimer</td><td>Generated</td><td>Supports finance content compliance and trust.</td></tr>';
        echo '<tr><td>Author bio</td><td>Generated</td><td>Adds expertise and authorship across articles.</td></tr>';
        echo '</tbody></table></div>';
        if (empty($items)) {
            echo '<p class="seo-empty">Run Optimize My Website to generate trust and authority recommendations here.</p></div>';
            return;
        }
        echo '<div class="seo-section"><h2>Recommended E-E-A-T improvements</h2><ul class="seo-list">';
        foreach ($items as $item) {
            echo '<li>' . esc_html($item) . '</li>';
        }
        echo '</ul></div></div>';
    }
    public function render_automations() {
        $settings = $this->settings();
        $last_run = get_option('seo_autopilot_ai_last_automation_result', []);
        $next_run = wp_next_scheduled($this->cron_hook);
        echo '<div class="wrap"><h1>Automations</h1>';
        echo '<div class="notice notice-success"><p>Automation is active and runs automatically every day using your selected mode.</p></div>';
        echo '<form method="post" style="margin:16px 0;">';
        wp_nonce_field('seo_autopilot_fix_all_action');
        echo '<button class="button button-primary" name="seo_autopilot_fix_all" value="1">Fix all issues now</button>';
        echo '</form>';
        echo '<table class="widefat striped"><tbody>';
        echo '<tr><td><strong>Mode</strong></td><td>' . esc_html(ucfirst($settings['mode'] ?? 'review')) . '</td></tr>';
        echo '<tr><td><strong>Next run</strong></td><td>' . esc_html($this->format_datetime($next_run)) . '</td></tr>';
        echo '<tr><td><strong>Last run</strong></td><td>' . esc_html($this->format_datetime($last_run['ran_at'] ?? null)) . '</td></tr>';
        echo '<tr><td><strong>Last status</strong></td><td>' . esc_html(!empty($last_run['success']) ? 'Success' : 'Waiting or failed') . '</td></tr>';
        echo '<tr><td><strong>Applied changes</strong></td><td>' . esc_html((string) intval($last_run['applied_changes'] ?? 0)) . '</td></tr>';
        echo '</tbody></table>';
        echo '<p style="margin-top:16px;">Daily automation is enabled and can also be triggered instantly with the one-click fix button.</p>';
        echo '</div>';
    }
    public function render_reports() {
        $audit = $this->get_result('seo_autopilot_ai_last_site_audit');
        $keywords = $this->get_result('seo_autopilot_ai_last_keywords');
        $content = $this->get_result('seo_autopilot_ai_last_content');
        $optimize = $this->get_result('seo_autopilot_ai_last_optimize_result');
        echo '<div class="wrap"><h1>Reports</h1><div class="seo-metrics">';
        echo '<div class="seo-metric"><span>Last SEO score</span><strong>' . esc_html((string) (($audit['audit']['seo_score'] ?? 0))) . '</strong></div>';
        echo '<div class="seo-metric"><span>Keywords found</span><strong>' . esc_html((string) count($keywords['keywords'] ?? [])) . '</strong></div>';
        echo '<div class="seo-metric"><span>Content ideas</span><strong>' . esc_html((string) count($content['recommendations'] ?? [])) . '</strong></div>';
        echo '<div class="seo-metric"><span>Corrections</span><strong>' . esc_html((string) ($optimize['applied_changes'] ?? 0)) . '</strong></div>';
        echo '</div>';
        if (!empty($optimize['summary'])) {
            echo '<p class="seo-summary">' . esc_html($optimize['summary']) . '</p>';
        }
        echo '</div>';
    }

    public function render_history() {
        $history = get_option('seo_autopilot_ai_fix_history', []);
        $history = is_array($history) ? array_reverse($history) : [];
        echo '<div class="wrap"><h1>Applied History</h1>';
        if (empty($history)) {
            echo '<p class="seo-empty">No automatic corrections have been recorded yet.</p></div>';
            return;
        }
        echo '<table class="seo-table"><thead><tr><th>Date</th><th>Action</th><th>Page</th><th>New value</th></tr></thead><tbody>';
        foreach ($history as $item) {
            echo '<tr>';
            echo '<td>' . esc_html($item['applied_at'] ?? '') . '</td>';
            echo '<td>' . esc_html($item['action_type'] ?? '') . '</td>';
            echo '<td>' . esc_html($item['page_url'] ?? '') . '</td>';
            echo '<td>' . esc_html($item['new_value'] ?? '') . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }
}

new SEOAutopilotAIConnector();`;

const pluginCssFile = String.raw`.seo-autopilot-wrap {
  max-width: 1200px;
}

.seo-hero {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  background: linear-gradient(135deg, #0f172a, #1e3a8a);
  border-radius: 18px;
  padding: 24px;
  color: #fff;
  margin-bottom: 18px;
}

.seo-hero h1 {
  margin: 0;
  color: #fff;
  font-size: 30px;
  line-height: 1.1;
}

.seo-hero-text {
  margin: 8px 0 0;
  color: rgba(255,255,255,.82);
  max-width: 680px;
}

.seo-pill-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.seo-pill {
  background: rgba(255,255,255,.12);
  border: 1px solid rgba(255,255,255,.16);
  color: #fff;
  border-radius: 999px;
  padding: 8px 12px;
  font-size: 12px;
  white-space: nowrap;
}

.seo-autopilot-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 20px;
  margin-top: 20px;
}

.seo-card {
  background: #fff;
  border: 1px solid #dfe6ef;
  border-radius: 16px;
  padding: 22px;
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
}

.seo-card h2,
.seo-section h2 {
  margin-top: 0;
}

.seo-section {
  background: #fff;
  border: 1px solid #dfe6ef;
  border-radius: 16px;
  padding: 22px;
  margin-top: 20px;
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
}

.seo-metrics {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 12px;
  margin: 16px 0;
}

.seo-metric {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 14px;
}

.seo-metric span {
  display: block;
  color: #64748b;
  font-size: 12px;
}

.seo-metric strong {
  display: block;
  margin-top: 6px;
  font-size: 22px;
  color: #0f172a;
}

.seo-summary {
  color: #334155;
  line-height: 1.7;
}

.seo-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 16px;
}

.seo-table th,
.seo-table td {
  border-bottom: 1px solid #e2e8f0;
  padding: 12px 10px;
  text-align: left;
  vertical-align: top;
}

.seo-table th {
  font-size: 12px;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: .04em;
}

.seo-list {
  margin: 12px 0 0 18px;
  color: #334155;
}

.seo-empty {
  margin-top: 16px;
  background: #fff;
  border: 1px dashed #cbd5e1;
  border-radius: 14px;
  padding: 18px;
  color: #64748b;
}

#seo-autopilot-status {
  margin-top: 12px;
  color: #334155;
  font-weight: 500;
}

@media (max-width: 960px) {
  .seo-autopilot-grid,
  .seo-metrics {
    grid-template-columns: 1fr;
  }

  .seo-hero {
    flex-direction: column;
  }
}`;

const endpointReference = String.raw`Base44 backend functions created in this app:

- connectSite
- siteAudit
- optimizeSite
- optimizePage
- keywordOpportunities
- contentRecommendations

How to get each raw URL:
Dashboard -> Code -> Functions -> open the function -> copy its endpoint URL

Plugin settings mapping:
- Connect Endpoint URL -> connectSite
- Site Audit Endpoint URL -> siteAudit
- Optimize Site Endpoint URL -> optimizeSite
- Optimize Page Endpoint URL -> optimizePage
- Keyword Opportunities Endpoint URL -> keywordOpportunities
- Content Recommendations Endpoint URL -> contentRecommendations

Auto Mode behavior:
- Clicking Optimize My Website can apply safe fixes automatically
- WordPress now schedules a daily optimization job when Mode is set to Auto
- Safe fixes currently include post title updates, meta description updates, and missing image ALT text updates
- A lightweight backup of previous values is stored before applying changes

Required payload fields for WordPress requests:
- site_url
- api_key
- mode
- pages (for full-site sync)
- page (for single-page optimization)`;

export default function WordPressPlugin() {
  const [downloading, setDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState('');

  const handleDownload = async () => {
    setDownloading(true);
    setDownloadError('');

    try {
      const response = await base44.functions.invoke('downloadWordPressPluginZip', {});
      const fileUrl = response?.data?.file_url || response?.data?.download_url;

      if (!fileUrl) {
        setDownloadError('Download link not found.');
        return;
      }

      window.open(fileUrl, '_blank');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader
        title="AI SEO Autopilot WordPress Plugin"
        description="Download the new English WordPress plugin for AI SEO Autopilot, built to apply safe SEO fixes and automation directly on connected sites."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="border-gray-200">
          <CardContent className="p-5">
            <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center mb-4">
              <Globe className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-900">Direct WordPress workflow</h3>
            <p className="text-sm text-gray-500 mt-1">Users can connect, scan, and optimize without leaving WordPress.</p>
          </CardContent>
        </Card>
        <Card className="border-gray-200">
          <CardContent className="p-5">
            <div className="w-10 h-10 rounded-xl bg-violet-50 flex items-center justify-center mb-4">
              <Server className="w-5 h-5 text-violet-600" />
            </div>
            <h3 className="font-semibold text-gray-900">Base44 backend endpoints</h3>
            <p className="text-sm text-gray-500 mt-1">The plugin calls your app functions over raw HTTP.</p>
          </CardContent>
        </Card>
        <Card className="border-gray-200">
          <CardContent className="p-5">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center mb-4">
              <Shield className="w-5 h-5 text-emerald-600" />
            </div>
            <h3 className="font-semibold text-gray-900">Review and Auto modes</h3>
            <p className="text-sm text-gray-500 mt-1">Auto mode now applies SEO fixes, content suggestions, author box, schema author and the Editorial Policy page automatically.</p>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-wrap gap-2">
        <Badge className="bg-blue-50 text-blue-700">WordPress 6+</Badge>
        <Badge className="bg-violet-50 text-violet-700">PHP 8+</Badge>
        <Badge className="bg-emerald-50 text-emerald-700">Gutenberg + Classic</Badge>
      </div>

      <Card className="border-blue-200 bg-blue-50/40">
        <CardContent className="p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h3 className="font-semibold text-gray-900">Direct plugin download</h3>
            <p className="text-sm text-gray-600 mt-1">Download the new ZIP package ready to upload into WordPress.</p>
          </div>
          <Button onClick={handleDownload} disabled={downloading} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
            {downloading ? 'Preparing ZIP...' : <>Download plugin ZIP <Download className="w-4 h-4" /></>}
          </Button>
          {downloadError ? <p className="text-sm text-destructive">{downloadError}</p> : null}
        </CardContent>
      </Card>

      <CodeCard
        title="ai-seo-autopilot.php"
        description="Main plugin file with automatic SEO application, EEAT injection, admin-ready WordPress draft import, and direct WordPress optimization."
        code={pluginMainFile}
      />

      <CodeCard
        title="admin.css"
        description="Minimal admin styling for the plugin dashboard."
        code={pluginCssFile}
      />

      <CodeCard
        title="Endpoint mapping"
        description="Use these function names when wiring the plugin to your Base44 backend."
        code={endpointReference}
      />

      <Card className="border-dashed border-blue-200 bg-blue-50/40">
        <CardContent className="p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h3 className="font-semibold text-gray-900">Next setup step</h3>
            <p className="text-sm text-gray-600 mt-1">Open Dashboard → Code → Functions to copy the live endpoint URL for each backend function into the WordPress plugin settings.</p>
          </div>
          <Button asChild className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
            <a href="https://base44.com" target="_blank" rel="noopener noreferrer">
              Open Base44 <ExternalLink className="w-4 h-4" />
            </a>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}