import React from 'react';
import SeoArticleLayout from '@/components/seo/SeoArticleLayout';
import { articlePages } from '@/lib/seoPages';

export default function CheapestWayToSendMoneyToMoroccoFromUsa() {
  return <SeoArticleLayout page={articlePages.CheapestWayToSendMoneyToMoroccoFromUsa} />;
}