import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function APIKeys() {
  const [name, setName] = useState('');
  const queryClient = useQueryClient();
  const { data: workspaces = [] } = useQuery({ queryKey: ['workspaces'], queryFn: () => base44.entities.Workspace.list('-created_date', 1) });
  const { data: projects = [] } = useQuery({ queryKey: ['projects'], queryFn: () => base44.entities.Project.list('-created_date', 1) });
  const { data: keys = [] } = useQuery({ queryKey: ['api-keys'], queryFn: () => base44.entities.ApiKey.list('-created_date', 100) });

  const createKey = async () => {
    if (!workspaces[0] || !name) return;
    await base44.entities.ApiKey.create({ workspace_id: workspaces[0].id, project_id: projects[0]?.id, name, provider: 'internal', key_type: 'project', key_value: crypto.randomUUID().replace(/-/g, ''), status: 'active' });
    setName('');
    queryClient.invalidateQueries({ queryKey: ['api-keys'] });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="API Keys" description="Manage project API keys, connection secrets, and future billing-ready access control." />
      <div className="flex gap-3"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Key label" className="rounded-xl" /><Button onClick={createKey} className="rounded-xl bg-blue-600 hover:bg-blue-700">Generate Key</Button></div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{keys.map((item) => <Card key={item.id}><CardContent className="p-5"><h3 className="font-semibold text-gray-900">{item.name}</h3><p className="text-sm text-gray-500 mt-1">{item.provider} · {item.key_type}</p><p className="text-xs text-gray-400 mt-2 break-all">{String(item.key_value).slice(0, 12)}••••••</p></CardContent></Card>)}</div>
    </div>
  );
}