import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';
import JSZip from 'npm:jszip@3.10.1';

const pluginPhp = String.raw`<?php
/**
 * Plugin Name: MoneyAbroadGuide Complete Site
 * Description: Installe une version complète légère du site MoneyAbroadGuide avec homepage, pages légales et habillage éditorial.
 * Version: 1.0.2
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) exit;

class MAG_Complete_Site {
    const HOME_SLUG = 'moneyabroadguide-home';
    const ABOUT_SLUG = 'about';
    const CONTACT_SLUG = 'contact';
    const PRIVACY_SLUG = 'privacy-policy';
    const HOME_TEMPLATE = '[mag_complete_home]';
    const ABOUT_TEMPLATE = '[mag_complete_about]';
    const CONTACT_TEMPLATE = '[mag_complete_contact]';
    const PRIVACY_TEMPLATE = '[mag_complete_privacy]';

    public function __construct() {
        add_shortcode('mag_complete_home', [$this, 'render_home']);
        add_shortcode('mag_complete_about', [$this, 'render_about']);
        add_shortcode('mag_complete_contact', [$this, 'render_contact']);
        add_shortcode('mag_complete_privacy', [$this, 'render_privacy']);
        add_filter('the_content', [$this, 'replace_page_content'], 1);
        add_filter('the_content', [$this, 'append_article_footer'], 20);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_filter('body_class', [$this, 'add_body_class']);
    }

    public static function activate() {
        $instance = new self();
        $pages = $instance->ensure_pages();

        if (!empty($pages['home'])) {
            update_option('show_on_front', 'page');
            update_option('page_on_front', $pages['home']);
            update_option('page_for_posts', 0);
        }

        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    private function upsert_page($slug, $title, $shortcode) {
        $page = get_page_by_path($slug, OBJECT, 'page');
        $page_data = [
            'post_title' => $title,
            'post_name' => $slug,
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_content' => $shortcode,
        ];

        if ($page) {
            $page_data['ID'] = $page->ID;
            return wp_update_post($page_data, true);
        }

        return wp_insert_post($page_data, true);
    }

    private function ensure_pages() {
        return [
            'home' => $this->upsert_page(self::HOME_SLUG, 'Home', self::HOME_TEMPLATE),
            'about' => $this->upsert_page(self::ABOUT_SLUG, 'About', self::ABOUT_TEMPLATE),
            'contact' => $this->upsert_page(self::CONTACT_SLUG, 'Contact', self::CONTACT_TEMPLATE),
            'privacy' => $this->upsert_page(self::PRIVACY_SLUG, 'Privacy Policy', self::PRIVACY_TEMPLATE),
        ];
    }

    private function is_target_page() {
        return is_page([self::HOME_SLUG, self::ABOUT_SLUG, self::CONTACT_SLUG, self::PRIVACY_SLUG]);
    }

    public function replace_page_content($content) {
        if (is_admin() || !in_the_loop() || !is_main_query() || !$this->is_target_page()) {
            return $content;
        }

        if (is_page(self::HOME_SLUG) || is_front_page()) {
            return do_shortcode(self::HOME_TEMPLATE);
        }

        if (is_page(self::ABOUT_SLUG)) {
            return do_shortcode(self::ABOUT_TEMPLATE);
        }

        if (is_page(self::CONTACT_SLUG)) {
            return do_shortcode(self::CONTACT_TEMPLATE);
        }

        if (is_page(self::PRIVACY_SLUG)) {
            return do_shortcode(self::PRIVACY_TEMPLATE);
        }

        return $content;
    }

    private function header_html() {
        $logo_url = 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/7807cf1df_logoMoneyabroadGuide.jpeg';
        return '<header class="mag-site-header"><div class="mag-shell mag-header-inner"><a href="' . esc_url(home_url('/')) . '" class="mag-logo-link"><img src="' . esc_url($logo_url) . '" alt="MoneyAbroadGuide" class="mag-logo" loading="lazy" /></a><nav class="mag-nav"><a href="' . esc_url(home_url('/')) . '">Home</a><a href="' . esc_url(home_url('/about/')) . '">About</a><a href="' . esc_url(home_url('/contact/')) . '">Contact</a><a href="' . esc_url(home_url('/privacy-policy/')) . '">Privacy Policy</a></nav></div></header>';
    }

    private function footer_html() {
        return '<footer class="mag-site-footer"><div class="mag-shell mag-footer-inner"><div><h3>MoneyAbroadGuide</h3><p>Educational financial content for immigrants, expats, and newcomers in North America.</p></div><div class="mag-footer-links"><a href="' . esc_url(home_url('/about/')) . '">About</a><a href="' . esc_url(home_url('/contact/')) . '">Contact</a><a href="' . esc_url(home_url('/privacy-policy/')) . '">Privacy Policy</a></div></div></footer>';
    }

    public function enqueue_assets() {
        wp_enqueue_style('mag-complete-site-style', plugins_url('style.css', __FILE__), [], '1.0.2');
        wp_enqueue_script('mag-complete-site-script', plugins_url('script.js', __FILE__), [], '1.0.2', true);
    }

    public function add_body_class($classes) {
        if ($this->is_target_page() || is_front_page()) {
            $classes[] = 'mag-complete-site-active';
        }
        return $classes;
    }

    public function render_home() {
        ob_start(); ?>
        <div class="mag-site-root">
          <?php echo $this->header_html(); ?>
          <main class="mag-page">
            <section class="mag-hero">
              <div class="mag-shell mag-hero-inner">
                <div class="mag-pill">Trusted money transfer comparison for immigrants, expats, and global families</div>
                <h1>Save Up to 90% on International Money Transfers</h1>
                <p>Compare real-time rates from trusted providers and avoid hidden fees.</p>
                <div class="mag-actions">
                  <a href="#compare" class="mag-btn mag-btn-primary">Compare Now</a>
                  <a href="#guides" class="mag-btn mag-btn-secondary">See Best Providers</a>
                </div>
              </div>
            </section>

            <section class="mag-section" id="compare">
              <div class="mag-shell">
                <div class="mag-card">
                  <h2>Compare top money transfer services at a glance</h2>
                  <div class="mag-table-wrap">
                    <table class="mag-table">
                      <thead><tr><th>Service</th><th>Fees</th><th>Speed</th><th>Exchange Rate</th><th>Rating</th></tr></thead>
                      <tbody>
                        <tr><td>Wise</td><td>Low, transparent</td><td>Minutes to 2 days</td><td>Mid-market rate</td><td>4.9/5</td></tr>
                        <tr><td>Remitly</td><td>Promo-friendly</td><td>Express available</td><td>Competitive</td><td>4.8/5</td></tr>
                        <tr><td>OFX</td><td>No fixed fee</td><td>1–3 days</td><td>Strong on large transfers</td><td>4.7/5</td></tr>
                        <tr><td>Xe</td><td>Varies</td><td>Same day to 3 days</td><td>Live rate tools</td><td>4.6/5</td></tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </section>

            <section class="mag-section" id="guides">
              <div class="mag-shell mag-grid-3">
                <article class="mag-card"><h3>Newcomers to the USA</h3><p>Educational explanations of U.S. financial concepts, banking basics, and saving.</p></article>
                <article class="mag-card"><h3>Newcomers to Canada</h3><p>Educational information to understand Canadian banking systems and financial basics.</p></article>
                <article class="mag-card"><h3>Start Here for Newcomers</h3><p>A simple starting point for immigrants learning financial systems in the USA and Canada.</p></article>
              </div>
            </section>
          </main>
          <?php echo $this->footer_html(); ?>
        </div>
        <?php return ob_get_clean();
    }

    public function render_about() {
        ob_start(); ?>
        <div class="mag-site-root"><?php echo $this->header_html(); ?><main class="mag-page"><section class="mag-shell"><div class="mag-card mag-prose"><h1>About MoneyAbroadGuide</h1><p>MoneyAbroadGuide is a financial education platform created to help immigrants, international students, and expats better understand money topics in North America.</p><p>Our goal is to provide clear, useful, and trustworthy information about banking, international transfers, credit building, and practical financial setup.</p></div></section></main><?php echo $this->footer_html(); ?></div>
        <?php return ob_get_clean();
    }

    public function render_contact() {
        ob_start(); ?>
        <div class="mag-site-root"><?php echo $this->header_html(); ?><main class="mag-page"><section class="mag-shell"><div class="mag-card mag-prose"><h1>Contact Us</h1><p>Email: contact@moneyabroadguide.com</p><p>For partnerships, use subject: Partnership</p><p>Response time: 24–48 hours</p><p>This site provides educational financial content only.</p></div></section></main><?php echo $this->footer_html(); ?></div>
        <?php return ob_get_clean();
    }

    public function render_privacy() {
        ob_start(); ?>
        <div class="mag-site-root"><?php echo $this->header_html(); ?><main class="mag-page"><section class="mag-shell"><div class="mag-card mag-prose"><h1>Privacy Policy</h1><p>Last updated: March 2026</p><p>We may collect personal data such as email and usage data.</p><p>We use cookies for analytics and affiliate tracking.</p><p>We may earn commissions through affiliate links at no extra cost to users.</p><p>Contact: contact@moneyabroadguide.com</p></div></section></main><?php echo $this->footer_html(); ?></div>
        <?php return ob_get_clean();
    }

    public function append_article_footer($content) {
        if (is_admin() || !is_singular('post') || !in_the_loop() || !is_main_query()) {
            return $content;
        }

        if (strpos($content, 'mag-author-footer-box') !== false) {
            return $content;
        }

        $footer = '<div class="mag-author-footer-box"><h3>About Talal Eddaouahiri</h3><p>Talal Eddaouahiri writes educational financial guides focused on immigrants, expats, and newcomers in North America.</p><p class="mag-article-disclosure">This article may contain affiliate links. We may earn a commission at no extra cost to you.</p><p class="mag-article-disclaimer">This content is for educational purposes only and should not be considered financial advice.</p></div>';
        return $content . $footer;
    }
}

register_activation_hook(__FILE__, ['MAG_Complete_Site', 'activate']);
register_deactivation_hook(__FILE__, ['MAG_Complete_Site', 'deactivate']);
new MAG_Complete_Site();`;

const pluginCss = String.raw`:root{--mag-primary:#16a34a;--mag-primary-dark:#166534;--mag-text:#0f172a;--mag-muted:#64748b;--mag-border:#e2e8f0}.mag-complete-site-active,.mag-complete-site-active .site{background:#f8fafc!important}.mag-complete-site-active *{box-sizing:border-box}.mag-complete-site-active .site-header,.mag-complete-site-active #masthead,.mag-complete-site-active .main-header-bar,.mag-complete-site-active .ast-above-header-wrap,.mag-complete-site-active .ast-below-header-wrap,.mag-complete-site-active .ast-desktop-header,.mag-complete-site-active .ast-mobile-header-wrap,.mag-complete-site-active .ast-theme-transparent-header,.mag-complete-site-active header[role='banner'],.mag-complete-site-active .site-footer,.mag-complete-site-active .entry-header,.mag-complete-site-active .entry-title{display:none!important}.mag-complete-site-active .entry-content,.mag-complete-site-active .site-content,.mag-complete-site-active .ast-container,.mag-complete-site-active #primary,.mag-complete-site-active .content-area{width:100%!important;max-width:100%!important;margin:0!important;padding:0!important}.mag-site-root{font-family:Inter,Arial,sans-serif;color:var(--mag-text)}.mag-shell{width:min(100%,960px);margin:0 auto;padding:0 16px}.mag-site-header{position:sticky;top:0;z-index:40;background:rgba(255,255,255,.95);border-bottom:1px solid var(--mag-border)}.mag-header-inner{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:12px 0}.mag-logo{width:300px;max-width:100%;height:auto}.mag-nav{display:none;gap:24px}.mag-nav a{text-decoration:none;color:#475569;font-weight:600}.mag-page{padding-bottom:56px}.mag-hero{padding:32px 0 56px;background:radial-gradient(circle at top center, rgba(31,143,106,.12), transparent 32%),linear-gradient(180deg,#f8fafc 0%,#ffffff 72%)}.mag-hero-inner{text-align:center;display:flex;flex-direction:column;gap:20px;align-items:center}.mag-pill{display:inline-flex;border:1px solid var(--mag-border);background:#fff;padding:10px 16px;border-radius:999px;color:#475569;font-weight:600}.mag-hero h1,.mag-prose h1,.mag-card h2,.mag-card h3{margin:0;color:var(--mag-text);line-height:1.08}.mag-hero h1{font-size:clamp(2.4rem,5vw,4rem);font-weight:800;letter-spacing:-.03em}.mag-hero p,.mag-card p,.mag-prose p{color:var(--mag-muted);line-height:1.8}.mag-actions{display:flex;flex-direction:column;gap:12px}.mag-btn{display:inline-flex;align-items:center;justify-content:center;min-height:52px;padding:0 24px;border-radius:999px;text-decoration:none;font-weight:700}.mag-btn-primary{background:var(--mag-primary);color:#fff}.mag-btn-secondary{background:#fff;border:1px solid var(--mag-border);color:var(--mag-text)}.mag-section{padding:28px 0}.mag-card{background:#fff;border:1px solid var(--mag-border);border-radius:28px;box-shadow:0 18px 45px rgba(15,23,42,.08);padding:24px}.mag-table-wrap{overflow-x:auto}.mag-table{width:100%;min-width:720px;border-collapse:collapse}.mag-table th,.mag-table td{padding:14px 12px;border-bottom:1px solid var(--mag-border);text-align:left}.mag-grid-3{display:grid;gap:16px}.mag-prose{max-width:760px;margin:0 auto}.mag-site-footer{border-top:1px solid var(--mag-border);background:#fff}.mag-footer-inner{display:grid;gap:16px;padding:28px 16px}.mag-footer-links{display:flex;flex-wrap:wrap;gap:16px}.mag-footer-links a{text-decoration:none;color:#475569}.mag-author-footer-box{margin-top:32px;padding:22px;border:1px solid var(--mag-border);border-radius:20px;background:#f8fafc}.mag-author-footer-box h3{margin:0 0 12px;color:#0f172a;font-size:22px}.mag-author-footer-box p{margin:0 0 12px;line-height:1.8;color:#475569}.mag-author-footer-box p:last-child{margin-bottom:0}.mag-article-disclosure{font-weight:600}.mag-article-disclaimer{color:#64748b}@media (min-width:900px){.mag-nav{display:flex}.mag-actions{flex-direction:row}.mag-grid-3{grid-template-columns:repeat(3,minmax(0,1fr))}.mag-footer-inner{grid-template-columns:1.2fr .8fr;align-items:start}}`;

const pluginJs = String.raw`document.addEventListener('DOMContentLoaded', function () {
  document.body.classList.add('mag-complete-site-active');
  var selectors = ['.site-header','#masthead','.main-header-bar','.ast-above-header-wrap','.ast-below-header-wrap','.ast-desktop-header','.ast-mobile-header-wrap','.ast-theme-transparent-header',"header[role='banner']",'.site-footer','.entry-header','.entry-title'];
  selectors.forEach(function (selector) {
    document.querySelectorAll(selector).forEach(function (el) {
      if (el && !el.closest('.mag-site-root')) el.remove();
    });
  });
});`;

async function buildZip() {
  const zip = new JSZip();
  const folder = zip.folder('moneyabroadguide-complete-site');
  folder.file('moneyabroadguide-complete-site.php', pluginPhp);
  folder.file('style.css', pluginCss);
  folder.file('script.js', pluginJs);
  return await zip.generateAsync({ type: 'uint8array' });
}

Deno.serve(async (req) => {
  try {
    const zipContent = await buildZip();

    if (req.method === 'GET') {
      return new Response(zipContent, {
        status: 200,
        headers: {
          'Content-Type': 'application/zip',
          'Content-Disposition': 'attachment; filename="moneyabroadguide-complete-site.zip"',
          'Cache-Control': 'no-store',
        },
      });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const zipFile = new File([zipContent], 'moneyabroadguide-complete-site.zip', { type: 'application/zip' });
    const upload = await base44.asServiceRole.integrations.Core.UploadFile({ file: zipFile });

    return Response.json({
      success: true,
      file_name: 'moneyabroadguide-complete-site.zip',
      folder_name: 'moneyabroadguide-complete-site',
      files: ['moneyabroadguide-complete-site.php', 'style.css', 'script.js'],
      file_url: upload.file_url,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});