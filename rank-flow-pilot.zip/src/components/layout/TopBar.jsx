import React from 'react';
import { Button } from '@/components/ui/button';
import { Rocket, Bell } from 'lucide-react';

export default function TopBar({ onOptimize, optimizing }) {
  return (
    <header className="h-16 border-b border-gray-100 bg-white/80 backdrop-blur-sm flex items-center justify-between px-6 sticky top-0 z-40">
      <div>
        <h2 className="text-sm font-medium text-gray-400 tracking-wide uppercase">SEO Autopilot AI</h2>
      </div>
      <div className="flex items-center gap-3">
        <button className="relative p-2 text-gray-400 hover:text-gray-600 transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-blue-500 rounded-full" />
        </button>
        <Button
          onClick={onOptimize}
          disabled={optimizing}
          className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white shadow-lg shadow-blue-500/20 gap-2 rounded-xl px-5"
        >
          <Rocket className="w-4 h-4" />
          {optimizing ? 'Optimizing...' : 'Optimize My Website'}
        </Button>
      </div>
    </header>
  );
}