import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const normalizeUrl = (url = '') => url.toLowerCase().trim().replace(/^https?:\/\//, '').replace(/\/$/, '');

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = req.method === 'POST' ? await req.json().catch(() => ({})) : {};
    const siteUrl = body.site_url || 'https://moneyabroadguide.com';
    const websites = await base44.asServiceRole.entities.Website.list();
    const website = websites.find((item) => normalizeUrl(item.url) === normalizeUrl(siteUrl));
    if (!website) return Response.json({ error: 'Website not found.' }, { status: 404 });

    const pages = await base44.asServiceRole.entities.Page.filter({ website_id: website.id }, '-updated_date', 100);
    const recommendations = await base44.asServiceRole.entities.ContentRecommendation.filter({ website_id: website.id }, '-created_date', 100);
    const scans = await base44.asServiceRole.entities.SiteScan.filter({ website_id: website.id }, '-created_date', 5);

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `Create a weekly SEO audit report for ${website.url} without paid APIs. Evaluate likely indexation readiness, Core Web Vitals risk signals, thin content under 300 words, missing metadata, missing alt tags, broken links risk, and backlink opportunities using this structured data: pages=${JSON.stringify(pages.map((page) => ({ url: page.url, title: page.title, word_count: page.word_count, meta_description: page.meta_description, has_alt_text: page.has_alt_text, internal_links_count: page.internal_links_count, has_faq: page.has_faq, seo_score: page.seo_score })))}, recommendations=${JSON.stringify(recommendations.map((item) => ({ page_url: item.page_url, type: item.type, priority: item.priority, status: item.status })))}, scans=${JSON.stringify(scans.map((scan) => ({ seo_score: scan.seo_score, critical_issues: scan.critical_issues, warnings: scan.warnings, summary: scan.summary })))}. Return JSON with keys report_json, report_markdown, critical_alert, summary, items_processed. report_json must be a compact JSON string. report_markdown must be a clean markdown summary with sections and bullet points.`,
      response_json_schema: {
        type: 'object',
        properties: {
          report_json: { type: 'string' },
          report_markdown: { type: 'string' },
          critical_alert: { type: 'boolean' },
          summary: { type: 'string' },
          items_processed: { type: 'number' }
        }
      }
    });

    const run = await base44.asServiceRole.entities.SeoAutopilotRun.create({
      website_id: website.id,
      run_type: 'weekly',
      status: 'completed',
      summary: result.summary,
      report_json: result.report_json,
      report_markdown: result.report_markdown,
      critical_alert: result.critical_alert,
      items_processed: result.items_processed || pages.length
    });

    return Response.json({ success: true, run });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});