import React from 'react';
import { CheckCircle2, ArrowRight } from 'lucide-react';
import MoneyTransferCalculator from '@/components/home/MoneyTransferCalculator';
import SectionReveal from '@/components/home/SectionReveal';
import { transferServices } from '@/lib/homepageData';

const trustBadges = [
  '100% Free',
  'Updated daily',
  'By immigrants',
  'Independent',
  'No sign-up',
];


export default function HomeHero() {
  return (
    <section id="top" className="relative overflow-hidden border-b border-slate-200/70 bg-[radial-gradient(ellipse_100%_90%_at_50%_-5%,#c8e8de_0%,#edf7f3_40%,#fff_100%)]">
      <SectionReveal className="mx-auto max-w-[1260px] px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid items-center gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10">
          <div>
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-[#001F3F] shadow-[0_2px_7px_rgba(0,31,63,0.07)]">
              <span className="h-2 w-2 rounded-full bg-green-500"></span>
              Updated 2026 — Free Educational Resource
            </div>

            <div className="space-y-5">
              <h1 className="max-w-3xl font-serif text-4xl font-bold leading-[1.05] tracking-tight text-[#0D1F2D] sm:text-5xl lg:text-[56px]">
                Your <span className="text-[#05825F]">Money</span> Roadmap
                <br />
                to Canada & the <span className="underline decoration-[#F5A623] decoration-4 underline-offset-4">USA</span>
              </h1>
              <p className="max-w-2xl text-[15px] leading-8 text-[#2E4A60] sm:text-lg">
                Free, honest guides for newcomers on banking, credit, transfers, housing and taxes — explained simply. All tools free, no sign-up.
              </p>
            </div>

            <div className="mt-5 flex flex-col gap-3 sm:flex-row">
              <a href="#calculator" className="cta-primary h-14 px-8 text-base">
                Compare Fees Now
              </a>
              <a href="/start-here/" className="inline-flex h-14 items-center justify-center rounded-full border-2 border-slate-300 bg-white px-8 text-base font-bold text-slate-900 transition hover:border-[#05825F] hover:text-[#05825F]">
                Start Free →
              </a>
            </div>

            <div className="mt-5 flex flex-wrap gap-3">
              {trustBadges.map((badge) => (
                <div key={badge} className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-[#2E4A60] shadow-sm">
                  <CheckCircle2 className="h-4 w-4 text-[#05825F]" />
                  <span>{badge}</span>
                </div>
              ))}
            </div>

            <div className="mt-4 flex items-center gap-2 text-sm text-slate-500">
              <span className="h-2 w-2 rounded-full bg-green-500"></span>
              <span>Used by <strong>10K+ expats</strong> in Canada & the USA</span>
            </div>
          </div>

          <div className="w-full rounded-[20px] border border-slate-200 bg-white p-5 text-left shadow-[0_14px_44px_rgba(0,31,63,0.1)]">
            <div className="mb-4 text-center sm:text-left">
              <p className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#05825F]">Live Tool — Transfer Calculator</p>
              <h2 className="mt-2 text-xl font-extrabold tracking-tight text-slate-950">How much does your family receive?</h2>
              <p className="mt-2 text-sm leading-7 text-slate-500">Compare quickly, then open the full calculator below.</p>
            </div>
            <div className="rounded-2xl bg-[#F8FAFC] p-4">
              <MoneyTransferCalculator />
            </div>
            <div className="mt-4 flex justify-center sm:justify-start">
              <a href="#calculator" className="inline-flex items-center gap-2 text-sm font-bold text-[#05825F] hover:text-[#07A076]">
                Open full comparison <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
      </SectionReveal>
    </section>
  );
}