import React from 'react';

export default function HomeFooter() {
  return (
    <footer className="bg-[#001F3F] text-white/60">
      <div className="mx-auto max-w-[1300px] px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <h3 className="text-lg font-extrabold text-white">MoneyAbroadGuide.com</h3>
            <p className="mt-4 max-w-xs text-sm leading-7 text-white/60">
              Free educational financial guides for newcomers in Canada and the USA. Independent, honest, always free.
            </p>
          </div>

          <div className="space-y-3 text-sm">
            <p className="font-bold uppercase tracking-[0.08em] text-white">Canada</p>
            <a href="/best-banks-newcomers-canada/" className="block transition hover:text-white">Best Banks</a>
            <a href="/build-credit-canada-newcomer/" className="block transition hover:text-white">Build Credit</a>
            <a href="/cost-of-living-canada-2026/" className="block transition hover:text-white">Cost of Living</a>
          </div>

          <div className="space-y-3 text-sm">
            <p className="font-bold uppercase tracking-[0.08em] text-white">USA</p>
            <a href="/banking-newcomers-usa/" className="block transition hover:text-white">Banking USA</a>
            <a href="/bank-account-immigrants-usa-no-ssn/" className="block transition hover:text-white">No SSN Banks</a>
            <a href="/nonresident-alien-taxes-usa-guide/" className="block transition hover:text-white">File US Taxes</a>
          </div>

          <div className="space-y-3 text-sm">
            <p className="font-bold uppercase tracking-[0.08em] text-white">Legal</p>
            <a href="/about" className="block transition hover:text-white">About</a>
            <a href="/contact" className="block transition hover:text-white">Contact</a>
            <a href="/privacy-policy" className="block transition hover:text-white">Privacy Policy</a>
          </div>
        </div>

        <div className="mt-10 border-t border-white/10 pt-5 text-xs text-white/40 sm:flex sm:items-center sm:justify-between">
          <span>© 2026 MoneyAbroadGuide.com — Educational purposes only</span>
          <span>Not financial advice</span>
        </div>
      </div>
    </footer>
  );
}