import React from 'react';
import CorridorLandingPage from '@/components/transfers/CorridorLandingPage';
import { transferCorridors } from '@/lib/transferCorridors';

export default function UsaToMorocco() {
  return <CorridorLandingPage page={transferCorridors.UsaToMorocco} />;
}