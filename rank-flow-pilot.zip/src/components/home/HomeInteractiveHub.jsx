import React, { useMemo, useState } from 'react';

const providers = [
  { key: 'wise', name: 'Wise', fee: 4.2, speed: 'Minutes', bestFor: 'Low fees', rate: { MAD: 9.82, INR: 61.5, PHP: 41.0 } },
  { key: 'remitly', name: 'Remitly', fee: 2.99, speed: 'Same day', bestFor: 'Speed', rate: { MAD: 9.65, INR: 60.9, PHP: 40.4 } },
  { key: 'ofx', name: 'OFX', fee: 0, speed: '1-2 days', bestFor: 'Large amounts', rate: { MAD: 9.48, INR: 59.8, PHP: 39.6 } },
  { key: 'xe', name: 'Xe', fee: 2, speed: '1-2 days', bestFor: 'Rate tools', rate: { MAD: 9.55, INR: 60.2, PHP: 39.9 } },
];

const budgetBase = {
  toronto: { rent: 2100, food: 500, transit: 180, extra: 350 },
  montreal: { rent: 1600, food: 460, transit: 110, extra: 280 },
  miami: { rent: 2400, food: 540, transit: 140, extra: 380 },
};

const adCards = [
  { title: 'Wise', text: 'Best rates for many transfer routes.', cta: 'Compare Wise', href: 'https://wise.com' },
  { title: 'Remitly', text: 'Fast transfer option for urgent payments.', cta: 'Try Remitly', href: 'https://www.remitly.com/' },
];

function AdColumn() {
  return (
    <div className="hidden xl:block">
      <div className="sticky top-24 space-y-4">
        <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 p-5 text-center text-sm text-slate-400">
          Google Ads 160×600
        </div>
        {adCards.map((card) => (
          <div key={card.title} className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-[0_12px_30px_rgba(15,23,42,0.06)]">
            <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#1F8F6A]">Sponsored</p>
            <h3 className="mt-2 text-lg font-bold text-slate-950">{card.title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-500">{card.text}</p>
            <a href={card.href} target="_blank" rel="noopener sponsored" className="mt-4 inline-flex rounded-full bg-[#1F8F6A] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#187255]">
              {card.cta}
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function HomeInteractiveHub() {
  const [tab, setTab] = useState('transfer');
  const [amount, setAmount] = useState(1000);
  const [destination, setDestination] = useState('MAD');
  const [city, setCity] = useState('toronto');
  const [creditStart, setCreditStart] = useState(0);
  const [homePrice, setHomePrice] = useState(500000);

  const transferRows = useMemo(() => {
    return providers
      .map((provider) => {
        const received = Math.max(0, amount - provider.fee) * provider.rate[destination];
        return { ...provider, received };
      })
      .sort((a, b) => b.received - a.received);
  }, [amount, destination]);

  const budget = budgetBase[city];
  const monthlyBudget = budget.rent + budget.food + budget.transit + budget.extra;
  const creditProjection = [3, 6, 12].map((month) => ({ month, score: Math.min(780, creditStart + month * 35 + 520) }));
  const downPayment = homePrice * 0.1;
  const loan = homePrice - downPayment;
  const mortgagePayment = Math.round((loan * 0.0056) / (1 - Math.pow(1.0056, -300)));

  const tabs = [
    { key: 'transfer', label: 'Transfer Calculator' },
    { key: 'budget', label: 'Budget Planner' },
    { key: 'credit', label: 'Credit Builder' },
    { key: 'mortgage', label: 'Mortgage Calc' },
  ];

  return (
    <section id="calculator" className="bg-[#F8FAFC]">
      <div className="mx-auto max-w-[1400px] px-4 py-14 sm:px-6 lg:px-8">
        <div className="mx-auto mb-8 max-w-3xl text-center">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.18em] text-[#1F8F6A]">Interactive Tools</p>
          <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 sm:text-4xl">Interactive tools designed to increase trust and conversions</h2>
          <p className="mt-3 text-base leading-7 text-slate-500">A centered premium tool area with room for ads and affiliate placements on desktop, while staying fully mobile-friendly.</p>
        </div>

        <div className="grid gap-6 xl:grid-cols-[220px_minmax(0,1fr)_220px]">
          <AdColumn />

          <div className="rounded-[32px] border border-slate-200 bg-white p-5 shadow-[0_20px_50px_rgba(15,23,42,0.08)] sm:p-6">
            <div className="mb-5 flex flex-wrap justify-center gap-3">
              {tabs.map((item) => (
                <button
                  key={item.key}
                  onClick={() => setTab(item.key)}
                  className={`rounded-full px-4 py-2 text-sm font-semibold transition ${tab === item.key ? 'bg-[#1F8F6A] text-white' : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50'}`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {tab === 'transfer' && (
              <div className="space-y-5">
                <div className="grid gap-4 sm:grid-cols-2">
                  <input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-medium outline-none focus:border-[#1F8F6A]" placeholder="Amount" />
                  <select value={destination} onChange={(e) => setDestination(e.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-medium outline-none focus:border-[#1F8F6A]">
                    <option value="MAD">Morocco (MAD)</option>
                    <option value="INR">India (INR)</option>
                    <option value="PHP">Philippines (PHP)</option>
                  </select>
                </div>
                <div className="space-y-3">
                  {transferRows.map((row, index) => (
                    <div key={row.key} className={`flex flex-col gap-2 rounded-2xl border px-4 py-4 sm:flex-row sm:items-center ${index === 0 ? 'border-[#1F8F6A] bg-[#F0FBF7]' : 'border-slate-200 bg-white'}`}>
                      <div className="min-w-[42px] text-sm font-bold text-slate-950">#{index + 1}</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 text-sm font-bold text-slate-950">
                          {row.name}
                          {index === 0 && <span className="rounded-full bg-[#1F8F6A] px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.14em] text-white">Editor’s Choice</span>}
                        </div>
                        <p className="text-sm text-slate-500">Best for: {row.bestFor} · Speed: {row.speed}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-extrabold text-slate-950">{Math.round(row.received).toLocaleString('en-CA')} {destination}</div>
                        <div className="text-xs text-slate-500">Fee: ${row.fee}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === 'budget' && (
              <div className="space-y-5">
                <select value={city} onChange={(e) => setCity(e.target.value)} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-medium outline-none focus:border-[#1F8F6A] sm:w-72">
                  <option value="toronto">Toronto</option>
                  <option value="montreal">Montreal</option>
                  <option value="miami">Miami</option>
                </select>
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                  {Object.entries(budget).map(([key, value]) => (
                    <div key={key} className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-center">
                      <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500">{key}</p>
                      <p className="mt-2 text-2xl font-extrabold text-slate-950">${value}</p>
                    </div>
                  ))}
                </div>
                <div className="rounded-2xl bg-[#0B1F3A] p-5 text-white">
                  <p className="text-sm text-white/70">Estimated monthly budget</p>
                  <p className="mt-2 text-3xl font-extrabold">${monthlyBudget.toLocaleString('en-CA')}</p>
                </div>
              </div>
            )}

            {tab === 'credit' && (
              <div className="space-y-5">
                <select value={creditStart} onChange={(e) => setCreditStart(Number(e.target.value))} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-medium outline-none focus:border-[#1F8F6A] sm:w-72">
                  <option value={0}>No score yet</option>
                  <option value={300}>300 - Poor</option>
                  <option value={550}>550 - Fair</option>
                </select>
                <div className="grid gap-4 md:grid-cols-3">
                  {creditProjection.map((item) => (
                    <div key={item.month} className="rounded-2xl border border-slate-200 bg-slate-50 p-5 text-center">
                      <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500">Month {item.month}</p>
                      <p className="mt-2 text-3xl font-extrabold text-[#1F8F6A]">{item.score}</p>
                      <p className="mt-2 text-sm text-slate-500">Projected score with regular payments and low utilization.</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === 'mortgage' && (
              <div className="space-y-5">
                <input type="number" value={homePrice} onChange={(e) => setHomePrice(Number(e.target.value) || 0)} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-medium outline-none focus:border-[#1F8F6A] sm:w-72" />
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5 text-center">
                    <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500">Down Payment</p>
                    <p className="mt-2 text-2xl font-extrabold text-slate-950">${Math.round(downPayment).toLocaleString('en-CA')}</p>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5 text-center">
                    <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500">Loan Amount</p>
                    <p className="mt-2 text-2xl font-extrabold text-slate-950">${Math.round(loan).toLocaleString('en-CA')}</p>
                  </div>
                  <div className="rounded-2xl bg-[#EAF7F1] p-5 text-center">
                    <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#1F8F6A]">Monthly Payment</p>
                    <p className="mt-2 text-2xl font-extrabold text-slate-950">${mortgagePayment.toLocaleString('en-CA')}</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          <AdColumn />
        </div>
      </div>
    </section>
  );
}