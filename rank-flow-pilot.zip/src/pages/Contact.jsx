import React from 'react';
import HomeHeader from '@/components/home/HomeHeader';
import HomeFooter from '@/components/home/HomeFooter';

export default function Contact() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-950">
      <HomeHeader />

      <main className="mx-auto max-w-[920px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
        <section className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-[0_18px_45px_rgba(15,23,42,0.08)] sm:p-10">
          <div className="mx-auto max-w-3xl text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#16a34a]">Contact Money Abroad Guide</p>
            <h1 className="mt-3 text-4xl font-extrabold tracking-tight sm:text-5xl">Contact Us</h1>
            <p className="mt-5 text-lg leading-8 text-slate-600">
              For general questions, partnerships, or editorial requests, contact the Money Abroad Guide team below.
            </p>
          </div>
        </section>

        <section className="mt-8 grid gap-6 md:grid-cols-2">
          <div className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-[0_18px_45px_rgba(15,23,42,0.08)]">
            <h2 className="text-2xl font-extrabold tracking-tight text-slate-950">Email</h2>
            <p className="mt-4 text-base leading-8 text-slate-600">
              Email: <a href="mailto:contact@moneyabroadguide.com" className="font-semibold text-[#16a34a] hover:underline">contact@moneyabroadguide.com</a>
            </p>
            <p className="mt-4 text-base leading-8 text-slate-600">
              For partnerships, please use the subject line: <strong>Partnership</strong>.
            </p>
          </div>

          <div className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-[0_18px_45px_rgba(15,23,42,0.08)]">
            <h2 className="text-2xl font-extrabold tracking-tight text-slate-950">Response time</h2>
            <p className="mt-4 text-base leading-8 text-slate-600">
              We usually respond within 24 to 48 hours on business days.
            </p>
            <p className="mt-4 text-base leading-8 text-slate-600">
              This site provides educational financial content only and does not offer personalised financial advice.
            </p>
          </div>
        </section>
      </main>

      <HomeFooter />
    </div>
  );
}