import React, { useMemo, useState } from 'react';
import { Input } from '@/components/ui/input';
import { ArrowRight } from 'lucide-react';
import { transferServices } from '@/lib/homepageData';
import { calculatorFromCountries, calculatorToCountries, getCalculatorCurrency, rankTransferProviders } from '@/lib/transferCalculator';

export default function MoneyTransferCalculator() {
  const [amount, setAmount] = useState(1000);
  const [fromCountry, setFromCountry] = useState('USA');
  const [toCountry, setToCountry] = useState('France');

  const rankings = useMemo(() => {
    const safeAmount = Number(amount) > 0 ? Number(amount) : 1000;
    return rankTransferProviders(safeAmount, fromCountry, toCountry, transferServices);
  }, [amount, fromCountry, toCountry]);

  const currency = getCalculatorCurrency(fromCountry);
  const formatter = new Intl.NumberFormat('en-US', { style: 'currency', currency });
  const bestProvider = rankings[0];
  const highestCost = rankings[rankings.length - 1]?.totalCost || 0;
  const estimatedSavings = highestCost - bestProvider.totalCost;

  return (
    <div id="calculator" className="fintech-card rounded-[30px] border border-slate-200/80 bg-white/95 p-6 shadow-[0_30px_70px_rgba(15,23,42,0.12)] backdrop-blur sm:p-8">
      <div className="space-y-3 text-center">
        <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#1F8F6A]">Transfer calculator</p>
        <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 sm:text-4xl">Find the best provider for your transfer</h2>
        <p className="mx-auto max-w-2xl text-sm leading-7 text-slate-500 sm:text-base">
          Enter an amount, choose your route, and instantly see the best provider ranked by total cost, speed, and trust.
        </p>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">Amount</label>
          <Input type="number" min="100" value={amount} onChange={(e) => setAmount(e.target.value)} className="h-12 rounded-2xl border-slate-200 bg-white" />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">From country</label>
          <select value={fromCountry} onChange={(e) => setFromCountry(e.target.value)} className="h-12 w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm text-slate-900 outline-none transition focus:border-[#1F8F6A]">
            {calculatorFromCountries.map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">To country</label>
          <select value={toCountry} onChange={(e) => setToCountry(e.target.value)} className="h-12 w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm text-slate-900 outline-none transition focus:border-[#1F8F6A]">
            {calculatorToCountries.map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="mt-6 rounded-[26px] bg-[#0B1F3A] p-5 text-white shadow-[0_25px_60px_rgba(11,31,58,0.24)] sm:p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div className="space-y-2 text-left">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-300">Best provider right now</p>
            <h3 className="text-4xl font-extrabold text-[#2f5ae8]">{bestProvider.name}</h3>
            <p className="max-w-sm text-sm leading-7 text-slate-300">Top-ranked for {fromCountry} to {toCountry} on {formatter.format(Number(amount) || 1000)}.</p>
          </div>
          <div className="w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-4 text-left lg:w-[220px]">
            <p className="text-slate-300">Estimated savings</p>
            <p className="mt-2 text-3xl font-extrabold text-white">{formatter.format(estimatedSavings > 0 ? estimatedSavings : 0)}</p>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <div className="min-h-[108px] rounded-2xl border border-white/10 bg-white/10 p-4 text-left">
            <p className="text-[11px] uppercase tracking-[0.08em] leading-5 text-slate-300">Total cost</p>
            <p className="mt-2 text-2xl leading-tight font-extrabold">{formatter.format(bestProvider.totalCost)}</p>
          </div>
          <div className="min-h-[108px] rounded-2xl border border-white/10 bg-white/10 p-4 text-left">
            <p className="text-[11px] uppercase tracking-[0.08em] leading-5 text-slate-300">Received amount</p>
            <p className="mt-2 text-2xl leading-tight font-extrabold">{formatter.format(bestProvider.receivedAmount)}</p>
          </div>
          <div className="min-h-[108px] rounded-2xl border border-white/10 bg-white/10 p-4 text-left">
            <p className="text-[11px] uppercase tracking-[0.08em] leading-5 text-slate-300">Fee</p>
            <p className="mt-2 text-2xl leading-tight font-extrabold">{formatter.format(bestProvider.fee)}</p>
          </div>
          <div className="min-h-[108px] rounded-2xl border border-white/10 bg-white/10 p-4 text-left">
            <p className="text-[11px] uppercase tracking-[0.08em] leading-5 text-slate-300">Speed</p>
            <p className="mt-2 text-2xl leading-tight font-extrabold">{bestProvider.speed}</p>
          </div>
        </div>
      </div>

      <div className="mt-5 space-y-3">
        {rankings.map((service) => (
          <div key={service.name} className="flex items-center justify-between gap-4 rounded-[22px] border border-slate-200 bg-slate-50/80 px-4 py-4 transition hover:border-slate-300 hover:bg-white">
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-sm font-bold text-slate-900 shadow-sm">#{service.rank}</div>
              <div className="min-w-0">
                <p className="truncate font-semibold text-slate-950">{service.name}</p>
                <p className="text-sm text-slate-500">{service.speed} • {service.rating}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-semibold text-slate-950">{formatter.format(service.totalCost)}</p>
              <p className="text-sm text-slate-500">Receives {formatter.format(service.receivedAmount)}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <a href={bestProvider.href} target="_blank" rel="noreferrer" className="cta-primary h-12 px-6 text-sm">
          Send Money Now
        </a>
        <a href="#compare" className="inline-flex items-center justify-center gap-2 rounded-full border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-900 transition hover:border-slate-300 hover:bg-slate-50">
          Compare providers in the table <ArrowRight className="h-4 w-4" />
        </a>
      </div>
    </div>
  );
}