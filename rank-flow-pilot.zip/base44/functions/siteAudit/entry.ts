import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import OpenAI from 'npm:openai@4.104.0';

const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY') });
const normalizeUrl = (url = '') => url.toLowerCase().trim().replace(/\/$/, '');
const toText = (value = '') => typeof value === 'string' ? value : value == null ? '' : String(value);
const toNumber = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const toArray = (value) => Array.isArray(value) ? value : [];

const getWebsite = async (base44, siteUrl, apiKey) => {
  const websites = await base44.asServiceRole.entities.Website.list();
  return websites.find((item) => normalizeUrl(item.url) === normalizeUrl(siteUrl) && item.wordpress_api_key === apiKey);
};

const askOpenAI = async (prompt) => {
  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: 'You are an expert SEO auditor. Return only valid JSON with no markdown.'
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
  });

  return JSON.parse(response.choices[0]?.message?.content || '{}');
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'siteAudit', required_fields: ['site_url', 'api_key'], optional_fields: ['pages'] });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.site_url || !payload.api_key) {
      return Response.json({ endpoint: 'siteAudit', required_fields: ['site_url', 'api_key'], optional_fields: ['pages'] });
    }

    const website = await getWebsite(base44, payload.site_url, payload.api_key);
    if (!website) {
      return Response.json({ error: 'Unauthorized WordPress connection.' }, { status: 403 });
    }

    const pageSummaries = toArray(payload.pages).slice(0, 50).map((page) => ({
      url: toText(page.url),
      title: toText(page.title),
      meta_description: toText(page.meta_description),
      h1: toText(page.h1),
      content_length: toText(page.content).length,
      image_count: toArray(page.images).length,
      missing_alt_count: toArray(page.images).filter((image) => !image.alt_text).length,
      internal_links_count: toArray(page.internal_links).length,
    }));

    const rawAudit = await askOpenAI(`Run a practical SEO audit for ${website.url} using this page data: ${JSON.stringify(pageSummaries)}. Return JSON with keys: seo_score, total_pages_scanned, critical_issues, warnings, opportunities, summary, issues. issues must be an array of objects with: type, severity, page_url, description, recommendation.`);

    const audit = {
      seo_score: toNumber(rawAudit.seo_score),
      total_pages_scanned: toNumber(rawAudit.total_pages_scanned, pageSummaries.length),
      critical_issues: toNumber(rawAudit.critical_issues),
      warnings: toNumber(rawAudit.warnings),
      opportunities: toNumber(rawAudit.opportunities),
      summary: toText(rawAudit.summary),
      issues: toArray(rawAudit.issues).map((issue) => ({
        type: toText(issue.type),
        severity: toText(issue.severity || 'medium'),
        page_url: toText(issue.page_url),
        description: toText(issue.description),
        recommendation: toText(issue.recommendation),
      })).filter((issue) => issue.description),
    };

    await base44.asServiceRole.entities.SiteScan.create({
      website_id: website.id,
      status: 'completed',
      ...audit,
    });

    await base44.asServiceRole.entities.Website.update(website.id, {
      seo_score: audit.seo_score,
      last_scan_date: new Date().toISOString(),
      total_pages: audit.total_pages_scanned,
      total_issues: audit.critical_issues + audit.warnings,
      status: 'connected',
    });

    return Response.json({ success: true, audit });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});