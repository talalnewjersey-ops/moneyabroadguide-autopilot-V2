import React from 'react';
import SeoArticleLayout from '@/components/seo/SeoArticleLayout';
import { articlePages } from '@/lib/seoPages';

export default function BestMoneyTransferAppsInCanada2026() {
  return <SeoArticleLayout page={articlePages.BestMoneyTransferAppsInCanada2026} />;
}