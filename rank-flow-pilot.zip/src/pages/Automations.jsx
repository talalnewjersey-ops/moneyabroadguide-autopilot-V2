import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Zap, Clock, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import { format } from 'date-fns';

const automationSchedule = [
  { name: 'Daily SEO Scan', frequency: 'Every day', type: 'site_scan', description: 'Crawls your website and detects new SEO issues' },
  { name: 'Keyword Discovery', frequency: 'Every day', type: 'keyword_discovery', description: 'Discovers new keyword opportunities from trends' },
  { name: 'Competitor Monitoring', frequency: 'Every day', type: 'competitor_analysis', description: 'Tracks competitor content changes and new pages' },
  { name: 'Content Refresh Check', frequency: 'Every day', type: 'content_optimization', description: 'Identifies stale content needing updates' },
  { name: 'Weekly Performance Report', frequency: 'Every week', type: 'report_generation', description: 'Generates comprehensive SEO performance summary' },
  { name: 'Backlink Opportunity Scan', frequency: 'Every week', type: 'backlink_discovery', description: 'Discovers new link building opportunities' },
];

export default function Automations() {
  const { data: websites = [] } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 1),
  });

  const activeWebsite = websites[0];

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ['automation-logs', activeWebsite?.id],
    queryFn: () => base44.entities.AutomationLog.filter({ website_id: activeWebsite.id }, '-created_date', 20),
    enabled: !!activeWebsite,
  });

  const statusIcon = {
    running: <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />,
    completed: <CheckCircle2 className="w-4 h-4 text-green-500" />,
    failed: <AlertCircle className="w-4 h-4 text-red-500" />,
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Automations" description="Automated SEO optimization tasks running in the background" />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {automationSchedule.map((auto, i) => (
          <Card key={i} className="hover:shadow-sm transition-shadow">
            <CardContent className="p-5">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                  <Zap className="w-4 h-4 text-blue-500" />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-semibold text-gray-900">{auto.name}</h3>
                  <div className="flex items-center gap-1 mt-0.5">
                    <Clock className="w-3 h-3 text-gray-400" />
                    <span className="text-xs text-gray-400">{auto.frequency}</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">{auto.description}</p>
                </div>
                <Badge className="bg-green-50 text-green-700 text-[10px]">Active</Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {logs.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Recent Activity</h3>
          <div className="space-y-2">
            {logs.map(log => (
              <div key={log.id} className="flex items-center gap-3 p-3 rounded-xl bg-gray-50/50 hover:bg-gray-50 transition-colors">
                {statusIcon[log.status] || statusIcon.completed}
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-800">{log.task_type?.replace(/_/g, ' ')}</p>
                  {log.details && <p className="text-xs text-gray-400 truncate">{log.details}</p>}
                </div>
                <span className="text-xs text-gray-400">{format(new Date(log.created_date), 'MMM d, HH:mm')}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}