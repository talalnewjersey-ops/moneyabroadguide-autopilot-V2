import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function CompetitorAnalysis() {
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const queryClient = useQueryClient();
  const { data: websites = [] } = useQuery({ queryKey: ['websites'], queryFn: () => base44.entities.Website.list('-created_date', 1) });
  const { data: competitors = [] } = useQuery({ queryKey: ['competitor-analysis'], queryFn: () => base44.entities.Competitor.list('-created_date', 100) });

  const createCompetitor = async () => {
    if (!websites[0] || !url) return;
    await base44.entities.Competitor.create({ website_id: websites[0].id, competitor_url: url, name: name || url.replace(/^https?:\/\//, '') });
    setName('');
    setUrl('');
    queryClient.invalidateQueries({ queryKey: ['competitor-analysis'] });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Competitor Analysis" description="Track gap-closing opportunities, content coverage, and competing domains." />
      <div className="grid md:grid-cols-3 gap-3"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Competitor name" className="rounded-xl" /><Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://competitor.com" className="rounded-xl" /><Button onClick={createCompetitor} className="rounded-xl bg-blue-600 hover:bg-blue-700">Add Competitor</Button></div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{competitors.map((item) => <Card key={item.id}><CardContent className="p-5"><h3 className="font-semibold text-gray-900">{item.name}</h3><p className="text-sm text-gray-500 mt-1">{item.competitor_url}</p></CardContent></Card>)}</div>
    </div>
  );
}