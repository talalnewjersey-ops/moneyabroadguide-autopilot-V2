import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import PageHeader from '../components/common/PageHeader';

export default function ActivityLogs() {
  const { data: items = [] } = useQuery({ queryKey: ['activity-logs'], queryFn: () => base44.entities.ActivityLog.list('-created_date', 100) });
  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Activity Logs" description="See operational history across workspaces, content, websites, and automation actions." />
      <div className="space-y-2">{items.map((item) => <div key={item.id} className="bg-white rounded-2xl border border-gray-100 p-4"><p className="text-sm font-medium text-gray-900">{item.action_type}</p><p className="text-sm text-gray-600 mt-1">{item.description}</p><p className="text-xs text-gray-400 mt-2">{item.entity_type || 'general'}</p></div>)}</div>
    </div>
  );
}