import { useEffect } from 'react';

export default function SeoFaqSchema({ items = [] }) {
  useEffect(() => {
    if (!items.length) return;

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: items.map((item) => ({
        '@type': 'Question',
        name: item.question,
        acceptedAnswer: {
          '@type': 'Answer',
          text: item.answer,
        },
      })),
    });

    document.head.appendChild(script);
    return () => document.head.removeChild(script);
  }, [items]);

  return null;
}