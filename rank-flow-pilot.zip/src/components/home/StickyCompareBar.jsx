import React from 'react';
import { ArrowRight, Globe2 } from 'lucide-react';

export default function StickyCompareBar() {
  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 md:left-auto md:right-6 md:w-auto">
      <a href="#compare" className="cta-primary flex h-14 items-center justify-center gap-2 px-6 text-sm shadow-[0_20px_45px_rgba(31,143,106,0.35)] md:text-base">
        <Globe2 className="h-4 w-4" />
        Find the Cheapest Transfer Now
        <ArrowRight className="h-4 w-4" />
      </a>
    </div>
  );
}