import React, { useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, ArrowUpDown } from 'lucide-react';
import { transferServices } from '@/lib/homepageData';
import { sortTransferServices } from '@/lib/transferCalculator';

const columns = [
  { key: 'service', label: 'Service', sortable: false },
  { key: 'fees', label: 'Fees', sortable: true },
  { key: 'speed', label: 'Speed', sortable: true },
  { key: 'exchangeRate', label: 'Exchange Rate', sortable: false },
  { key: 'rating', label: 'Rating', sortable: true },
  { key: 'action', label: 'Action', sortable: false },
];

export default function TransferComparisonTable({ services = transferServices }) {
  const [sortBy, setSortBy] = useState('rating');
  const [sortDirection, setSortDirection] = useState('desc');

  const sortedServices = useMemo(() => sortTransferServices(services, sortBy, sortDirection), [services, sortBy, sortDirection]);

  const handleSort = (column) => {
    if (!column.sortable) return;
    const nextDirection = sortBy === column.key && sortDirection === 'asc' ? 'desc' : column.key === 'rating' ? 'desc' : 'asc';
    setSortBy(column.key);
    setSortDirection(nextDirection);
  };

  const renderSortIcon = (column) => {
    if (!column.sortable) return null;
    if (sortBy !== column.key) return <ArrowUpDown className="h-4 w-4" />;
    return sortDirection === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />;
  };

  return (
    <div className="fintech-card overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-[860px] w-full text-left text-sm">
          <thead className="sticky top-0 z-10 bg-[#0B1F3A] text-white">
            <tr>
              {columns.map((column) => (
                <th key={column.key} className="px-5 py-4 font-semibold">
                  {column.sortable ? (
                    <button type="button" onClick={() => handleSort(column)} className="inline-flex items-center gap-2 transition hover:text-white/80">
                      {column.label}
                      {renderSortIcon(column)}
                    </button>
                  ) : (
                    column.label
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedServices.map((service, index) => (
              <tr key={service.name} className={`border-t border-slate-200 align-middle transition hover:bg-[#F4F8FB] ${index % 2 === 0 ? 'bg-white' : 'bg-slate-50/60'}`}>
                <td className="px-5 py-5 font-semibold text-slate-950">{service.name}</td>
                <td className="px-5 py-5 text-slate-600">{service.fees}</td>
                <td className="px-5 py-5 text-slate-600">{service.speed}</td>
                <td className="px-5 py-5 text-slate-600">{service.exchangeRate}</td>
                <td className="px-5 py-5 font-semibold text-slate-900">{service.rating}</td>
                <td className="px-5 py-5">
                  <a href={service.href} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center rounded-full bg-black px-5 py-3 text-sm font-semibold text-white transition hover:opacity-90">
                    View Deal
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}