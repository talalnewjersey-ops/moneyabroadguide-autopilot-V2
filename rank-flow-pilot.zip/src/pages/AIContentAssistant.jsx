import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { FileText, Sparkles, PenSquare, Wand2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function AIContentAssistant() {
  const { data: briefs = [] } = useQuery({ queryKey: ['content-briefs'], queryFn: () => base44.entities.ContentBrief.list('-created_date', 50) });
  const { data: drafts = [] } = useQuery({ queryKey: ['content-drafts'], queryFn: () => base44.entities.ContentDraft.list('-created_date', 50) });
  const modules = [
    { icon: Sparkles, title: 'Generate SEO briefs', value: briefs.length, path: '/ArticleGenerator' },
    { icon: PenSquare, title: 'Create long-form drafts', value: drafts.length, path: '/ArticleGenerator' },
    { icon: Wand2, title: 'Refresh old pages', value: 'Auto', path: '/ContentOptimizer' },
    { icon: FileText, title: 'Build keyword content maps', value: 'Ready', path: '/KeywordClusters' },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="AI Content Assistant" description="Generate briefs, drafts, refresh blocks, and WordPress-ready content workflows." />
      <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4">{modules.map((item) => <Link key={item.title} to={item.path}><Card className="hover:shadow-sm transition-shadow"><CardContent className="p-5"><item.icon className="w-5 h-5 text-blue-600 mb-3" /><p className="text-sm text-gray-500">{item.title}</p><p className="text-2xl font-semibold text-gray-900 mt-2">{item.value}</p></CardContent></Card></Link>)}</div>
    </div>
  );
}