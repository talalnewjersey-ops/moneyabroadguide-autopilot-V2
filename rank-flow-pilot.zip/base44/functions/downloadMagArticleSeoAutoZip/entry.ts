import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';
import JSZip from 'npm:jszip@3.10.1';

const pluginPhp = String.raw`<?php
/**
 * Plugin Name: MAG Article SEO Auto
 * Description: Automatically adds author bio, affiliate disclosure, disclaimer, and core SEO meta/schema to new MoneyAbroadGuide articles.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) exit;

class MAG_Article_SEO_Auto {
    public function __construct() {
        add_action('save_post_post', [$this, 'fill_post_seo_fields'], 20, 3);
        add_filter('the_content', [$this, 'append_article_footer'], 20);
        add_action('wp_head', [$this, 'output_post_meta_tags'], 5);
        add_filter('pre_get_document_title', [$this, 'filter_document_title'], 20);
    }

    private function author_bio_html() {
        return '<div class="mag-author-footer-box">'
            . '<h3>About Talal Eddaouahiri</h3>'
            . '<p>Talal Eddaouahiri is a financial advisor specialising in the financial systems of the United States and Canada. He founded Money Abroad Guide to provide honest, jargon-free guidance for immigrants, international students, and expats building their new lives in North America. With a focus on practical, real-world advice, Talal helps newcomers build their financial future — from opening a first bank account to understanding credit, taxes, and everyday money decisions — with confidence.</p>'
            . '<p class="mag-article-disclosure">This article may contain affiliate links. We may earn a commission at no extra cost to you. This does not influence our editorial assessments.</p>'
            . '<p class="mag-article-disclaimer">This content is for educational purposes only and should not be considered financial, legal, or tax advice.</p>'
            . '</div>';
    }

    public function append_article_footer($content) {
        if (is_admin() || !is_singular('post') || !in_the_loop() || !is_main_query()) {
            return $content;
        }

        if (strpos($content, 'mag-author-footer-box') !== false) {
            return $content;
        }

        return $content . $this->author_bio_html();
    }

    public function fill_post_seo_fields($post_id, $post, $update) {
        if (wp_is_post_revision($post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) return;
        if ($post->post_status !== 'publish' && $post->post_status !== 'draft') return;

        $title = get_the_title($post_id);
        $plain_content = wp_strip_all_tags($post->post_content);
        $description = wp_trim_words($plain_content, 28, '...');

        if (!get_post_meta($post_id, '_yoast_wpseo_title', true)) {
            update_post_meta($post_id, '_yoast_wpseo_title', $title . ' – Money Abroad Guide');
        }

        if (!get_post_meta($post_id, '_yoast_wpseo_metadesc', true)) {
            update_post_meta($post_id, '_yoast_wpseo_metadesc', $description);
        }

        if (!has_excerpt($post_id)) {
            wp_update_post([
                'ID' => $post_id,
                'post_excerpt' => $description,
            ]);
        }
    }

    public function filter_document_title($title) {
        if (is_singular('post')) {
            return wp_strip_all_tags(get_the_title()) . ' – Money Abroad Guide';
        }
        return $title;
    }

    private function logo_url() {
        $custom_logo_id = get_theme_mod('custom_logo');
        if ($custom_logo_id) {
            $logo = wp_get_attachment_image_url($custom_logo_id, 'full');
            if ($logo) return $logo;
        }
        return 'https://media.base44.com/images/public/69b0e5e335d4b05b71b39d24/7807cf1df_logoMoneyabroadGuide.jpeg';
    }

    private function breadcrumb_schema() {
        $items = [[
            '@type' => 'ListItem',
            'position' => 1,
            'name' => 'Home',
            'item' => home_url('/'),
        ]];

        $categories = get_the_category();
        if (!empty($categories)) {
            $items[] = [
                '@type' => 'ListItem',
                'position' => 2,
                'name' => $categories[0]->name,
                'item' => get_category_link($categories[0]->term_id),
            ];
            $pos = 3;
        } else {
            $pos = 2;
        }

        $items[] = [
            '@type' => 'ListItem',
            'position' => $pos,
            'name' => get_the_title(),
            'item' => get_permalink(),
        ];

        return [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $items,
        ];
    }

    private function article_schema() {
        global $post;
        $image = get_the_post_thumbnail_url($post, 'full') ?: $this->logo_url();
        $author = get_the_author_meta('display_name', $post->post_author) ?: 'Talal Eddaouahiri';

        return [
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            'headline' => wp_strip_all_tags(get_the_title($post)),
            'datePublished' => get_the_date('c', $post),
            'dateModified' => get_the_modified_date('c', $post),
            'author' => [
                '@type' => 'Person',
                'name' => $author,
            ],
            'publisher' => [
                '@type' => 'Organization',
                'name' => 'Money Abroad Guide',
                'logo' => [
                    '@type' => 'ImageObject',
                    'url' => $this->logo_url(),
                ],
            ],
            'image' => [$image],
            'mainEntityOfPage' => get_permalink($post),
            'description' => wp_strip_all_tags(get_the_excerpt($post) ?: get_bloginfo('description')),
        ];
    }

    private function howto_schema() {
        if (stripos(get_the_title(), 'how to') === false) return null;

        return [
            '@context' => 'https://schema.org',
            '@type' => 'HowTo',
            'name' => get_the_title(),
            'description' => wp_strip_all_tags(get_the_excerpt() ?: get_bloginfo('description')),
            'step' => [
                ['@type' => 'HowToStep', 'name' => 'Review the options', 'text' => 'Read the guide carefully and understand the required steps.'],
                ['@type' => 'HowToStep', 'name' => 'Prepare the right documents', 'text' => 'Use the article checklist to prepare the documents and information you need.'],
                ['@type' => 'HowToStep', 'name' => 'Apply the advice carefully', 'text' => 'Follow the practical recommendations and verify details with the official source or provider.'],
            ],
        ];
    }

    public function output_post_meta_tags() {
        if (!is_singular('post')) return;

        global $post;
        $title = wp_strip_all_tags(get_the_title($post)) . ' – Money Abroad Guide';
        $description = get_post_meta($post->ID, '_yoast_wpseo_metadesc', true) ?: wp_strip_all_tags(get_the_excerpt($post) ?: get_bloginfo('description'));
        $image = get_the_post_thumbnail_url($post, 'full') ?: $this->logo_url();
        $canonical = get_permalink($post);

        echo '<meta name="description" content="' . esc_attr($description) . '">';
        echo '<meta property="og:title" content="' . esc_attr($title) . '">';
        echo '<meta property="og:description" content="' . esc_attr($description) . '">';
        echo '<meta property="og:type" content="article">';
        echo '<meta property="og:url" content="' . esc_url($canonical) . '">';
        echo '<meta property="og:image" content="' . esc_url($image) . '">';
        echo '<meta name="twitter:card" content="summary_large_image">';
        echo '<meta name="twitter:title" content="' . esc_attr($title) . '">';
        echo '<meta name="twitter:description" content="' . esc_attr($description) . '">';
        echo '<meta name="twitter:image" content="' . esc_url($image) . '">';
        echo '<link rel="canonical" href="' . esc_url($canonical) . '" />';
        echo '<script type="application/ld+json">' . wp_json_encode($this->article_schema(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
        echo '<script type="application/ld+json">' . wp_json_encode($this->breadcrumb_schema(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';

        $howto = $this->howto_schema();
        if ($howto) {
            echo '<script type="application/ld+json">' . wp_json_encode($howto, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
        }

        echo '<style>.mag-author-footer-box{margin-top:32px;padding:22px;border:1px solid #e2e8f0;border-radius:20px;background:#f8fafc}.mag-author-footer-box h3{margin:0 0 12px;color:#0f172a;font-size:22px}.mag-author-footer-box p{margin:0 0 12px;line-height:1.8;color:#475569}.mag-author-footer-box p:last-child{margin-bottom:0}.mag-article-disclosure{font-weight:600}.mag-article-disclaimer{color:#64748b}</style>';
    }
}

new MAG_Article_SEO_Auto();`;

async function buildZip() {
  const zip = new JSZip();
  const folder = zip.folder('mag-article-seo-auto');
  folder.file('mag-article-seo-auto.php', pluginPhp);
  return await zip.generateAsync({ type: 'uint8array' });
}

Deno.serve(async (req) => {
  try {
    const zipContent = await buildZip();

    if (req.method === 'GET') {
      return new Response(zipContent, {
        status: 200,
        headers: {
          'Content-Type': 'application/zip',
          'Content-Disposition': 'attachment; filename="mag-article-seo-auto.zip"',
          'Cache-Control': 'no-store',
        },
      });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const zipFile = new File([zipContent], 'mag-article-seo-auto.zip', { type: 'application/zip' });
    const upload = await base44.asServiceRole.integrations.Core.UploadFile({ file: zipFile });

    return Response.json({
      success: true,
      file_name: 'mag-article-seo-auto.zip',
      folder_name: 'mag-article-seo-auto',
      files: ['mag-article-seo-auto.php'],
      file_url: upload.file_url,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});