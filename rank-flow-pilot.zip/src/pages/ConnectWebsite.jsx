import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function ConnectWebsite() {
  const [domain, setDomain] = useState('');
  const [name, setName] = useState('');
  const queryClient = useQueryClient();
  const { data: projects = [] } = useQuery({ queryKey: ['projects'], queryFn: () => base44.entities.Project.list('-created_date', 1) });
  const { data: websites = [] } = useQuery({ queryKey: ['websites'], queryFn: () => base44.entities.Website.list('-created_date', 50) });

  const connectWebsite = async () => {
    if (!domain || !projects[0]) return;
    const cleanDomain = domain.replace(/^https?:\/\//, '');
    await base44.entities.Website.create({
      project_id: projects[0].id,
      workspace_id: projects[0].workspace_id,
      name: name || cleanDomain,
      domain: cleanDomain,
      url: `https://${cleanDomain}`,
      cms_type: 'wordpress',
      niche: 'expat finance',
      language: 'English',
      country: 'USA and Canada',
      project_api_key: projects[0].project_api_key,
      wordpress_connection_status: 'pending',
      status: 'connected',
      auto_mode: projects[0].auto_mode || 'assisted'
    });
    setDomain('');
    setName('');
    queryClient.invalidateQueries({ queryKey: ['websites'] });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Connect Website" description="Add domains, prepare WordPress handshakes, and store market targeting data." />
      <div className="grid md:grid-cols-3 gap-3"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Website name" className="rounded-xl" /><Input value={domain} onChange={(e) => setDomain(e.target.value)} placeholder="moneyabroadguide.com" className="rounded-xl" /><Button onClick={connectWebsite} className="rounded-xl bg-blue-600 hover:bg-blue-700">Connect Website</Button></div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{websites.map((website) => <Card key={website.id}><CardContent className="p-5"><h3 className="font-semibold text-gray-900">{website.name}</h3><p className="text-sm text-gray-500 mt-1">{website.url}</p><p className="text-xs text-gray-400 mt-2">{website.country} · {website.language} · {website.cms_type}</p></CardContent></Card>)}</div>
    </div>
  );
}