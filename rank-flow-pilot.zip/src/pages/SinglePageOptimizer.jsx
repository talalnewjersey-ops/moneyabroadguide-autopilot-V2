import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import PageHeader from '../components/common/PageHeader';

export default function SinglePageOptimizer() {
  const { data: pages = [] } = useQuery({ queryKey: ['pages-single-optimizer'], queryFn: () => base44.entities.Page.list('-updated_date', 100) });
  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Single Page Optimizer" description="Review each page score, content status, and manual or automatic actions." />
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{pages.map((page) => <div key={page.id} className="bg-white rounded-2xl border border-gray-100 p-5"><p className="text-sm font-semibold text-gray-900 break-all">{page.url}</p><p className="text-xs text-gray-400 mt-2">SEO score: {page.seo_score ?? '—'} · Content score: {page.content_score ?? '—'}</p></div>)}</div>
    </div>
  );
}