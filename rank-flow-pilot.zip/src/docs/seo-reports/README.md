# SEO Reports

This folder stores generated dry-run SEO reports from GitHub Actions.

Subfolders:
- `daily/`
- `weekly/`
- `articles/`

These outputs are safe to review in pull requests before any manual production step.