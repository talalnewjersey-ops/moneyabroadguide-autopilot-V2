import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import OpenAI from 'npm:openai@4.104.0';

const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY') });
const normalizeUrl = (url = '') => url.toLowerCase().trim().replace(/\/$/, '');
const toText = (value = '') => typeof value === 'string' ? value : value == null ? '' : String(value);
const toArray = (value) => Array.isArray(value) ? value : [];

const getWebsite = async (base44, siteUrl, apiKey) => {
  const websites = await base44.asServiceRole.entities.Website.list();
  return websites.find((item) => normalizeUrl(item.url) === normalizeUrl(siteUrl) && item.wordpress_api_key === apiKey);
};

const askOpenAI = async (prompt) => {
  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: 'You are an expert SEO copywriter using ChatGPT. Return only valid JSON with no markdown.'
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
  });

  return JSON.parse(response.choices[0]?.message?.content || '{}');
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'optimizePage', required_fields: ['site_url', 'api_key', 'page'] });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.site_url || !payload.api_key || !payload.page) {
      return Response.json({ endpoint: 'optimizePage', required_fields: ['site_url', 'api_key', 'page'] });
    }

    const website = await getWebsite(base44, payload.site_url, payload.api_key);
    if (!website) {
      return Response.json({ error: 'Unauthorized WordPress connection.' }, { status: 403 });
    }

    const rawResult = await askOpenAI(`Optimize this page for SEO and EEAT: ${JSON.stringify(payload.page)}. Return JSON with keys: optimized_title, optimized_meta_description, faq_items, internal_link_suggestions, trust_section, author_box. faq_items must be an array of objects with question and answer.`);

    const result = {
      optimized_title: toText(rawResult.optimized_title),
      optimized_meta_description: toText(rawResult.optimized_meta_description),
      faq_items: toArray(rawResult.faq_items).map((item) => ({
        question: toText(item.question),
        answer: toText(item.answer),
      })).filter((item) => item.question && item.answer),
      internal_link_suggestions: toArray(rawResult.internal_link_suggestions).map((item) => toText(item)).filter(Boolean),
      trust_section: toText(rawResult.trust_section),
      author_box: toText(rawResult.author_box),
    };

    return Response.json({ success: true, page_url: payload.page.url, optimization: result });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});