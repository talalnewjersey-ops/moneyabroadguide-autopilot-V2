/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Dashboard from './pages/Dashboard';
import AppSettings from './pages/AppSettings';
import SiteAudit from './pages/SiteAudit';
import ContentOptimizer from './pages/ContentOptimizer';
import KeywordCenter from './pages/KeywordCenter';
import Competitors from './pages/Competitors';
import InternalLinks from './pages/InternalLinks';
import Backlinks from './pages/Backlinks';
import EEAT from './pages/EEAT';
import Automations from './pages/Automations';
import Reports from './pages/Reports';
import OptimizeFlow from './pages/OptimizeFlow';
import WordPressPlugin from './pages/WordPressPlugin';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Dashboard": Dashboard,
    "AppSettings": AppSettings,
    "SiteAudit": SiteAudit,
    "ContentOptimizer": ContentOptimizer,
    "KeywordCenter": KeywordCenter,
    "Competitors": Competitors,
    "InternalLinks": InternalLinks,
    "Backlinks": Backlinks,
    "EEAT": EEAT,
    "Automations": Automations,
    "Reports": Reports,
    "OptimizeFlow": OptimizeFlow,
    "WordPressPlugin": WordPressPlugin,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};