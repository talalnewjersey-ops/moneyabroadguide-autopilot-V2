import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const workspace = await base44.asServiceRole.entities.Workspace.create({
      name: 'North America Finance Lab',
      slug: 'north-america-finance-lab',
      description: 'Demo workspace for expat finance SEO automation.',
      plan_status: 'growth',
      default_country: 'USA and Canada',
      default_language: 'English',
      usage_tokens: 0,
      onboarding_completed: true,
    });

    await base44.asServiceRole.entities.WorkspaceMember.create({
      workspace_id: workspace.id,
      user_email: user.email,
      role: 'owner',
      status: 'active',
    });

    const projectUs = await base44.asServiceRole.entities.Project.create({
      workspace_id: workspace.id,
      name: 'Money Abroad Guide USA',
      domain: 'moneyabroadguide.com',
      site_url: 'https://moneyabroadguide.com',
      cms_type: 'wordpress',
      niche: 'expat finance',
      language: 'English',
      country: 'USA',
      project_api_key: crypto.randomUUID().replace(/-/g, ''),
      wordpress_connection_status: 'connected',
      auto_mode: 'assisted',
      ai_model: 'gpt-4o-mini',
      ai_temperature: 0.7,
      ai_max_tokens: 4000,
    });

    const projectCa = await base44.asServiceRole.entities.Project.create({
      workspace_id: workspace.id,
      name: 'Newcomer Finance Canada',
      domain: 'newcomerfinancecanada.com',
      site_url: 'https://newcomerfinancecanada.com',
      cms_type: 'wordpress',
      niche: 'newcomer finance',
      language: 'English',
      country: 'Canada',
      project_api_key: crypto.randomUUID().replace(/-/g, ''),
      wordpress_connection_status: 'pending',
      auto_mode: 'manual',
      ai_model: 'gpt-4o-mini',
      ai_temperature: 0.7,
      ai_max_tokens: 4000,
    });

    const websiteUs = await base44.asServiceRole.entities.Website.create({
      project_id: projectUs.id,
      workspace_id: workspace.id,
      name: 'Money Abroad Guide',
      domain: 'moneyabroadguide.com',
      url: 'https://moneyabroadguide.com',
      cms_type: 'wordpress',
      niche: 'expat finance',
      language: 'English',
      country: 'USA',
      project_api_key: projectUs.project_api_key,
      wordpress_connection_status: 'connected',
      status: 'connected',
      seo_score: 74,
      total_pages: 18,
      total_issues: 12,
      auto_mode: 'assisted',
    });

    const websiteCa = await base44.asServiceRole.entities.Website.create({
      project_id: projectCa.id,
      workspace_id: workspace.id,
      name: 'Newcomer Finance Canada',
      domain: 'newcomerfinancecanada.com',
      url: 'https://newcomerfinancecanada.com',
      cms_type: 'wordpress',
      niche: 'newcomer finance',
      language: 'English',
      country: 'Canada',
      project_api_key: projectCa.project_api_key,
      wordpress_connection_status: 'pending',
      status: 'connected',
      seo_score: 61,
      total_pages: 9,
      total_issues: 7,
      auto_mode: 'manual',
    });

    await base44.asServiceRole.entities.AuditIssue.bulkCreate([
      { project_id: projectUs.id, website_id: websiteUs.id, page_url: 'https://moneyabroadguide.com/best-banks-for-newcomers', issue_type: 'missing_alt_text', severity: 'warning', priority: 'high', description: 'Images are missing descriptive ALT text.', recommended_fix: 'Generate descriptive ALT text for all images.', auto_fixable: true, generate_fix_available: true, apply_fix_available: true, status: 'open' },
      { project_id: projectUs.id, website_id: websiteUs.id, page_url: 'https://moneyabroadguide.com/how-to-open-a-bank-account-in-the-us', issue_type: 'meta_description_too_short', severity: 'warning', priority: 'high', description: 'Meta description is too short and misses key intent.', recommended_fix: 'Generate a richer meta description with expat search intent.', auto_fixable: true, generate_fix_available: true, apply_fix_available: true, status: 'open' },
      { project_id: projectCa.id, website_id: websiteCa.id, page_url: 'https://newcomerfinancecanada.com/credit-score-guide', issue_type: 'thin_content', severity: 'critical', priority: 'high', description: 'The page needs more practical content depth.', recommended_fix: 'Add a full beginner guide with steps, examples, and FAQs.', auto_fixable: false, generate_fix_available: true, apply_fix_available: false, status: 'open' }
    ]);

    await base44.asServiceRole.entities.KeywordCluster.bulkCreate([
      { project_id: projectUs.id, name: 'Best Banks for Newcomers', primary_keyword: 'best banks for immigrants in usa', secondary_keywords: ['best bank for new immigrants', 'checking account for newcomers'], intent: 'commercial', priority: 'high', status: 'planned' },
      { project_id: projectCa.id, name: 'Credit Building in Canada', primary_keyword: 'how to build credit in canada as a newcomer', secondary_keywords: ['secured credit card canada newcomer', 'canada credit history'], intent: 'informational', priority: 'high', status: 'planned' }
    ]);

    await base44.asServiceRole.entities.ContentBrief.bulkCreate([
      { project_id: projectUs.id, title: 'Best Banks for Newcomers in the USA', primary_keyword: 'best banks for immigrants in usa', secondary_keywords: ['checking account for newcomers', 'best bank for immigrants'], search_intent: 'commercial', audience: 'immigrants and expats', country: 'USA', tone: 'helpful expert', outline: 'Intro\nBest bank options\nFees\nHow to choose\nFAQs', faq_queries: ['Can a new immigrant open a bank account in the USA?', 'Which bank is easiest for newcomers?'], internal_link_targets: ['https://moneyabroadguide.com/how-to-open-a-bank-account-in-the-us'], status: 'ready' },
      { project_id: projectCa.id, title: 'How to Build Credit in Canada as a Newcomer', primary_keyword: 'how to build credit in canada as a newcomer', secondary_keywords: ['secured credit card canada newcomer'], search_intent: 'informational', audience: 'newcomers and students', country: 'Canada', tone: 'clear guide', outline: 'Intro\nHow credit works\nFirst steps\nBest products\nFAQs', faq_queries: ['Can I build credit without a job?', 'How long does it take?'], internal_link_targets: ['https://newcomerfinancecanada.com/newcomer-bank-accounts'], status: 'ready' }
    ]);

    await base44.asServiceRole.entities.ContentDraft.bulkCreate([
      { project_id: projectUs.id, title: 'Best Banks for Immigrants in the USA', slug: 'best-banks-for-immigrants-usa', excerpt: 'A complete guide to choosing the right bank as a newcomer in the United States.', primary_keyword: 'best banks for immigrants in usa', secondary_keywords: ['best bank for newcomers', 'checking account immigrants'], article_type: 'guide', tone: 'helpful expert', country: 'USA', language: 'English', meta_title: 'Best Banks for Immigrants in the USA (2026 Guide)', meta_description: 'Compare the best banks for immigrants in the USA and learn how to open your first account with fewer fees.', html_content: '<h1>Best Banks for Immigrants in the USA</h1><p>This is a demo article draft ready for WordPress.</p>', table_of_contents: ['Best bank features', 'Fees', 'Who each bank fits best'], faq_html: '<h2>FAQs</h2><p><strong>Can immigrants open a bank account?</strong> Yes.</p>', schema_markup: '{"@context":"https://schema.org"}', wordpress_status: 'not_sent', status: 'ready' }
    ]);

    await base44.asServiceRole.entities.Competitor.bulkCreate([
      { website_id: websiteUs.id, competitor_url: 'https://wise.com/us/blog', name: 'Wise Blog', avg_article_length: 2200, keyword_overlap: 38, strengths: ['Brand visibility', 'Strong comparisons'], weaknesses: ['Limited newcomer banking depth'], last_analyzed: new Date().toISOString() },
      { website_id: websiteCa.id, competitor_url: 'https://www.koho.ca/learn/', name: 'KOHO Learn', avg_article_length: 1800, keyword_overlap: 27, strengths: ['Strong educational flow'], weaknesses: ['Less expat-specific content'], last_analyzed: new Date().toISOString() }
    ]);

    await base44.asServiceRole.entities.Report.create({
      project_id: projectUs.id,
      report_type: 'executive',
      title: 'Weekly SEO Overview',
      summary: 'Demo report showing gains in metadata coverage and content planning.',
      report_json: JSON.stringify({ seo_score: 74, priorities: ['Fix metadata', 'Expand banking guides', 'Improve internal links'] }),
      report_period: 'weekly',
      status: 'generated'
    });

    return Response.json({ success: true, workspace_id: workspace.id, projects_created: 2, websites_created: 2, message: 'Demo data created successfully.' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});