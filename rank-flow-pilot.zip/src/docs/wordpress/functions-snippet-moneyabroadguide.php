<?php
/**
 * Money Abroad Guide SEO + Schema + Meta Snippet
 * Paste into Code Snippets (run everywhere)
 */

if (!defined('ABSPATH')) {
    exit;
}

function mag_is_home_context() {
    return is_front_page() || is_home();
}

function mag_get_site_logo_url() {
    $custom_logo_id = get_theme_mod('custom_logo');
    if ($custom_logo_id) {
        $logo = wp_get_attachment_image_url($custom_logo_id, 'full');
        if ($logo) return $logo;
    }
    return 'https://moneyabroadguide.com/wp-content/uploads/2026/01/logo-moneyabroadguide.png';
}

function mag_get_primary_category_name($post_id) {
    $terms = get_the_category($post_id);
    return !empty($terms) ? $terms[0]->name : 'Guides';
}

function mag_build_breadcrumb_schema() {
    $items = [[
        '@type' => 'ListItem',
        'position' => 1,
        'name' => 'Home',
        'item' => home_url('/'),
    ]];

    if (is_singular('post')) {
        $items[] = [
            '@type' => 'ListItem',
            'position' => 2,
            'name' => mag_get_primary_category_name(get_the_ID()),
            'item' => get_permalink(get_the_ID()),
        ];
        $items[] = [
            '@type' => 'ListItem',
            'position' => 3,
            'name' => get_the_title(),
            'item' => get_permalink(),
        ];
    } elseif (is_page()) {
        $items[] = [
            '@type' => 'ListItem',
            'position' => 2,
            'name' => get_the_title(),
            'item' => get_permalink(),
        ];
    }

    return [
        '@context' => 'https://schema.org',
        '@type' => 'BreadcrumbList',
        'itemListElement' => $items,
    ];
}

function mag_build_article_schema() {
    if (!is_singular('post')) return null;

    global $post;
    $image = get_the_post_thumbnail_url($post, 'full') ?: mag_get_site_logo_url();
    $author_name = get_the_author_meta('display_name', $post->post_author) ?: 'Money Abroad Guide Editorial Team';

    return [
        '@context' => 'https://schema.org',
        '@type' => 'Article',
        'headline' => wp_strip_all_tags(get_the_title($post)),
        'datePublished' => get_the_date('c', $post),
        'dateModified' => get_the_modified_date('c', $post),
        'author' => [
            '@type' => 'Person',
            'name' => $author_name,
        ],
        'publisher' => [
            '@type' => 'Organization',
            'name' => 'Money Abroad Guide',
            'logo' => [
                '@type' => 'ImageObject',
                'url' => mag_get_site_logo_url(),
            ],
        ],
        'image' => [$image],
        'mainEntityOfPage' => get_permalink($post),
        'description' => wp_strip_all_tags(get_the_excerpt($post) ?: get_bloginfo('description')),
    ];
}

function mag_build_howto_schema() {
    if (!is_singular('post')) return null;
    if (stripos(get_the_title(), 'how to') === false) return null;

    return [
        '@context' => 'https://schema.org',
        '@type' => 'HowTo',
        'name' => get_the_title(),
        'description' => wp_strip_all_tags(get_the_excerpt() ?: get_bloginfo('description')),
        'step' => [
            ['@type' => 'HowToStep', 'name' => 'Compare providers', 'text' => 'Review fees, exchange rates, and transfer speed before sending money.'],
            ['@type' => 'HowToStep', 'name' => 'Choose the best route', 'text' => 'Pick the provider and payout method that fits your amount and urgency.'],
            ['@type' => 'HowToStep', 'name' => 'Verify final value', 'text' => 'Confirm the amount received, total fee, and expected delivery time before completing the transfer.'],
        ],
    ];
}

function mag_output_homepage_schema() {
    if (!mag_is_home_context()) return;

    $website_schema = [
        '@context' => 'https://schema.org',
        '@type' => 'WebSite',
        'name' => 'Money Abroad Guide',
        'url' => home_url('/'),
        'potentialAction' => [
            '@type' => 'SearchAction',
            'target' => home_url('/?s={search_term_string}'),
            'query-input' => 'required name=search_term_string',
        ],
    ];

    $organization_schema = [
        '@context' => 'https://schema.org',
        '@type' => 'Organization',
        'name' => 'Money Abroad Guide',
        'url' => home_url('/'),
        'logo' => mag_get_site_logo_url(),
        'description' => 'International money transfer comparisons and financial guides for immigrants and expats in the USA and Canada.',
    ];

    $faq_schema = [
        '@context' => 'https://schema.org',
        '@type' => 'FAQPage',
        'mainEntity' => [
            [
                '@type' => 'Question',
                'name' => 'What is the cheapest way to send money abroad?',
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'The cheapest option depends on the amount, corridor, and payout method. Comparing fees and exchange rates together is the best way to find the strongest value.'],
            ],
            [
                '@type' => 'Question',
                'name' => 'Why does the exchange rate matter so much?',
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'A weak exchange rate can quietly cost more than the visible transfer fee, so users should compare the final amount received, not just the headline fee.'],
            ],
            [
                '@type' => 'Question',
                'name' => 'Are specialist transfer apps cheaper than banks?',
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'In many cases yes, because specialist providers often offer lower fees and better foreign exchange pricing than traditional banks.'],
            ],
            [
                '@type' => 'Question',
                'name' => 'How often should I compare transfer providers?',
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'You should compare providers each time you send money because promotional pricing, transfer fees, and exchange rates can change regularly.'],
            ],
        ],
    ];

    echo '<script type="application/ld+json">' . wp_json_encode($website_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
    echo '<script type="application/ld+json">' . wp_json_encode($organization_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
    echo '<script type="application/ld+json">' . wp_json_encode($faq_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}
add_action('wp_head', 'mag_output_homepage_schema', 5);

function mag_output_article_schema() {
    if (!is_singular('post')) return;

    $article = mag_build_article_schema();
    $breadcrumb = mag_build_breadcrumb_schema();
    $howto = mag_build_howto_schema();

    if ($article) {
        echo '<script type="application/ld+json">' . wp_json_encode($article, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
    }

    echo '<script type="application/ld+json">' . wp_json_encode($breadcrumb, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';

    if ($howto) {
        echo '<script type="application/ld+json">' . wp_json_encode($howto, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
    }
}
add_action('wp_head', 'mag_output_article_schema', 6);

function mag_output_meta_tags() {
    if (is_admin()) return;

    if (mag_is_home_context()) {
        $title = 'Money Abroad Guide: Compare International Money Transfers for Immigrants & Expats';
        $description = 'Compare international money transfer fees, exchange rates, and delivery times for immigrants and expats in the USA and Canada.';
        $url = home_url('/');
    } elseif (is_singular()) {
        $title = wp_strip_all_tags(get_the_title()) . ' – Money Abroad Guide';
        $description = wp_strip_all_tags(get_the_excerpt() ?: get_bloginfo('description'));
        $url = get_permalink();
    } else {
        $title = wp_get_document_title();
        $description = get_bloginfo('description');
        $url = home_url(add_query_arg([], $GLOBALS['wp']->request ?? ''));
    }

    $image = is_singular() ? (get_the_post_thumbnail_url(get_the_ID(), 'full') ?: mag_get_site_logo_url()) : mag_get_site_logo_url();

    echo '<meta property="og:title" content="' . esc_attr($title) . '">';
    echo '<meta property="og:description" content="' . esc_attr($description) . '">';
    echo '<meta property="og:type" content="' . (is_singular('post') ? 'article' : 'website') . '">';
    echo '<meta property="og:url" content="' . esc_url($url) . '">';
    echo '<meta property="og:image" content="' . esc_url($image) . '">';
    echo '<meta name="twitter:card" content="summary_large_image">';
    echo '<meta name="twitter:title" content="' . esc_attr($title) . '">';
    echo '<meta name="twitter:description" content="' . esc_attr($description) . '">';
    echo '<meta name="twitter:image" content="' . esc_url($image) . '">';
}
add_action('wp_head', 'mag_output_meta_tags', 7);

function mag_output_canonical_url() {
    if (!is_singular()) return;
    echo '<link rel="canonical" href="' . esc_url(get_permalink()) . '" />';
}
add_action('wp_head', 'mag_output_canonical_url', 8);

function mag_filter_document_title($title) {
    if (mag_is_home_context()) {
        return 'Money Abroad Guide: Compare International Money Transfers for Immigrants & Expats';
    }

    if (is_singular('post')) {
        return wp_strip_all_tags(get_the_title()) . ' – Money Abroad Guide';
    }

    return $title;
}
add_filter('pre_get_document_title', 'mag_filter_document_title', 20);

function mag_top_banners($content) {
    if (!is_singular('post') || !in_the_loop() || !is_main_query()) return $content;

    $updated = get_the_modified_date('F j, Y');

    $banner = '<div class="mag-info-banner mag-updated-banner" role="note" aria-label="Article update notice">'
        . '<strong>Last updated:</strong> ' . esc_html($updated)
        . ' — Transfer fees and bank requirements change regularly — always verify directly with the provider.'</div>';

    $disclosure = '<div class="mag-info-banner mag-affiliate-banner" role="note" aria-label="Affiliate disclosure">'
        . 'This article may contain affiliate links. We may earn a commission at no extra cost to you. This does not influence our editorial assessments.'</div>';

    $disclaimer = '<div class="mag-info-banner mag-disclaimer-banner" role="note" aria-label="Not financial advice disclaimer">'
        . 'This content is for educational purposes only and should not be considered financial advice.'</div>';

    return $banner . $disclosure . $disclaimer . $content;
}
add_filter('the_content', 'mag_top_banners', 5);

function mag_banner_styles() {
    if (!is_singular('post')) return;
    echo '<style>
        .mag-info-banner{margin:0 0 16px;padding:14px 16px;border-radius:12px;line-height:1.7;font-size:14px}
        .mag-updated-banner{background:#eff6ff;border:1px solid #bfdbfe;color:#1e3a8a}
        .mag-affiliate-banner{background:#f8fafc;border:1px solid #cbd5e1;color:#334155}
        .mag-disclaimer-banner{background:#fefce8;border:1px solid #fde68a;color:#854d0e}
    </style>';
}
add_action('wp_head', 'mag_banner_styles', 20);