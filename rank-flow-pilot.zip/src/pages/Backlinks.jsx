import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Globe, Loader2, Sparkles, ExternalLink, Mail } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import EmptyState from '../components/common/EmptyState';
import { toast } from 'sonner';

export default function Backlinks() {
  const [discovering, setDiscovering] = useState(false);
  const queryClient = useQueryClient();

  const { data: websites = [] } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 1),
  });

  const activeWebsite = websites[0];

  const { data: opportunities = [], isLoading } = useQuery({
    queryKey: ['backlinks', activeWebsite?.id],
    queryFn: () => base44.entities.BacklinkOpportunity.filter({ website_id: activeWebsite.id }),
    enabled: !!activeWebsite,
  });

  const discover = async () => {
    if (!activeWebsite) return;
    setDiscovering(true);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Find backlink opportunities for ${activeWebsite.url}.
      
      Generate 8 realistic backlink opportunities including:
      - Guest post opportunities on relevant blogs
      - Directory listings
      - Partnership opportunities
      - Resource page opportunities
      - Broken link building opportunities
      
      For each, provide:
      - source_url, source_name, type (guest_post/directory/partnership/broken_link/resource_page)
      - relevance_score (0-100)
      - outreach_email: a brief outreach email template`,
      response_json_schema: {
        type: "object",
        properties: {
          opportunities: {
            type: "array",
            items: {
              type: "object",
              properties: {
                source_url: { type: "string" },
                source_name: { type: "string" },
                type: { type: "string" },
                relevance_score: { type: "number" },
                outreach_email: { type: "string" }
              }
            }
          }
        }
      },
      add_context_from_internet: true,
    });

    for (const opp of result.opportunities || []) {
      await base44.entities.BacklinkOpportunity.create({
        website_id: activeWebsite.id,
        ...opp,
        status: 'discovered',
      });
    }

    queryClient.invalidateQueries({ queryKey: ['backlinks'] });
    setDiscovering(false);
    toast.success('Backlink opportunities discovered!');
  };

  const updateStatus = async (id, status) => {
    await base44.entities.BacklinkOpportunity.update(id, { status });
    queryClient.invalidateQueries({ queryKey: ['backlinks'] });
  };

  if (!activeWebsite) {
    return <EmptyState icon={Globe} title="No website connected" description="Add a website in Settings first." />;
  }

  const typeColor = {
    guest_post: 'bg-purple-50 text-purple-700',
    directory: 'bg-blue-50 text-blue-700',
    partnership: 'bg-green-50 text-green-700',
    broken_link: 'bg-red-50 text-red-700',
    resource_page: 'bg-amber-50 text-amber-700',
  };

  const statusColor = {
    discovered: 'bg-gray-50 text-gray-600',
    contacted: 'bg-blue-50 text-blue-700',
    in_progress: 'bg-amber-50 text-amber-700',
    acquired: 'bg-green-50 text-green-700',
    rejected: 'bg-red-50 text-red-700',
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader
        title="Backlink Opportunities"
        description="Discover and manage link building opportunities"
        action={
          <Button onClick={discover} disabled={discovering} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
            {discovering ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {discovering ? 'Discovering...' : 'Discover Opportunities'}
          </Button>
        }
      />

      {opportunities.length === 0 && !isLoading ? (
        <EmptyState icon={Globe} title="No backlink opportunities" description="Click discover to find link building opportunities." action="Discover Now" onAction={discover} />
      ) : (
        <div className="space-y-3">
          {opportunities.map(opp => (
            <Card key={opp.id} className="hover:shadow-sm transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-50 to-cyan-50 flex items-center justify-center flex-shrink-0">
                    <Globe className="w-5 h-5 text-blue-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-sm font-semibold text-gray-900">{opp.source_name}</h3>
                      <Badge className={typeColor[opp.type] || 'bg-gray-50 text-gray-700'}>
                        {opp.type?.replace(/_/g, ' ')}
                      </Badge>
                    </div>
                    <a href={opp.source_url} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-500 hover:text-blue-600 flex items-center gap-1">
                      {opp.source_url} <ExternalLink className="w-3 h-3" />
                    </a>
                    {opp.relevance_score && (
                      <p className="text-xs text-gray-400 mt-1">Relevance: {opp.relevance_score}/100</p>
                    )}
                    {opp.outreach_email && (
                      <details className="mt-2">
                        <summary className="text-xs text-gray-500 cursor-pointer flex items-center gap-1 hover:text-gray-700">
                          <Mail className="w-3 h-3" /> View outreach template
                        </summary>
                        <p className="text-xs text-gray-600 mt-2 bg-gray-50 p-3 rounded-lg whitespace-pre-wrap">{opp.outreach_email}</p>
                      </details>
                    )}
                  </div>
                  <Select value={opp.status} onValueChange={(v) => updateStatus(opp.id, v)}>
                    <SelectTrigger className="w-32 h-8 text-xs rounded-lg">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="discovered">Discovered</SelectItem>
                      <SelectItem value="contacted">Contacted</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="acquired">Acquired</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}