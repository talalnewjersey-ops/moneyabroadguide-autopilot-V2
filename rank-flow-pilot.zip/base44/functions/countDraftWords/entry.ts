import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const stripHtml = (value = '') => String(value).replace(/<[^>]+>/g, ' ');
const countWords = (value = '') => stripHtml(value).trim().split(/\s+/).filter(Boolean).length;

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    let draft;
    if (payload.draft_id) {
      draft = await base44.asServiceRole.entities.ContentDraft.get(payload.draft_id);
    } else {
      const drafts = await base44.asServiceRole.entities.ContentDraft.list('-created_date', 1);
      draft = drafts[0];
    }

    if (!draft) return Response.json({ error: 'No draft found' }, { status: 404 });

    let html = draft.html_content || '';
    if (draft.html_file_url) {
      const response = await fetch(draft.html_file_url);
      if (response.ok) {
        html = await response.text();
      }
    }

    return Response.json({
      success: true,
      draft_id: draft.id,
      title: draft.title,
      word_count: countWords(html),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});