import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Copy, Check } from 'lucide-react';

export default function CodeCard({ title, description, code }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <Card className="overflow-hidden border-gray-200">
      <CardHeader className="flex flex-row items-start justify-between space-y-0 gap-4 border-b bg-gray-50/60">
        <div>
          <CardTitle className="text-base">{title}</CardTitle>
          {description && <p className="text-sm text-gray-500 mt-1">{description}</p>}
        </div>
        <Button variant="outline" size="sm" onClick={handleCopy} className="gap-2 rounded-lg">
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copied ? 'Copied' : 'Copy'}
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        <pre className="text-xs leading-6 overflow-x-auto p-4 bg-[#0b1020] text-slate-100"><code>{code}</code></pre>
      </CardContent>
    </Card>
  );
}