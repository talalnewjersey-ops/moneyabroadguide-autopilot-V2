import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

const steps = [
  ['Create workspace', '/Workspaces'],
  ['Create first project', '/Projects'],
  ['Connect website', '/ConnectWebsite'],
  ['Connect WordPress', '/WordPressConnection'],
  ['Add API key', '/APIKeys'],
  ['Run first audit', '/SiteAudit'],
  ['Optimize first page', '/SinglePageOptimizer'],
  ['Generate first article', '/ArticleGenerator'],
];

export default function Onboarding() {
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <PageHeader title="Onboarding" description="Launch AI SEO Autopilot in a guided sequence designed for solo creators and agencies." />
      <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4">{steps.map(([label, path], index) => <Link key={label} to={path}><Card className="hover:shadow-sm transition-shadow"><CardContent className="p-5"><p className="text-xs text-blue-600 font-medium">Step {index + 1}</p><h3 className="font-semibold text-gray-900 mt-2">{label}</h3></CardContent></Card></Link>)}</div>
    </div>
  );
}