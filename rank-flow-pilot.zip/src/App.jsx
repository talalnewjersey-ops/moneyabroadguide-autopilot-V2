import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Workspaces from './pages/Workspaces';
import WorkspaceDashboard from './pages/WorkspaceDashboard';
import Projects from './pages/Projects';
import ProjectOverview from './pages/ProjectOverview';
import ConnectWebsite from './pages/ConnectWebsite';
import WordPressConnection from './pages/WordPressConnection';
import AuditIssues from './pages/AuditIssues';
import SinglePageOptimizer from './pages/SinglePageOptimizer';
import FullSiteOptimizer from './pages/FullSiteOptimizer';
import KeywordClusters from './pages/KeywordClusters';
import CompetitorAnalysis from './pages/CompetitorAnalysis';
import AIContentAssistant from './pages/AIContentAssistant';
import ArticleGenerator from './pages/ArticleGenerator';
import RankTracking from './pages/RankTracking';
import APIKeys from './pages/APIKeys';
import AISettings from './pages/AISettings';
import BillingPlaceholder from './pages/BillingPlaceholder';
import ActivityLogs from './pages/ActivityLogs';
import AppliedFixesHistory from './pages/AppliedFixesHistory';
import Onboarding from './pages/Onboarding';
import AdminConsole from './pages/AdminConsole';
import WritesonicPluginDownload from './pages/WritesonicPluginDownload';
import LegalPagesPluginDownload from './pages/LegalPagesPluginDownload';
import HomePage from './pages/HomePage';
import About from './pages/About';
import Contact from './pages/Contact';
import PrivacyPolicy from './pages/PrivacyPolicy';
import WordPressZipPreview from './pages/WordPressZipPreview';
import SeoAutopilotCenter from './pages/SeoAutopilotCenter';
import { marketingPages } from './lib/marketingRoutes';

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;
const explicitPages = {
  Workspaces,
  WorkspaceDashboard,
  Projects,
  ProjectOverview,
  ConnectWebsite,
  WordPressConnection,
  AuditIssues,
  SinglePageOptimizer,
  FullSiteOptimizer,
  KeywordClusters,
  CompetitorAnalysis,
  AIContentAssistant,
  ArticleGenerator,
  RankTracking,
  APIKeys,
  AISettings,
  BillingPlaceholder,
  ActivityLogs,
  AppliedFixesHistory,
  Onboarding,
  AdminConsole,
  WritesonicPluginDownload,
  LegalPagesPluginDownload,
  About,
};

const LayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/HomePage" element={<HomePage />} />
      <Route path="/about" element={<About />} />
      <Route path="/About" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/Contact" element={<Contact />} />
      <Route path="/privacy-policy" element={<PrivacyPolicy />} />
      <Route path="/PrivacyPolicy" element={<PrivacyPolicy />} />
      <Route path="/wordpress-zip-preview" element={<WordPressZipPreview />} />
      <Route path="/seo-autopilot-center" element={<LayoutWrapper currentPageName="SeoAutopilotCenter"><SeoAutopilotCenter /></LayoutWrapper>} />
      {Object.entries(marketingPages).map(([path, Page]) => (
        <Route
          key={`marketing-${path}`}
          path={`/${path}`}
          element={<Page />}
        />
      ))}
      {Object.entries(Pages).map(([path, Page]) => (
        <Route
          key={path}
          path={`/${path}`}
          element={
            <LayoutWrapper currentPageName={path}>
              <Page />
            </LayoutWrapper>
          }
        />
      ))}
      {Object.entries(explicitPages).map(([path, Page]) => (
        <Route
          key={`explicit-${path}`}
          path={`/${path}`}
          element={
            <LayoutWrapper currentPageName={path}>
              <Page />
            </LayoutWrapper>
          }
        />
      ))}
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App