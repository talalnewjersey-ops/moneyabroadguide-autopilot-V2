import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import OpenAI from 'npm:openai@4.104.0';

const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY') });
const normalizeUrl = (url = '') => url.toLowerCase().trim().replace(/\/$/, '');
const toText = (value = '') => typeof value === 'string' ? value : value == null ? '' : String(value);
const toNumber = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const toArray = (value) => Array.isArray(value) ? value : [];

const getWebsite = async (base44, siteUrl, apiKey) => {
  const websites = await base44.asServiceRole.entities.Website.list();
  return websites.find((item) => normalizeUrl(item.url) === normalizeUrl(siteUrl) && item.wordpress_api_key === apiKey);
};

const askOpenAI = async (prompt) => {
  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: 'You are a content optimization strategist using ChatGPT. Return only valid JSON with no markdown.'
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
  });

  return JSON.parse(response.choices[0]?.message?.content || '{}');
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'contentRecommendations', required_fields: ['site_url', 'api_key'], optional_fields: ['pages', 'page', 'keyword', 'niche', 'language', 'country'] });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.site_url || !payload.api_key) {
      return Response.json({ endpoint: 'contentRecommendations', required_fields: ['site_url', 'api_key'], optional_fields: ['pages', 'page', 'keyword', 'niche', 'language', 'country'] });
    }

    const website = await getWebsite(base44, payload.site_url, payload.api_key);
    if (!website) {
      return Response.json({ error: 'Unauthorized WordPress connection.' }, { status: 403 });
    }

    const pageContext = toArray(payload.pages).slice(0, 50).map((page) => ({
      title: toText(page.title),
      url: toText(page.url),
      content: toText(page.content).slice(0, 2200),
      categories: toArray(page.categories),
    }));

    const rawResult = await askOpenAI(`Generate page-specific content recommendations for ${website.url}. Prioritize practical finance content for expats, immigrants, newcomers, foreign workers, and international students in the USA and Canada unless the payload says otherwise. Payload keyword: ${toText(payload.keyword)}. Payload niche: ${toText(payload.niche || 'expat finance')}. Language: ${toText(payload.language || 'English')}. Country: ${toText(payload.country || 'USA and Canada')}. Use this content snapshot: ${JSON.stringify(pageContext)}. Return JSON with a recommendations array. Each recommendation must include: page_url, type, priority, description, suggested_content, impact_score.`);

    const recommendations = toArray(rawResult.recommendations).map((recommendation) => ({
      page_url: toText(recommendation.page_url),
      type: toText(recommendation.type || 'content_refresh'),
      priority: toText(recommendation.priority || 'medium'),
      description: toText(recommendation.description),
      suggested_content: toText(recommendation.suggested_content),
      impact_score: toNumber(recommendation.impact_score),
    })).filter((recommendation) => recommendation.description);

    for (const recommendation of recommendations) {
      await base44.asServiceRole.entities.ContentRecommendation.create({
        website_id: website.id,
        page_url: recommendation.page_url || website.url,
        type: recommendation.type,
        priority: recommendation.priority,
        description: recommendation.description,
        suggested_content: recommendation.suggested_content,
        impact_score: recommendation.impact_score,
        status: 'pending',
      });
    }

    return Response.json({ success: true, recommendations });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});