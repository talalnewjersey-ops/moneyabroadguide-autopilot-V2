import React from 'react';
import { Quote, TrendingUp } from 'lucide-react';
import SectionReveal from '@/components/home/SectionReveal';

export default function HomeStory() {
  return (
    <section className="bg-white">
      <SectionReveal className="mx-auto max-w-[920px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
        <div className="fintech-card overflow-hidden rounded-[32px] border-0 bg-[linear-gradient(135deg,#0B1F3A_0%,#15304f_52%,#1F8F6A_100%)] p-8 text-white shadow-[0_28px_70px_rgba(15,23,42,0.18)] sm:p-10">
          <div className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
            <div>
              <div className="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10">
                <Quote className="h-6 w-6" />
              </div>
              <p className="text-sm font-semibold uppercase tracking-[0.22em] text-white/70">Real savings story</p>
              <h2 className="mt-3 max-w-2xl text-3xl font-extrabold tracking-tight sm:text-4xl">
                Ahmed saved $420 a year by switching transfer provider
              </h2>
              <p className="mt-4 max-w-2xl text-base leading-8 text-white/80">
                Ahmed was sending money home every month from the USA and assumed his usual provider was already competitive.
                After comparing fees, FX margins, and delivery times, he switched to a lower-cost option and kept hundreds of dollars each year.
              </p>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <a href="#calculator" className="inline-flex h-13 items-center justify-center rounded-full bg-white px-7 text-sm font-semibold text-slate-950 transition hover:bg-slate-100">
                  Compare Fees Now
                </a>
                <a href="/HomePage#trust" className="inline-flex h-13 items-center justify-center rounded-full border border-white/15 bg-white/10 px-7 text-sm font-semibold text-white transition hover:bg-white/15">
                  See why users trust us
                </a>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
              <div className="rounded-[24px] border border-white/10 bg-white/10 p-5 backdrop-blur-sm">
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-white/70">Before switching</p>
                <p className="mt-3 text-2xl font-bold">Higher fees + weak FX</p>
                <p className="mt-2 text-sm leading-7 text-white/75">Monthly transfers looked fine on the surface, but hidden spread costs kept reducing the received amount.</p>
              </div>
              <div className="rounded-[24px] border border-white/10 bg-white/10 p-5 backdrop-blur-sm">
                <div className="flex items-center gap-2 text-emerald-200">
                  <TrendingUp className="h-5 w-5" />
                  <p className="text-xs font-semibold uppercase tracking-[0.16em]">After comparing</p>
                </div>
                <p className="mt-3 text-2xl font-bold">$420/year saved</p>
                <p className="mt-2 text-sm leading-7 text-white/75">A better provider meant stronger rates, lower total cost, and more money delivered to family every month.</p>
              </div>
            </div>
          </div>
        </div>
      </SectionReveal>
    </section>
  );
}