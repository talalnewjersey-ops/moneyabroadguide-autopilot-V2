import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function WritesonicPluginDownload() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleDownload = async () => {
    setLoading(true);
    setError('');

    try {
      const response = await base44.functions.invoke('downloadWritesonicHeadPlugin', {});
      const fileUrl = response?.data?.file_url;

      if (!fileUrl) {
        setError('Le lien de téléchargement est introuvable.');
        return;
      }

      window.open(fileUrl, '_blank');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>Plugin Writesonic WordPress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Cliquez ci-dessous pour télécharger le plugin ZIP à installer dans WordPress.
            </p>
            <Button onClick={handleDownload} disabled={loading}>
              {loading ? 'Préparation du téléchargement...' : 'Télécharger le plugin'}
            </Button>
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <div className="text-sm text-muted-foreground space-y-1">
              <p>1. Téléchargez le ZIP.</p>
              <p>2. Dans WordPress : Plugins → Add New → Upload Plugin.</p>
              <p>3. Activez-le, puis ouvrez Settings → Writesonic Head.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}