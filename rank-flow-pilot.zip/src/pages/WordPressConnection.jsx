import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function WordPressConnection() {
  const [siteUrl, setSiteUrl] = useState('');
  const [restUrl, setRestUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const queryClient = useQueryClient();
  const { data: projects = [] } = useQuery({ queryKey: ['projects'], queryFn: () => base44.entities.Project.list('-created_date', 1) });
  const { data: websites = [] } = useQuery({ queryKey: ['websites'], queryFn: () => base44.entities.Website.list('-created_date', 1) });
  const { data: items = [] } = useQuery({ queryKey: ['wordpress-connections'], queryFn: () => base44.entities.WordPressConnection.list('-created_date', 50) });

  const connect = async () => {
    if (!projects[0] || !siteUrl) return;
    await base44.entities.WordPressConnection.create({
      project_id: projects[0].id,
      website_id: websites[0]?.id,
      site_url: siteUrl,
      rest_url: restUrl || siteUrl,
      api_key: apiKey || projects[0].project_api_key,
      plugin_version: '1.4.0',
      status: 'connected',
      last_sync_date: new Date().toISOString()
    });
    setSiteUrl('');
    setRestUrl('');
    setApiKey('');
    queryClient.invalidateQueries({ queryKey: ['wordpress-connections'] });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="WordPress Connection" description="Track plugin handshakes, API keys, and sync status for connected WordPress sites." />
      <div className="grid md:grid-cols-4 gap-3"><Input value={siteUrl} onChange={(e) => setSiteUrl(e.target.value)} placeholder="Site URL" className="rounded-xl" /><Input value={restUrl} onChange={(e) => setRestUrl(e.target.value)} placeholder="REST URL" className="rounded-xl" /><Input value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="Project API key" className="rounded-xl" /><Button onClick={connect} className="rounded-xl bg-blue-600 hover:bg-blue-700">Save Connection</Button></div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{items.map((item) => <Card key={item.id}><CardContent className="p-5"><h3 className="font-semibold text-gray-900">{item.site_url}</h3><p className="text-sm text-gray-500 mt-1">Status: {item.status}</p><p className="text-xs text-gray-400 mt-2">Plugin {item.plugin_version || '—'}</p></CardContent></Card>)}</div>
    </div>
  );
}