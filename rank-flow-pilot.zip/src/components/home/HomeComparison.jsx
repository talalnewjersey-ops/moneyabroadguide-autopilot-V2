import React, { useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, ArrowUpDown } from 'lucide-react';
import { transferServices } from '@/lib/homepageData';
import { sortTransferServices } from '@/lib/transferCalculator';
import SectionReveal from '@/components/home/SectionReveal';
import SectionHeading from '@/components/home/SectionHeading';

const columns = [
  { key: 'service', label: 'Service', sortable: false },
  { key: 'fees', label: 'Fees', sortable: true },
  { key: 'speed', label: 'Speed', sortable: true },
  { key: 'exchangeRate', label: 'Exchange Rate', sortable: false },
  { key: 'rating', label: 'Rating', sortable: true },
  { key: 'action', label: 'Action', sortable: false },
];

export default function HomeComparison() {
  const [sortBy, setSortBy] = useState('rating');
  const [sortDirection, setSortDirection] = useState('desc');

  const sortedServices = useMemo(() => sortTransferServices(transferServices, sortBy, sortDirection), [sortBy, sortDirection]);

  const handleSort = (column) => {
    if (!column.sortable) return;
    const nextDirection = sortBy === column.key && sortDirection === 'asc' ? 'desc' : column.key === 'rating' ? 'desc' : 'asc';
    setSortBy(column.key);
    setSortDirection(nextDirection);
  };

  const renderSortIcon = (column) => {
    if (!column.sortable) return null;
    if (sortBy !== column.key) return <ArrowUpDown className="h-4 w-4" />;
    return sortDirection === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />;
  };

  return (
    <section id="compare" className="table border-y border-slate-200/70 bg-slate-50/80">
      <SectionReveal className="mx-auto max-w-[920px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
        <SectionHeading
          eyebrow="Compare and convert"
          title="Compare providers, reduce fees, and move money with more confidence"
          description="This table is built to help users compare total value fast and click through only when the offer matches their route, urgency, and amount."
          className="mx-auto max-w-[680px] text-center"
        />

        <div className="fintech-card mx-auto max-w-[820px] overflow-hidden rounded-[30px] border-0">
          <div className="overflow-x-auto">
            <table className="mx-auto min-w-[820px] w-full text-center text-sm">
              <thead className="sticky top-0 z-10 bg-[#0B1F3A] text-white">
                <tr>
                  {columns.map((column) => (
                    <th key={column.key} className="px-6 py-4 text-center font-semibold">
                      {column.sortable ? (
                        <button type="button" onClick={() => handleSort(column)} className="inline-flex items-center justify-center gap-2 transition hover:text-white/80">
                          {column.label}
                          {renderSortIcon(column)}
                        </button>
                      ) : (
                        column.label
                      )}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {sortedServices.map((service, index) => (
                  <tr key={service.name} className={`border-t border-slate-200 align-middle transition hover:bg-[#F4F8FB] ${index % 2 === 0 ? 'bg-white' : 'bg-slate-50/60'}`}>
                    <td className="px-6 py-5 text-center font-semibold text-slate-950">{service.name}</td>
                    <td className="px-6 py-5 text-center text-slate-600">{service.fees}</td>
                    <td className="px-6 py-5 text-center text-slate-600">{service.speed}</td>
                    <td className="px-6 py-5 text-center text-slate-600">{service.exchangeRate}</td>
                    <td className="px-6 py-5 text-center font-semibold text-slate-900">{service.rating}</td>
                    <td className="px-6 py-5 text-center">
                      <a href={service.href} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center rounded-full bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800">
                        Compare Fees Now
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-6 flex justify-center">
          <a href="#calculator" className="cta-primary h-13 px-8 text-sm">
            Compare Fees Now
          </a>
        </div>
      </SectionReveal>
    </section>
  );
}