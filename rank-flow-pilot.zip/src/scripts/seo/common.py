import base64
import json
import os
from datetime import datetime, timezone
from pathlib import Path

import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[2]
REPORTS_DIR = ROOT / 'docs' / 'seo-reports'
CONTENT_DRAFTS_DIR = ROOT / 'content-drafts'
META_DIR = ROOT / 'meta'

EDITORIAL_REPLACEMENT = 'Content under review. Updated editorial policy coming soon.'
ROBOTS_TARGET = """User-agent: *
Allow: /

Disallow: /wp-admin/
Allow: /wp-admin/admin-ajax.php

Sitemap: https://moneyabroadguide.com/sitemap.xml
""".strip()

META_TARGETS = {
    '/': {
        'title': 'Financial Guide for Newcomers to USA & Canada | MoneyAbroadGuide',
        'description': 'Explore a financial guide for newcomers to USA and Canada with practical banking, transfer, and credit tips. Start planning smarter today.'
    },
    '/newcomers-to-the-usa/': {
        'title': 'Banking & Finance for Immigrants in the USA | MoneyAbroadGuide',
        'description': 'Get banking and finance for immigrants in the USA with simple newcomer tips, account options, and next steps. Read the guide today.'
    },
    '/newcomers-to-canada/': {
        'title': 'Financial Guide for New Immigrants in Canada | MoneyAbroadGuide',
        'description': 'Use this financial guide for new immigrants in Canada to compare banking, transfers, and budgeting tips. Explore your options now.'
    }
}

INTERNAL_LINK_TARGETS = {
    '/': [
        {'anchor': 'money transfer comparisons', 'target': '/best-international-money-transfer-services-2026/'},
        {'anchor': 'guides for newcomers', 'target': '/international-money-transfer-guide-for-immigrants/'}
    ],
    '/newcomers-to-the-usa/': [
        {'anchor': 'build US credit', 'target': '/best-bank-account-for-immigrants-usa-no-credit-history/'},
        {'anchor': 'sending money abroad', 'target': '/wise-vs-remitly-comparison-2026/'}
    ],
    '/newcomers-to-canada/': [
        {'anchor': 'open a bank account in Canada', 'target': '/how-to-open-a-bank-account-in-canada-as-a-newcomer/'},
        {'anchor': 'budgeting tips for newcomers', 'target': '/budgeting-tips-for-new-immigrants-canada/'}
    ],
    '/editorial-policy/': [
        {'anchor': 'about Money Abroad Guide', 'target': '/about/'},
        {'anchor': 'contact our team', 'target': '/contact/'}
    ],
    '/about/': [
        {'anchor': 'editorial policy', 'target': '/editorial-policy/'},
        {'anchor': 'financial guides for newcomers', 'target': '/'}
    ]
}

ARTICLE_BLUEPRINTS = [
    {
        'slug': 'how-to-open-a-bank-account-in-canada-as-a-newcomer',
        'keyword': 'how to open a bank account in canada as a newcomer',
        'title': 'How to Open a Bank Account in Canada as a Newcomer',
        'meta_description': 'Learn how to open a bank account in Canada as a newcomer with simple steps, required documents, and smart tips. Start banking confidently today.'
    },
    {
        'slug': 'best-bank-account-for-immigrants-usa-no-credit-history',
        'keyword': 'best bank account for immigrants usa no credit history',
        'title': 'Best Bank Account for Immigrants in the USA',
        'meta_description': 'Find the best bank account for immigrants in the USA with no credit history and compare easy options. Read the guide and choose confidently.'
    },
    {
        'slug': 'how-to-build-credit-score-as-international-student-usa',
        'keyword': 'how to build credit score as international student usa',
        'title': 'How to Build Credit Score as an International Student',
        'meta_description': 'Discover how to build credit score as an international student in the USA with practical steps and tools. Start improving your credit today.'
    },
    {
        'slug': 'wise-vs-remitly-for-sending-money-abroad',
        'keyword': 'wise vs remitly for sending money abroad',
        'title': 'Wise vs Remitly for Sending Money Abroad',
        'meta_description': 'Compare Wise vs Remitly for sending money abroad, including fees, speed, and ease of use. Read the guide and pick the best fit today.'
    },
    {
        'slug': 'budgeting-tips-for-new-immigrants-canada',
        'keyword': 'budgeting tips for new immigrants canada',
        'title': 'Budgeting Tips for New Immigrants in Canada',
        'meta_description': 'Use these budgeting tips for new immigrants in Canada to manage rent, groceries, and savings goals. Read the guide and plan better today.'
    }
]


def ensure_dirs():
    for path in [
        REPORTS_DIR / 'daily',
        REPORTS_DIR / 'weekly',
        REPORTS_DIR / 'articles',
        CONTENT_DRAFTS_DIR,
        META_DIR,
    ]:
        path.mkdir(parents=True, exist_ok=True)


def timestamp():
    return datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')


def write_text(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')


def write_json(path, payload):
    write_text(path, json.dumps(payload, indent=2, ensure_ascii=False))


def env_flag(name, default=False):
    value = os.getenv(name)
    if value is None:
        return default
    return str(value).lower() in {'1', 'true', 'yes', 'on'}


def get_wp_credentials():
    base_url = (os.getenv('WP_BASE_URL') or '').rstrip('/')
    username = os.getenv('WP_USERNAME') or ''
    app_password = os.getenv('WP_APP_PASSWORD') or ''
    return {
        'base_url': base_url,
        'username': username,
        'app_password': app_password,
        'configured': bool(base_url and username and app_password),
    }


def get_auth_header(credentials):
    token = base64.b64encode(f"{credentials['username']}:{credentials['app_password']}".encode('utf-8')).decode('utf-8')
    return {'Authorization': f'Basic {token}'}


def fetch_url(url, timeout=20):
    response = requests.get(url, timeout=timeout, headers={'User-Agent': 'MoneyAbroadGuide SEO Autopilot/1.0'})
    response.raise_for_status()
    return response


def get_page_html(base_url, path):
    response = fetch_url(f"{base_url}{path}")
    return response.text


def extract_title_and_meta(html):
    soup = BeautifulSoup(html, 'html.parser')
    title = soup.title.get_text(strip=True) if soup.title else ''
    meta = soup.find('meta', attrs={'name': 'description'})
    description = meta.get('content', '').strip() if meta else ''
    return {'title': title, 'description': description, 'soup': soup}


def word_count_from_html(html):
    soup = BeautifulSoup(html, 'html.parser')
    text = soup.get_text(' ', strip=True)
    return len([word for word in text.split() if word])


def find_base64_images(html):
    soup = BeautifulSoup(html, 'html.parser')
    images = []
    for img in soup.find_all('img'):
        src = img.get('src', '')
        if src.startswith('data:image/'):
            images.append({
                'src': src[:120] + '...' if len(src) > 120 else src,
                'alt': img.get('alt', ''),
                'loading': img.get('loading', ''),
                'has_lazy': img.get('loading') == 'lazy'
            })
    return images


def detect_editorial_artifacts(html):
    lines = [line.strip() for line in BeautifulSoup(html, 'html.parser').get_text('\n').splitlines() if line.strip()]
    prefixes = ('Provide', 'Include', 'Add', 'Detail', 'Expand on')
    hits = [line for line in lines if line.startswith(prefixes)]
    return hits


def build_meta_report(base_url):
    report = []
    for path, target in META_TARGETS.items():
        current = {'title': '', 'description': ''}
        status = 'report_only'
        if base_url:
            try:
                parsed = extract_title_and_meta(get_page_html(base_url, path))
                current = {'title': parsed['title'], 'description': parsed['description']}
                status = 'compare'
            except Exception as error:
                current = {'title': '', 'description': f'Fetch failed: {error}'}
                status = 'unavailable'
        report.append({'path': path, 'current': current, 'target': target, 'status': status})
    return report


def build_internal_link_report():
    report = []
    for path, suggestions in INTERNAL_LINK_TARGETS.items():
        report.append({'path': path, 'suggestions': suggestions})
    return report


def organization_schema():
    return {
        '@context': 'https://schema.org',
        '@type': 'Organization',
        'name': 'Money Abroad Guide',
        'url': 'https://moneyabroadguide.com',
        'founder': 'Talal Eddaouahiri',
        'description': 'Free financial guides for newcomers to Canada & USA'
    }


def person_schema():
    return {
        '@context': 'https://schema.org',
        '@type': 'Person',
        'name': 'Talal Eddaouahiri',
        'url': 'https://moneyabroadguide.com/about/',
        'jobTitle': 'Founder',
        'description': 'Founder of Money Abroad Guide, focused on finance for newcomers.'
    }


def rank_math_checklist():
    return {
        'installation_checklist': [
            'Confirm Rank Math is not already active in WordPress plugins.',
            'Create a fresh backup before installation.',
            'Install Rank Math manually in wp-admin > Plugins > Add New.',
            'Keep LiteSpeed cache purge ready after activation if needed.'
        ],
        'activation_checklist': [
            'Activate Rank Math during a low-traffic window.',
            'Verify no schema duplication with Astra or custom snippets.',
            'Confirm Wordfence does not block Rank Math REST or AJAX actions.'
        ],
        'configuration_checklist': [
            'Enable Sitemap module for posts and pages only.',
            'Enable Schema module and keep defaults conservative.',
            'Enable Redirections module but review all imports before publish.',
            'Enable Analytics only after Search Console credentials are available.',
            'Exclude noindex URLs from sitemap output.',
            'Verify sitemap.xml remains accessible after changes.'
        ],
        'gsc_placeholders': {
            'property_type': 'URL-prefix or Domain property',
            'site_url': os.getenv('GSC_SITE_URL') or 'manual approval required',
            'service_account_json': 'manual approval required',
            'verification_status': 'not connected'
        }
    }