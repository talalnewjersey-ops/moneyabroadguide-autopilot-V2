import React from 'react';
import HomeHeader from '@/components/home/HomeHeader';
import HomeComparison from '@/components/home/HomeComparison';
import HomeFinalCta from '@/components/home/HomeFinalCta';
import HomeFooter from '@/components/home/HomeFooter';
import MoneyTransferCalculator from '@/components/home/MoneyTransferCalculator';
import StickyCompareBar from '@/components/home/StickyCompareBar';
import SectionReveal from '@/components/home/SectionReveal';
import SeoMeta from '@/components/seo/SeoMeta';

export default function Calculator() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-950">
      <SeoMeta title="Money Transfer Calculator | MoneyAbroadGuide" description="Compare the cheapest way to send money abroad with MoneyAbroadGuide's calculator for cost, received amount, and speed." />
      <HomeHeader />
      <section className="hero border-b border-slate-200">
        <SectionReveal className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
          <div className="space-y-5 text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#1F8F6A]">Core conversion tool</p>
            <h1 className="text-4xl font-extrabold tracking-tight text-[#0F172A] sm:text-5xl lg:text-[52px]">Money Transfer Calculator</h1>
            <p className="mx-auto max-w-3xl text-lg leading-8 text-slate-500">Compare providers by total cost, received amount, speed, and rating so you can find the best deal before you send money now.</p>
          </div>
        </SectionReveal>
      </section>
      <SectionReveal className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 lg:px-8 lg:py-14">
        <MoneyTransferCalculator />
      </SectionReveal>
      <HomeComparison />
      <HomeFinalCta />
      <HomeFooter />
      <StickyCompareBar />
    </div>
  );
}