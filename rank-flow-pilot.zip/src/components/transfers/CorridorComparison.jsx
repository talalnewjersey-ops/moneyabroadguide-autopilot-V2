import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import SectionHeading from '@/components/home/SectionHeading';

export default function CorridorComparison({ title, description, services, ctaText = 'Send Now' }) {
  return (
    <section id="compare" className="bg-white">
      <div className="mx-auto max-w-[980px] px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
        <SectionHeading eyebrow="Provider comparison" title={title} description={description} />

        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {services.map((service) => (
            <Card key={service.name} className="fintech-card fintech-card-hover h-full rounded-[28px] border-0">
              <CardContent className="flex h-full flex-col p-7 text-center">
                <div className="mx-auto inline-flex rounded-full bg-[#EAF7F1] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#1F8F6A]">
                  {service.badge}
                </div>
                <h3 className="mt-4 text-2xl font-bold text-slate-950">{service.name}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-500">{service.description}</p>
                <ul className="mt-5 space-y-3 text-left">
                  {service.highlights.map((item) => (
                    <li key={item} className="flex items-start gap-3 text-sm leading-6 text-slate-600">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-[#1F8F6A]" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <a href={service.href} target="_blank" rel="noreferrer" className="mt-6 inline-flex w-fit self-center items-center gap-2 rounded-full bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800">
                  {ctaText} <ArrowRight className="h-4 w-4" />
                </a>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 fintech-card overflow-hidden rounded-[28px] border-0">
          <div className="overflow-x-auto">
            <table className="min-w-[760px] w-full text-left text-sm">
              <thead className="bg-[#0B1F3A] text-white">
                <tr>
                  <th className="px-6 py-4 font-semibold">Provider</th>
                  <th className="px-6 py-4 font-semibold">Best for</th>
                  <th className="px-6 py-4 font-semibold">Transfer fee</th>
                  <th className="px-6 py-4 font-semibold">Exchange rate</th>
                  <th className="px-6 py-4 font-semibold">Delivery time</th>
                  <th className="px-6 py-4 font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {services.map((service, index) => (
                  <tr key={service.name} className={`${index % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'} border-t border-slate-200`}>
                    <td className="px-6 py-5 font-semibold text-slate-950">{service.name}</td>
                    <td className="px-6 py-5 text-slate-600">{service.badge}</td>
                    <td className="px-6 py-5 text-slate-600">{service.typicalFee}</td>
                    <td className="px-6 py-5 text-slate-600">{service.rateText}</td>
                    <td className="px-6 py-5 text-slate-600">{service.speed}</td>
                    <td className="px-6 py-5">
                      <a href={service.href} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center rounded-full bg-[#1F8F6A] px-4 py-2 text-xs font-semibold text-white transition hover:bg-[#187255]">
                        {ctaText}
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}