import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Search, Loader2, AlertCircle, AlertTriangle, Info, CheckCircle2 } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import ScoreGauge from '../components/dashboard/ScoreGauge';
import EmptyState from '../components/common/EmptyState';
import { toast } from 'sonner';

export default function SiteAudit() {
  const [scanning, setScanning] = useState(false);
  const queryClient = useQueryClient();

  const { data: websites = [] } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 1),
  });

  const activeWebsite = websites[0];

  const { data: scans = [], isLoading } = useQuery({
    queryKey: ['scans', activeWebsite?.id],
    queryFn: () => base44.entities.SiteScan.filter({ website_id: activeWebsite.id }, '-created_date', 5),
    enabled: !!activeWebsite,
  });

  const runScan = async () => {
    if (!activeWebsite) return;
    setScanning(true);
    
    const aiResult = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an SEO auditor. Analyze this website URL: ${activeWebsite.url}
      
      Return a detailed SEO audit with realistic issues that a typical website would have. Be specific with page URLs.
      
      Return JSON with:
      - seo_score (0-100)
      - total_pages_scanned (number)
      - critical_issues (count)
      - warnings (count)
      - opportunities (count)
      - issues (array of objects with: type, severity [critical/warning/info], page_url, description, recommendation)
      - summary (string with overall assessment)
      
      Generate 10-15 realistic issues including missing meta descriptions, thin content, broken links, missing alt text, etc.`,
      response_json_schema: {
        type: "object",
        properties: {
          seo_score: { type: "number" },
          total_pages_scanned: { type: "number" },
          critical_issues: { type: "number" },
          warnings: { type: "number" },
          opportunities: { type: "number" },
          issues: {
            type: "array",
            items: {
              type: "object",
              properties: {
                type: { type: "string" },
                severity: { type: "string" },
                page_url: { type: "string" },
                description: { type: "string" },
                recommendation: { type: "string" }
              }
            }
          },
          summary: { type: "string" }
        }
      },
      add_context_from_internet: true,
    });

    await base44.entities.SiteScan.create({
      website_id: activeWebsite.id,
      status: 'completed',
      ...aiResult,
    });

    await base44.entities.Website.update(activeWebsite.id, {
      seo_score: aiResult.seo_score,
      last_scan_date: new Date().toISOString(),
      total_pages: aiResult.total_pages_scanned,
      total_issues: (aiResult.critical_issues || 0) + (aiResult.warnings || 0),
    });

    queryClient.invalidateQueries({ queryKey: ['scans'] });
    queryClient.invalidateQueries({ queryKey: ['websites'] });
    setScanning(false);
    toast.success('Site audit completed!');
  };

  if (!activeWebsite) {
    return <EmptyState icon={Search} title="No website connected" description="Add a website in Settings first." />;
  }

  const latestScan = scans[0];

  const sevCounts = {
    critical: latestScan?.issues?.filter(i => i.severity === 'critical').length || 0,
    warning: latestScan?.issues?.filter(i => i.severity === 'warning').length || 0,
    info: latestScan?.issues?.filter(i => i.severity === 'info').length || 0,
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader
        title="Site Audit"
        description={`SEO health check for ${activeWebsite.name}`}
        action={
          <Button onClick={runScan} disabled={scanning} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
            {scanning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            {scanning ? 'Scanning...' : 'Run New Scan'}
          </Button>
        }
      />

      {latestScan && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
            <div className="bg-white rounded-2xl border border-gray-100 p-6 flex justify-center">
              <ScoreGauge score={latestScan.seo_score} label="Health Score" />
            </div>
            <Card className="border-red-100">
              <CardContent className="p-5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center">
                  <AlertCircle className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{sevCounts.critical}</p>
                  <p className="text-xs text-gray-500">Critical Issues</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-amber-100">
              <CardContent className="p-5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{sevCounts.warning}</p>
                  <p className="text-xs text-gray-500">Warnings</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-blue-100">
              <CardContent className="p-5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                  <Info className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{sevCounts.info}</p>
                  <p className="text-xs text-gray-500">Opportunities</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {latestScan.summary && (
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h3 className="font-semibold text-gray-900 mb-2">Summary</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{latestScan.summary}</p>
            </div>
          )}

          <div className="bg-white rounded-2xl border border-gray-100 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">All Issues</h3>
            <div className="space-y-2">
              {latestScan.issues?.map((issue, i) => (
                <div key={i} className="flex items-start gap-3 p-4 rounded-xl bg-gray-50/50 hover:bg-gray-50 transition-colors">
                  {issue.severity === 'critical' && <AlertCircle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />}
                  {issue.severity === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />}
                  {issue.severity === 'info' && <Info className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800">{issue.description}</p>
                    {issue.page_url && <p className="text-xs text-gray-400 mt-0.5">{issue.page_url}</p>}
                    {issue.recommendation && <p className="text-xs text-gray-500 mt-1 bg-white p-2 rounded-lg">{issue.recommendation}</p>}
                  </div>
                  <Badge variant="secondary" className="text-[10px] flex-shrink-0">
                    {issue.type}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {!latestScan && !isLoading && (
        <EmptyState
          icon={Search}
          title="No scans yet"
          description="Run your first SEO audit to discover issues and opportunities."
          action="Run First Scan"
          onAction={runScan}
        />
      )}
    </div>
  );
}