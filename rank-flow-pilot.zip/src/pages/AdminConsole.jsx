import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '../components/common/PageHeader';

export default function AdminConsole() {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('user');
  const [loading, setLoading] = useState(false);
  const queryClient = useQueryClient();
  const { data: users = [] } = useQuery({ queryKey: ['admin-users'], queryFn: () => base44.entities.User.list('-created_date', 100) });

  const grantAdmin = async () => {
    setLoading(true);
    await base44.functions.invoke('grantMeAdmin', {});
    setLoading(false);
    queryClient.invalidateQueries({ queryKey: ['admin-users'] });
  };

  const inviteUser = async () => {
    if (!email) return;
    setLoading(true);
    await base44.users.inviteUser(email, role);
    setEmail('');
    setLoading(false);
  };

  const makeRole = async (userId, nextRole) => {
    await base44.entities.User.update(userId, { role: nextRole });
    queryClient.invalidateQueries({ queryKey: ['admin-users'] });
  };

  const seedDemo = async () => {
    setLoading(true);
    await base44.functions.invoke('seedDemoData', {});
    setLoading(false);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader title="Admin Console" description="Manage admin access, invite users, seed demo data, and control accounts." />
      <div className="flex flex-wrap gap-3">
        <Button onClick={grantAdmin} disabled={loading} className="rounded-xl bg-blue-600 hover:bg-blue-700">Grant my account admin</Button>
        <Button onClick={seedDemo} disabled={loading} variant="outline" className="rounded-xl">Seed demo data</Button>
      </div>
      <div className="grid md:grid-cols-3 gap-3">
        <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Invite user email" className="rounded-xl" />
        <Input value={role} onChange={(e) => setRole(e.target.value)} placeholder="user or admin" className="rounded-xl" />
        <Button onClick={inviteUser} disabled={loading} className="rounded-xl bg-blue-600 hover:bg-blue-700">Invite User</Button>
      </div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{users.map((user) => <Card key={user.id}><CardContent className="p-5"><h3 className="font-semibold text-gray-900">{user.full_name || user.email}</h3><p className="text-sm text-gray-500 mt-1">{user.email}</p><p className="text-xs text-gray-400 mt-2">Role: {user.role || 'user'}</p><div className="flex gap-2 mt-3"><Button size="sm" variant="outline" className="rounded-lg" onClick={() => makeRole(user.id, 'admin')}>Make admin</Button><Button size="sm" variant="outline" className="rounded-lg" onClick={() => makeRole(user.id, 'viewer')}>Make viewer</Button></div></CardContent></Card>)}</div>
    </div>
  );
}