import React from 'react';

const adCards = [
  { title: 'Wise', text: 'Best rates for many transfer routes.', cta: 'Compare Wise', href: 'https://wise.com' },
  { title: 'Remitly', text: 'Fast transfer option for urgent payments.', cta: 'Try Remitly', href: 'https://www.remitly.com/' },
  { title: 'OFX', text: 'Good option for larger transfers.', cta: 'View OFX', href: 'https://www.ofx.com/en-ca/' },
];

export default function HomeSideAds() {
  return (
    <div className="hidden xl:block">
      <div className="sticky top-24 space-y-4">
        <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 p-5 text-center text-sm text-slate-400">
          Google Ads 160×600
        </div>
        {adCards.map((card) => (
          <div key={card.title} className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-[0_12px_30px_rgba(15,23,42,0.06)]">
            <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#1F8F6A]">Sponsored</p>
            <h3 className="mt-2 text-lg font-bold text-slate-950">{card.title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-500">{card.text}</p>
            <a href={card.href} target="_blank" rel="noopener sponsored" className="mt-4 inline-flex rounded-full bg-[#1F8F6A] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#187255]">
              {card.cta}
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}