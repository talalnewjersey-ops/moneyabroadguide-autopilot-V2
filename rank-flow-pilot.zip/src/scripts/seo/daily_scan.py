from common import (
    EDITORIAL_REPLACEMENT,
    ROBOTS_TARGET,
    build_internal_link_report,
    build_meta_report,
    detect_editorial_artifacts,
    ensure_dirs,
    find_base64_images,
    get_page_html,
    get_wp_credentials,
    organization_schema,
    person_schema,
    rank_math_checklist,
    timestamp,
    write_json,
    write_text,
)


def main():
    ensure_dirs()
    creds = get_wp_credentials()
    run_id = timestamp()
    base_url = creds['base_url']

    editorial_report = {
        'path': '/editorial-policy/',
        'mode': 'dry_run',
        'replacement': EDITORIAL_REPLACEMENT,
        'detected_lines': [],
        'status': 'report_only'
    }
    image_report = {
        'mode': 'dry_run',
        'upload_target_path': '/wp-content/uploads/2026/04/',
        'items': [],
        'status': 'report_only'
    }
    robots_report = {
        'mode': 'dry_run',
        'current': '',
        'target': ROBOTS_TARGET,
        'status': 'ready_to_apply_file'
    }

    if base_url:
        try:
            editorial_html = get_page_html(base_url, '/editorial-policy/')
            editorial_report['detected_lines'] = detect_editorial_artifacts(editorial_html)
            editorial_report['status'] = 'patch_proposal_ready' if editorial_report['detected_lines'] else 'no_artifacts_found'
        except Exception as error:
            editorial_report['status'] = f'fetch_failed: {error}'

        try:
            robots_report['current'] = get_page_html(base_url, '/robots.txt').strip()
            robots_report['status'] = 'matches_target' if robots_report['current'] == ROBOTS_TARGET else 'patch_proposal_ready'
        except Exception as error:
            robots_report['status'] = f'fetch_failed: {error}'

        for path in ['/', '/editorial-policy/', '/about/', '/newcomers-to-the-usa/', '/newcomers-to-canada/']:
            try:
                html = get_page_html(base_url, path)
                images = find_base64_images(html)
                if images:
                    image_report['items'].append({
                        'path': path,
                        'detected_images': images,
                        'replacement_plan': 'decode -> convert webp -> compress <=150KB -> upload manually -> replace src -> add alt + loading=lazy'
                    })
            except Exception as error:
                image_report['items'].append({'path': path, 'error': str(error)})

    meta_report = build_meta_report(base_url)
    internal_link_report = build_internal_link_report()
    schema_report = {
        'homepage_organization_schema': organization_schema(),
        'about_person_schema': person_schema(),
        'breadcrumb_schema': 'Prefer Rank Math breadcrumbs if already enabled.',
        'faq_schema': 'Inject only when FAQ blocks are confirmed on page.'
    }
    eeat_report = {
        'about_page_plan': {
            'founder': 'Talal Eddaouahiri',
            'expertise': 'finance for newcomers',
            'status': 'manual approval required',
            'trust_signals': ['Founder bio', 'Experience statement', 'Research methodology', 'Editorial standards']
        },
        'author_box_plan': 'Use child-theme/snippet-compatible patch only after template review.',
        'trust_badges_plan': ['Verified Content badge', 'Last updated date', 'Official sources mention']
    }
    rank_math_report = rank_math_checklist()

    payload = {
        'run_id': run_id,
        'mode': 'dry_run',
        'wordpress_credentials_configured': creds['configured'],
        'editorial_policy': editorial_report,
        'base64_images': image_report,
        'robots': robots_report,
        'meta_updates': meta_report,
        'internal_links': internal_link_report,
        'schema': schema_report,
        'eeat': eeat_report,
        'rank_math': rank_math_report,
    }

    md_lines = [
        '# Daily SEO Safe Scan',
        '',
        f'- Run ID: {run_id}',
        '- Mode: dry_run',
        f"- WordPress credentials configured: {'yes' if creds['configured'] else 'no'}",
        '',
        '## Editorial Policy',
        f"- Status: {editorial_report['status']}",
        f"- Detected artifacts: {len(editorial_report['detected_lines'])}",
        '',
        '## Base64 Images',
        f"- Pages with detections: {len([item for item in image_report['items'] if item.get('detected_images')])}",
        '',
        '## Robots.txt',
        f"- Status: {robots_report['status']}",
        '',
        '## Meta Updates',
        *[f"- {item['path']}: compare current vs target" for item in meta_report],
        '',
        '## Internal Linking',
        *[f"- {item['path']}: {len(item['suggestions'])} suggestions" for item in internal_link_report],
        '',
        '## Rank Math',
        '- Installation, activation, and configuration checklists prepared.',
        '',
        '## Safety',
        '- No production changes applied.',
        '- Manual approval required before any write step.',
    ]

    write_json('docs/seo-reports/daily/daily-scan-latest.json', payload)
    write_json(f'docs/seo-reports/daily/daily-scan-{run_id}.json', payload)
    write_text('docs/seo-reports/daily/daily-scan-latest.md', '\n'.join(md_lines))
    write_text(f'docs/seo-reports/daily/daily-scan-{run_id}.md', '\n'.join(md_lines))
    write_text('docs/seo-reports/daily/robots.txt.ready.txt', ROBOTS_TARGET + '\n')


if __name__ == '__main__':
    main()