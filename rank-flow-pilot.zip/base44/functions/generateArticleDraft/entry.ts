import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import OpenAI from 'npm:openai@4.104.0';

const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY') });
const toText = (value = '') => typeof value === 'string' ? value : value == null ? '' : String(value);
const toArray = (value) => Array.isArray(value) ? value : [];
const toJsonString = (value) => typeof value === 'string' ? value : JSON.stringify(value || {});
const stripHtml = (value = '') => toText(value).replace(/<[^>]+>/g, ' ');
const countWords = (value = '') => stripHtml(value).trim().split(/\s+/).filter(Boolean).length;
const slugify = (value = '') => toText(value).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 96);

const getNowMeta = () => {
  const now = new Date();
  return {
    isoDate: now.toISOString(),
    publishedLabel: now.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
    timeLabel: now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
  };
};
const buildArticleMetaBlock = () => {
  const { publishedLabel, timeLabel } = getNowMeta();
  return `<div class="article-meta"><p><strong>Author:</strong> Talal Eddaouahiri</p><p><strong>Published:</strong> ${publishedLabel} at ${timeLabel}</p></div>`;
};
const normalizeSchemaMarkup = (value, title, description) => {
  const { isoDate } = getNowMeta();
  let parsed = {};
  try {
    parsed = typeof value === 'string' ? JSON.parse(value) : (value || {});
  } catch {
    parsed = {};
  }
  const normalized = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: title,
    description,
    author: {
      '@type': 'Person',
      name: 'Talal Eddaouahiri'
    },
    datePublished: isoDate,
    image: parsed.image || [
      'https://source.unsplash.com/featured/1200x800/?banking',
      'https://source.unsplash.com/featured/1200x800/?immigrant,family',
      'https://source.unsplash.com/featured/1200x800/?student,finance',
      'https://source.unsplash.com/featured/1200x800/?money,planning'
    ],
    ...parsed,
  };
  normalized.datePublished = isoDate;
  normalized.author = {
    '@type': 'Person',
    name: 'Talal Eddaouahiri'
  };
  return JSON.stringify(normalized);
};

const defaultImageGallery = `
<div class="article-image-grid">
  <img src="https://source.unsplash.com/featured/1200x800/?banking" alt="Banking scene for newcomers in North America" />
  <img src="https://source.unsplash.com/featured/1200x800/?immigrant,family" alt="Immigrant family planning finances" />
  <img src="https://source.unsplash.com/featured/1200x800/?student,finance" alt="International student reviewing personal finances" />
  <img src="https://source.unsplash.com/featured/1200x800/?money,planning" alt="Personal finance planning and budgeting" />
</div>`;

const fallbackStorySection = `
<section>
  <h2>Real Story: Maria and Ahmed Starting Fresh</h2>
  <p>Maria moved to the United States after accepting a new job offer, while Ahmed arrived a few months later as an international student. Both quickly discovered that everyday tasks like getting paid, paying rent, and building trust with landlords became much easier once they opened a local bank account. Maria needed a checking account that supported direct deposit and low transfer fees, while Ahmed needed an account with flexible ID requirements and easy online banking.</p>
  <p>Their experience shows why newcomers benefit from choosing a bank that is easy to access, transparent on fees, and practical for day-to-day life. Their first good decision was comparing account terms before applying instead of opening the first account they saw.</p>
</section>`;

const fallbackComparisonTable = `
<section>
  <h2>Comparison Table: Common Newcomer Banking Priorities</h2>
  <table>
    <thead>
      <tr>
        <th>Priority</th>
        <th>Why It Matters</th>
        <th>What to Check</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Monthly fees</td>
        <td>Keeps day-to-day banking affordable</td>
        <td>Waiver rules, minimum balance, newcomer offers</td>
      </tr>
      <tr>
        <td>ID flexibility</td>
        <td>Important if you are still building documents in the USA</td>
        <td>Passport, visa, ITIN, proof of address</td>
      </tr>
      <tr>
        <td>Online banking</td>
        <td>Helps manage money faster and from anywhere</td>
        <td>App quality, transfer limits, alerts, customer support</td>
      </tr>
      <tr>
        <td>Transfer options</td>
        <td>Useful for sending or receiving money internationally</td>
        <td>Wire fees, ACH, card support, partner integrations</td>
      </tr>
    </tbody>
  </table>
</section>`;

const fallbackChartSection = `
<section>
  <h2>Illustrative Budget Chart for the First 30 Days</h2>
  <div class="chart-block">
    <p><strong>Sample allocation:</strong></p>
    <ul>
      <li>40% Housing and utilities</li>
      <li>20% Food and transport</li>
      <li>15% Emergency savings</li>
      <li>15% Banking setup, phone, and admin costs</li>
      <li>10% Flexible spending</li>
    </ul>
  </div>
</section>`;

const fallbackStudiesSection = `
<section>
  <h2>Official Data and Study Angles to Review</h2>
  <p>When reviewing banking choices as a newcomer, it is smart to compare official consumer information from institutions such as the CFPB, FDIC, IRS, and major bank fee schedules. These sources help validate account protections, deposit insurance, transfer rules, and common account costs.</p>
  <p>For a stronger decision, compare official disclosures for maintenance fees, overdraft policies, ATM network coverage, and customer support access before opening your account.</p>
</section>`;

const fallbackExpertTips = `
<section>
  <h2>Expert Tips from Talal Eddaouahiri</h2>
  <ul>
    <li>Choose a bank that clearly explains fee waivers and direct deposit rules.</li>
    <li>Keep digital copies of your passport, visa, address proof, and tax documents.</li>
    <li>Ask whether the bank can support international transfers and credit-building products later.</li>
    <li>Set up account alerts on day one so you track balances, deposits, and card activity.</li>
  </ul>
</section>`;

const fallbackMistakesSection = `
<section>
  <h2>Common Mistakes to Avoid</h2>
  <ul>
    <li>Opening the first account you see without comparing monthly fees and transfer charges.</li>
    <li>Ignoring direct deposit conditions that may affect fee waivers.</li>
    <li>Not asking about newcomer programs, welcome bonuses, or multilingual support.</li>
    <li>Using a credit card without a repayment plan, which can make early credit building more expensive.</li>
    <li>Skipping online banking setup and alerts, which reduces visibility on balances and transactions.</li>
  </ul>
</section>`;

const fallbackCTASection = `
<section>
  <h2>Explore More Money Abroad Guide Resources</h2>
  <p>Explore our guides to building credit, choosing the best banks, avoiding financial mistakes, and managing your finances as a newcomer in North America.</p>
  <ul>
    <li><a href="https://moneyabroadguide.com/best-us-banks-for-foreigners-2026-guide/">Best US Banks for Foreigners</a></li>
    <li><a href="https://moneyabroadguide.com/can-foreigners-open-a-bank-account-in-the-us/">Can Foreigners Open a US Bank Account</a></li>
    <li><a href="https://moneyabroadguide.com/newcomers-to-canada/">Newcomers to Canada</a></li>
    <li><a href="https://moneyabroadguide.com/newcomers-to-the-usa/">Newcomers to the USA</a></li>
  </ul>
</section>`;

const fallbackConclusionSection = `
<section>
  <h2>Conclusion</h2>
  <p>For newcomers, the best bank is not always the biggest bank. The right choice is the one that makes daily life easier, keeps fees under control, supports your first months in North America, and helps you build long-term financial stability. Comparing practical features, asking the right questions, and understanding the fine print can save both money and stress.</p>
</section>`;

const fallbackFaq = `
<section>
  <h2>Frequently Asked Questions</h2>
  <h3>Can I open a bank account without a Social Security Number?</h3>
  <p>In many cases, yes. Some banks may accept a passport, visa, ITIN, or other approved documents depending on their internal policy.</p>
  <h3>What type of account should I open first?</h3>
  <p>Most newcomers begin with a checking account for daily use, then add a savings account once their income and budget are stable.</p>
  <h3>How do I avoid unnecessary banking fees?</h3>
  <p>Check monthly maintenance fees, minimum balance rules, ATM costs, and overdraft settings before opening the account.</p>
</section>`;

const ensureSection = (content, marker, fallback) => content.includes(marker) ? content : `${content}${fallback}`;
const safeParseJson = (value = '') => {
  try {
    return JSON.parse(value || '{}');
  } catch {
    const start = String(value).indexOf('{');
    const end = String(value).lastIndexOf('}');
    if (start >= 0 && end > start) {
      return JSON.parse(String(value).slice(start, end + 1));
    }
    return {};
  }
};

const buildDefaultSchema = (title, description) => JSON.stringify({
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline: title,
  author: {
    '@type': 'Person',
    name: 'Talal Eddaouahiri'
  },
  datePublished: new Date().toISOString(),
  image: ['https://source.unsplash.com/featured/1200x800/?banking'],
  description,
});

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (req.method !== 'POST') {
      return Response.json({ endpoint: 'generateArticleDraft', required_fields: ['project_id', 'primary_keyword'], optional_fields: ['title_hint', 'audience', 'country', 'tone', 'article_type', 'length'] });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    if (!payload.project_id || !payload.primary_keyword) {
      return Response.json({ endpoint: 'generateArticleDraft', required_fields: ['project_id', 'primary_keyword'], optional_fields: ['title_hint', 'audience', 'country', 'tone', 'article_type', 'length'] });
    }

    const prompt = `You are generating SEO-optimized financial articles for MoneyAbroadGuide.com. Website: MoneyAbroadGuide.com. Author: Talal Eddaouahiri. Audience: immigrants, expats, international newcomers moving to the United States and Canada. Primary keyword: ${toText(payload.primary_keyword)}. Title hint: ${toText(payload.title_hint)}. Country: ${toText(payload.country || 'USA and Canada')}. Tone: ${toText(payload.tone || 'helpful expert')}. Article type: ${toText(payload.article_type || 'guide')}. Article length: 2500 to 4000 words, but target at least 3500 words when possible. Create a strong SEO H1 title including the main keyword and year when relevant. Add an introduction of about 150 to 200 words. Include 5 to 6 key takeaways in bullet points. Include a clickable table of contents. Include a realistic hero image plus at least 4 realistic images throughout the article, each with SEO alt text and a caption, placed naturally in the content. Include 5 to 8 main sections with explanations, practical advice, bullet points, and examples. Include 1 to 3 comparison tables when relevant. Include a market analysis section, one graph or chart-style section, two realistic stories about immigrants or expats, a practical tips section, 3 to 5 common mistakes to avoid, 5 to 7 FAQs, 3 to 6 internal links to related MoneyAbroadGuide articles, a CTA, a conclusion, an author bio for Talal Eddaouahiri, and this financial disclaimer exactly: The information in this article is for educational purposes only and should not be considered financial, legal, or tax advice. Readers should consult qualified professionals before making financial decisions. Use H1, H2, H3 headings, short paragraphs, bullet points, tables where useful, and clean HTML optimized for WordPress publishing. Do NOT invent an old publication date inside the body because the publication date is inserted automatically. Follow Google EEAT principles for finance content. Return only JSON with title, excerpt, meta_title, meta_description, table_of_contents, html_content, faq_html, schema_markup.`;

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      max_tokens: 7000,
      response_format: { type: 'json_object' },
      messages: [
        {
          role: 'system',
          content: 'You write original SEO-first long-form finance content for expats, immigrants, newcomers, foreign workers, and international students in the USA and Canada. Return only valid JSON with WordPress-ready HTML sections.'
        },
        {
          role: 'user',
          content: prompt
        }
      ]
    });

    const parsed = safeParseJson(response.choices[0]?.message?.content || '{}');
    const title = toText(parsed.title || payload.title_hint || payload.primary_keyword);
    let baseHtmlContent = toText(parsed.html_content)
      .replace(/<p[^>]*class=['"]author['"][^>]*>[\s\S]*?<\/p>/ig, '')
      .replace(/<p[^>]*class=['"]publication-date['"][^>]*>[\s\S]*?<\/p>/ig, '')
      .replace(/<p[^>]*>\s*Published on:[\s\S]*?<\/p>/ig, '');
    let finalHtmlContent = `${buildArticleMetaBlock()}${defaultImageGallery}${baseHtmlContent}`;
    finalHtmlContent = ensureSection(finalHtmlContent, '<table', fallbackComparisonTable);
    finalHtmlContent = ensureSection(finalHtmlContent, 'Real Story', fallbackStorySection);
    finalHtmlContent = ensureSection(finalHtmlContent, 'Illustrative Budget Chart', fallbackChartSection);
    finalHtmlContent = ensureSection(finalHtmlContent, 'Official Data and Study Angles', fallbackStudiesSection);
    finalHtmlContent = ensureSection(finalHtmlContent, 'Expert Tips from Talal Eddaouahiri', fallbackExpertTips);
    finalHtmlContent = ensureSection(finalHtmlContent, 'Common Mistakes to Avoid', fallbackMistakesSection);
    finalHtmlContent = ensureSection(finalHtmlContent, 'Frequently Asked Questions', fallbackFaq);
    finalHtmlContent = ensureSection(finalHtmlContent, 'Explore More Money Abroad Guide Resources', fallbackCTASection);
    finalHtmlContent = ensureSection(finalHtmlContent, '<h2>Conclusion</h2>', fallbackConclusionSection);

    let enrichmentIndex = 1;
    while (countWords(finalHtmlContent) < 3500) {
      finalHtmlContent += `<section><h2>Additional Practical Guidance for Newcomers ${enrichmentIndex}</h2><p>Opening a bank account is only one part of building a stable financial life in North America. Newcomers should also review transfer fees, debit card protections, cash withdrawal rules, budgeting habits, and how to start creating a reliable money system for everyday life. Before choosing a bank, compare how easy it is to receive salary deposits, set up bill payments, manage savings, and contact support when problems happen.</p><p>It is also useful to compare the first 90 days of financial setup: a checking account for salary and bills, a savings account for emergency funds, a simple monthly budget, and a careful review of card fees and ATM access. Talal Eddaouahiri recommends building these foundations early so that expats and newcomers can avoid unnecessary banking costs and start their new life with more confidence.</p><p>Another practical point is documentation. Keep your passport, visa, proof of address, tax identification documents, and any onboarding letters organized in both paper and digital format. This reduces delays when banks, landlords, telecom providers, or employers ask for verification. A well-organized financial setup saves time, protects your budget, and reduces stress while settling in.</p><p>Newcomers should also compare the difference between online-first banks, traditional branch banks, and credit unions. Each option can be useful depending on your need for in-person support, multilingual service, wire transfers, and credit-building products. Taking the time to compare these options can make the first year in North America much easier financially.</p><p>Finally, always review the long-term picture rather than just the welcome offer. A newcomer package can be attractive for the first year, but what matters most is what happens after the promotional period ends: monthly fees, ATM access, transfer charges, customer support quality, branch convenience, and future credit-building options. Choosing with that mindset usually leads to a much better banking outcome.</p></section>`;
      enrichmentIndex += 1;
    }

    const faqHtml = toText(parsed.faq_html) || fallbackFaq;
    const finalWordCount = countWords(finalHtmlContent);
    const htmlFile = new File([finalHtmlContent], `${slugify(title)}.html`, { type: 'text/html' });
    const upload = await base44.asServiceRole.integrations.Core.UploadFile({ file: htmlFile });
    const draft = {
      project_id: payload.project_id,
      title,
      slug: slugify(title),
      excerpt: toText(parsed.excerpt),
      primary_keyword: toText(payload.primary_keyword),
      secondary_keywords: toArray(payload.secondary_keywords).map((item) => toText(item)).filter(Boolean),
      article_type: toText(payload.article_type || 'guide'),
      tone: toText(payload.tone || 'helpful expert'),
      country: toText(payload.country || 'USA and Canada'),
      language: 'English',
      meta_title: toText(parsed.meta_title),
      meta_description: toText(parsed.meta_description),
      html_content: finalHtmlContent.slice(0, 12000),
      html_file_url: upload.file_url,
      table_of_contents: toArray(parsed.table_of_contents).map((item) => toText(item)).filter(Boolean),
      faq_html: faqHtml,
      schema_markup: normalizeSchemaMarkup(parsed.schema_markup || buildDefaultSchema(title, toText(parsed.meta_description)), title, toText(parsed.meta_description)),
      wordpress_status: 'not_sent',
      status: 'ready'
    };

    const created = await base44.entities.ContentDraft.create(draft);
    await base44.entities.AIUsageLog.create({
      workspace_id: toText(payload.workspace_id),
      project_id: payload.project_id,
      feature_name: 'article_generation',
      provider: 'openai',
      model: 'gpt-4o-mini',
      status: 'success'
    });

    return Response.json({ success: true, draft: created, word_count: finalWordCount });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});