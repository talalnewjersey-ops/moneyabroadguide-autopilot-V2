import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Loader2, Sparkles, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import EmptyState from '../components/common/EmptyState';

export default function EEAT() {
  const [analyzing, setAnalyzing] = useState(false);
  const [audit, setAudit] = useState(null);

  const { data: websites = [] } = useQuery({
    queryKey: ['websites'],
    queryFn: () => base44.entities.Website.list('-created_date', 1),
  });

  const activeWebsite = websites[0];

  const runAudit = async () => {
    if (!activeWebsite) return;
    setAnalyzing(true);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Audit E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness) signals for ${activeWebsite.url}.
      
      Check for:
      - Author bio presence
      - About page quality
      - Contact page
      - Editorial policy
      - Privacy policy
      - Citations and sources
      - Expert credentials
      - Trust badges
      - Financial disclosure (if applicable)
      
      Return a detailed audit with score and specific recommendations.`,
      response_json_schema: {
        type: "object",
        properties: {
          overall_score: { type: "number" },
          checks: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                status: { type: "string" },
                description: { type: "string" },
                recommendation: { type: "string" }
              }
            }
          },
          improvements: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                priority: { type: "string" },
                suggested_content: { type: "string" }
              }
            }
          }
        }
      },
      add_context_from_internet: true,
    });

    setAudit(result);
    setAnalyzing(false);
  };

  if (!activeWebsite) {
    return <EmptyState icon={Shield} title="No website connected" description="Add a website in Settings first." />;
  }

  const statusIcon = {
    pass: <CheckCircle2 className="w-4 h-4 text-green-500" />,
    fail: <XCircle className="w-4 h-4 text-red-500" />,
    warning: <AlertTriangle className="w-4 h-4 text-amber-500" />,
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <PageHeader
        title="E-E-A-T Optimizer"
        description="Audit and improve trust & authority signals"
        action={
          <Button onClick={runAudit} disabled={analyzing} className="bg-blue-600 hover:bg-blue-700 rounded-xl gap-2">
            {analyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {analyzing ? 'Auditing...' : 'Run E-E-A-T Audit'}
          </Button>
        }
      />

      {!audit ? (
        <EmptyState icon={Shield} title="No E-E-A-T audit yet" description="Run an audit to check your trust and authority signals." action="Run Audit" onAction={runAudit} />
      ) : (
        <>
          <div className="bg-white rounded-2xl border border-gray-100 p-6 text-center">
            <p className="text-sm text-gray-500 mb-2">E-E-A-T Score</p>
            <p className="text-5xl font-bold text-gray-900">{audit.overall_score}<span className="text-lg text-gray-400">/100</span></p>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Trust Signal Checks</h3>
            <div className="space-y-3">
              {audit.checks?.map((check, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-gray-50/50">
                  {statusIcon[check.status] || statusIcon.warning}
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-800">{check.name}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{check.description}</p>
                    {check.recommendation && check.status !== 'pass' && (
                      <p className="text-xs text-blue-600 mt-1">{check.recommendation}</p>
                    )}
                  </div>
                  <Badge variant="secondary" className={
                    check.status === 'pass' ? 'bg-green-50 text-green-700' :
                    check.status === 'fail' ? 'bg-red-50 text-red-700' :
                    'bg-amber-50 text-amber-700'
                  }>
                    {check.status}
                  </Badge>
                </div>
              ))}
            </div>
          </div>

          {audit.improvements?.length > 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Suggested Improvements</h3>
              <div className="space-y-3">
                {audit.improvements.map((imp, i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="text-sm font-semibold text-gray-900">{imp.title}</h4>
                        <Badge className={imp.priority === 'high' ? 'bg-red-50 text-red-700' : imp.priority === 'medium' ? 'bg-amber-50 text-amber-700' : 'bg-green-50 text-green-700'}>
                          {imp.priority}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-600">{imp.description}</p>
                      {imp.suggested_content && (
                        <div className="mt-2 bg-gray-50 p-3 rounded-lg text-xs text-gray-700 whitespace-pre-wrap">
                          {imp.suggested_content}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}