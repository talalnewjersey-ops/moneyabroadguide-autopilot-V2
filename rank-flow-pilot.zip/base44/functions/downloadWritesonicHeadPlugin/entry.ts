import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import JSZip from 'npm:jszip@3.10.1';

const pluginPhp = `<?php
/*
Plugin Name: Money Abroad Guide Writesonic Head Connector
Description: Adds a configurable head script and a protected REST endpoint to manage it remotely.
Version: 1.0.0
Author: Money Abroad Guide
*/

if (!defined('ABSPATH')) {
    exit;
}

class MAG_Writesonic_Head_Connector {
    const SCRIPT_OPTION = 'mag_writesonic_head_script';
    const API_KEY_OPTION = 'mag_writesonic_head_api_key';

    public function __construct() {
        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('wp_head', [$this, 'render_head_script'], 1);
        add_action('rest_api_init', [$this, 'register_rest_routes']);
    }

    public static function activate() {
        if (!get_option(self::API_KEY_OPTION)) {
            update_option(self::API_KEY_OPTION, wp_generate_password(32, false, false));
        }

        if (!get_option(self::SCRIPT_OPTION)) {
            update_option(self::SCRIPT_OPTION, self::default_script());
        }
    }

    public static function default_script() {
        return <<<'HTML'
<script src="https://seo-fixer.writesonic.com/site-audit/fixer-script/index.js" id="wsAiSeoMb"></script>
<script id="wsAiSeoInitScript">
  wsSEOfixer.configure({
    hostURL: 'https://seo-fixer.writesonic.com',
    siteID: '698b3972462c09142695aef9'
  });
</script>
HTML;
    }

    public function register_menu() {
        add_options_page(
            'Writesonic Head Connector',
            'Writesonic Head',
            'manage_options',
            'mag-writesonic-head',
            [$this, 'render_settings_page']
        );
    }

    public function register_settings() {
        register_setting('mag_writesonic_head_group', self::SCRIPT_OPTION);
    }

    public function render_head_script() {
        $script = get_option(self::SCRIPT_OPTION, '');
        if (!empty($script)) {
            echo "\n" . $script . "\n";
        }
    }

    public function register_rest_routes() {
        register_rest_route('mag-head/v1', '/script', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_script_route'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function handle_script_route($request) {
        if ($request->get_method() === 'GET') {
            return new WP_REST_Response([
                'success' => true,
                'installed' => true,
                'endpoint' => rest_url('mag-head/v1/script'),
                'has_script' => !empty(get_option(self::SCRIPT_OPTION, '')),
            ], 200);
        }

        $provided_key = $request->get_header('x-mag-head-key');
        $saved_key = get_option(self::API_KEY_OPTION, '');

        if (!$saved_key || !$provided_key || !hash_equals($saved_key, $provided_key)) {
            return new WP_REST_Response([
                'success' => false,
                'error' => 'Unauthorized',
            ], 401);
        }

        $script = $request->get_param('script');
        if (!is_string($script) || trim($script) === '') {
            return new WP_REST_Response([
                'success' => false,
                'error' => 'Missing script',
            ], 400);
        }

        update_option(self::SCRIPT_OPTION, $script);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Head script updated successfully',
        ], 200);
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $endpoint = rest_url('mag-head/v1/script');
        $api_key = get_option(self::API_KEY_OPTION, '');
        $script = get_option(self::SCRIPT_OPTION, self::default_script());
        ?>
        <div class="wrap">
            <h1>Writesonic Head Connector</h1>
            <p>Use this plugin to manage the head script and expose a protected REST endpoint for remote updates.</p>
            <p><strong>REST endpoint:</strong> <code><?php echo esc_html($endpoint); ?></code></p>
            <p><strong>API key:</strong> <code><?php echo esc_html($api_key); ?></code></p>
            <p>Send your updates with the HTTP header <code>x-mag-head-key</code>.</p>

            <form method="post" action="options.php">
                <?php settings_fields('mag_writesonic_head_group'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="mag_writesonic_head_script">Head script</label></th>
                        <td>
                            <textarea id="mag_writesonic_head_script" name="mag_writesonic_head_script" rows="12" class="large-text code"><?php echo esc_textarea($script); ?></textarea>
                            <p class="description">This script will be printed inside the &lt;head&gt; of your site.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save Script'); ?>
            </form>
        </div>
        <?php
    }
}

register_activation_hook(__FILE__, ['MAG_Writesonic_Head_Connector', 'activate']);
new MAG_Writesonic_Head_Connector();
`;

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }

    const zip = new JSZip();
    zip.folder('money-abroad-guide-writesonic-head-connector')?.file('money-abroad-guide-writesonic-head-connector.php', pluginPhp);
    const zipBytes = await zip.generateAsync({ type: 'uint8array' });
    const zipFile = new File([zipBytes], 'money-abroad-guide-writesonic-head-connector.zip', { type: 'application/zip' });
    const upload = await base44.asServiceRole.integrations.Core.UploadFile({ file: zipFile });

    if (!payload.download) {
      return Response.json({
        success: true,
        function_name: 'downloadWritesonicHeadPlugin',
        plugin_slug: 'money-abroad-guide-writesonic-head-connector',
        filename: 'money-abroad-guide-writesonic-head-connector.zip',
        file_url: upload.file_url,
        instructions: [
          'Open the file_url to download the plugin ZIP.',
          'Upload the ZIP in WordPress > Plugins > Add New > Upload Plugin.',
          'After activation, open Settings > Writesonic Head to copy the endpoint and API key.'
        ]
      });
    }

    return new Response(zipBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename="money-abroad-guide-writesonic-head-connector.zip"'
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});